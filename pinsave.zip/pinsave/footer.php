        <!-- Footer -->
        <footer class="bg-white rounded-lg shadow-md mt-8 p-6">
            <div class="container mx-auto">
                <!-- Disclaimer -->
                <div class="mb-6 border-b pb-4">
                    <h2 class="text-lg font-semibold text-gray-700 mb-3">Disclaimer</h2>
                    <p class="text-sm text-gray-600">
                        <?php echo !empty($footerConfig['disclaimer']) 
                            ? nl2br(htmlspecialchars($footerConfig['disclaimer'])) 
                            : 'PinterestDownloader does not host any pirated or copyright content on its server, and all videos or images that you download from our tool are downloaded from their respective CDN servers. And this tool is not associated with Pinterest in any ways.'; ?>
                    </p>
                </div>
                
                <!-- Footer Navigation -->
                <div class="flex flex-col md:flex-row justify-between items-center border-b pb-4 mb-4">
                    <div class="mb-4 md:mb-0">
                        <h3 class="text-md font-medium text-gray-700 mb-2">Quick Links</h3>
                        <ul class="flex flex-wrap gap-x-6 gap-y-2">
                            <li><a href="/host/pinsave/pages/about.php" class="text-blue-600 hover:text-blue-800 text-sm flex items-center"><i class="fas fa-info-circle mr-1"></i> About Us</a></li>
                            <li><a href="/host/pinsave/pages/contact.php" class="text-blue-600 hover:text-blue-800 text-sm flex items-center"><i class="fas fa-envelope mr-1"></i> Contact Us</a></li>
                            <li><a href="/host/pinsave/blog.php" class="text-blue-600 hover:text-blue-800 text-sm flex items-center"><i class="fas fa-blog mr-1"></i> Blog</a></li>
                            <li><a href="/host/pinsave/pages/faq.php" class="text-blue-600 hover:text-blue-800 text-sm flex items-center"><i class="fas fa-question-circle mr-1"></i> FAQ</a></li>
                            <li><a href="/host/pinsave/pages/dmca.php" class="text-blue-600 hover:text-blue-800 text-sm flex items-center"><i class="fas fa-copyright mr-1"></i> DMCA Policy</a></li>
                            <li><a href="/host/pinsave/pages/privacy.php" class="text-blue-600 hover:text-blue-800 text-sm flex items-center"><i class="fas fa-shield-alt mr-1"></i> Privacy Policy</a></li>
                            <li><a href="/host/pinsave/pages/terms.php" class="text-blue-600 hover:text-blue-800 text-sm flex items-center"><i class="fas fa-gavel mr-1"></i> Terms of Service</a></li>
                        </ul>
                    </div>
                    
                    <!-- Info Links -->
                    <?php if (!empty($footerConfig['links'])): ?>
                    <div>
                        <h3 class="text-md font-medium text-gray-700 mb-2">Resources</h3>
                        <ul class="flex flex-wrap gap-x-6 gap-y-2">
                            <?php foreach ($footerConfig['links'] as $link): ?>
                            <?php if (!empty($link['text']) && !empty($link['url'])): ?>
                            <li>
                                <a href="<?php echo htmlspecialchars($link['url']); ?>" class="text-blue-600 hover:text-blue-800 text-sm">
                                    <?php echo htmlspecialchars($link['text']); ?>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Copyright -->
                <div class="text-center text-gray-600 text-sm">
                    <p><?php echo htmlspecialchars($footerConfig['copyright_text'] ?? '© ' . date('Y') . ' PinSave - Pinterest Video Downloader | All Rights Reserved'); ?></p>
                </div>
            </div>
        </footer>
    </div>
</body>
</html>
