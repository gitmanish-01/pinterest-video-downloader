<?php
class Router {
    private $routes = [];
    private $notFoundCallback;
    private $basePath;
    
    public function __construct($basePath = '') {
        $this->basePath = $basePath;
    }
    
    public function add($pattern, $callback) {
        // Convert pattern to regex
        $pattern = str_replace('/', '\/', $pattern);
        $pattern = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '(?P<$1>[^\/]+)', $pattern);
        $this->routes[$pattern] = $callback;
        return $this;
    }
    
    public function notFound($callback) {
        $this->notFoundCallback = $callback;
        return $this;
    }
    
    public function dispatch() {
        // Get the request URI and remove query string
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        
        // Remove base path from URI if it exists
        if ($this->basePath && strpos($uri, $this->basePath) === 0) {
            $uri = substr($uri, strlen($this->basePath));
        }
        
        // Remove trailing slash
        $uri = rtrim($uri, '/');
        
        // Add leading slash if missing
        if (empty($uri)) {
            $uri = '/';
        }
        
        // Try to match route
        foreach ($this->routes as $pattern => $callback) {
            if (preg_match('/^' . $pattern . '$/', $uri, $matches)) {
                // Remove numeric keys
                foreach ($matches as $key => $value) {
                    if (is_int($key)) {
                        unset($matches[$key]);
                    }
                }
                
                // Call the callback with parameters
                return call_user_func($callback, $matches);
            }
        }
        
        // If no route found, call notFound callback
        if ($this->notFoundCallback) {
            return call_user_func($this->notFoundCallback);
        }
        
        // Default 404 if no notFound callback
        header("HTTP/1.0 404 Not Found");
        echo '404 Not Found';
    }
}
