<?php
require_once __DIR__ . '/cache_handler.php';
require_once __DIR__ . '/rate_limiter.php';
require_once __DIR__ . '/stats_handler.php';

function downloadPinterestContent($url) {
    $stats_handler = new StatsHandler();
    $start_time = microtime(true);
    global $config;
    
    $result = [
        'success' => false,
        'url' => '',
        'type' => '',
        'error' => '',
        'debug' => []
    ];
    
    // Normalize URL
    $url = normalizeUrl($url);
    
    // Add debug information
    $debug = [
        'api_provider' => $config['api']['api_provider'],
        'debug_mode' => $config['api']['debug_mode'] ? 'Enabled' : 'Disabled',
        'timestamp' => date('Y-m-d H:i:s'),
        'url' => $url
    ];

    // Try Pinterest's Internal API first
    try {
        $video_url = extractFromInternalApi($url);
        if ($video_url) {
            $response_time = (microtime(true) - $start_time) * 1000; // Convert to milliseconds
            $stats_handler->logAPIRequest('internal_api', true, $response_time);
            $result['success'] = true;
            $result['url'] = $video_url;
            $result['type'] = 'video';
            $debug['method'] = 'internal_api';
            $debug['status'] = 'success';
            $result['debug'] = $debug;
            return $result;
        }
    } catch (Exception $e) {
        $debug['internal_api_error'] = $e->getMessage();
    }

    // Initialize cache and rate limiter
    $cache = new CacheHandler();
    $rate_limiter = new RateLimiter();
    
    // Check cache first
    $cache_key = $cache->getCacheKey($url);
    $cached_result = $cache->get($cache_key);
    if ($cached_result) {
        $cached_result['debug']['source'] = 'cache';
        return $cached_result;
    }

    // Try RapidAPI providers in sequence
    $api_providers = [
        'pinterest-video-downloader1' => 'https://pinterest-video-and-image-downloader.p.rapidapi.com/pinterest',
        'pinterest-downloader2' => 'https://pinterest-downloader.p.rapidapi.com/download',
        'pinterest-video-api3' => 'https://pinterest-video-api.p.rapidapi.com/download',
        'pinterest-download-api4' => 'https://pinterest-download-api.p.rapidapi.com/v1/download',
        'pinterest-media-api5' => 'https://pinterest-media-downloader.p.rapidapi.com/download',
        'pinterestv6' => 'https://pinterest-video-downloader-v6.p.rapidapi.com/download',
        'pinsaver7' => 'https://pinterest-downloader-v7.p.rapidapi.com/video',
        'pinextractor8' => 'https://pinterest-extractor-v8.p.rapidapi.com/media'
    ];

    foreach ($api_providers as $provider => $endpoint) {
        // Check rate limit before making request
        try {
            $rate_limiter->checkLimit($provider);
        } catch (Exception $e) {
            $debug['rate_limit_error'][$provider] = $e->getMessage();
            continue;
        }
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $endpoint . "?url=" . urlencode($url));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "X-RapidAPI-Host: " . parse_url($endpoint, PHP_URL_HOST),
                "X-RapidAPI-Key: " . $config['api']['rapidapi_key']
            ]);
            
            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($http_code == 200) {
                $data = json_decode($response, true);
                
                if (isset($data['video_url']) || isset($data['url']) || isset($data['download_url'])) {
                    $response_time = (microtime(true) - $start_time) * 1000;
                    $stats_handler->logAPIRequest($provider, true, $response_time);
                    $video_url = $data['video_url'] ?? $data['url'] ?? $data['download_url'];
                    $result['success'] = true;
                    $result['url'] = $video_url;
                    $result['type'] = 'video';
                    $debug['api_method'] = $provider;
                    $debug['status'] = 'success';
                    $result['debug'] = $debug;
                    // Cache successful result
                    $cache->set($cache_key, $result);
                    return $result;
                }
            }
            
            $response_time = (microtime(true) - $start_time) * 1000;
            $stats_handler->logAPIRequest($provider, false, $response_time, $response);
            
            $debug['api_attempts'][$provider] = [
                'http_code' => $http_code,
                'response' => substr($response, 0, 200) // Truncate long responses
            ];
            
        } catch (Exception $e) {
            $debug['api_errors'][$provider] = $e->getMessage();
        }
    }

    // Try direct HTML extraction as last resort
    try {
        $video_url = extractFromHtml($url);
        if ($video_url) {
            $result['success'] = true;
            $result['url'] = $video_url;
            $result['type'] = 'video';
            $debug['method'] = 'direct_html';
            $debug['status'] = 'success';
            $result['debug'] = $debug;
            return $result;
        }
    } catch (Exception $e) {
        $debug['direct_extraction'] = 'failed';
        $debug['direct_error'] = $e->getMessage();
    }

    // If all methods fail, try to get image instead
    try {
        $image_url = extractImage($url);
        if ($image_url) {
            $result['success'] = true;
            $result['url'] = $image_url;
            $result['type'] = 'image';
            $debug['method'] = 'image_fallback';
            $debug['status'] = 'success';
            $result['debug'] = $debug;
            return $result;
        }
    } catch (Exception $e) {
        $debug['image_extraction'] = 'failed';
        $debug['image_error'] = $e->getMessage();
    }

    // All methods failed
    $result['error'] = 'Could not extract content from Pinterest URL';
    $debug['status'] = 'failed';
    $result['debug'] = $debug;
    return $result;
}

function normalizeUrl($url) {
    // Convert pin.it URLs to full URLs
    if (strpos($url, 'pin.it/') !== false) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);
        $url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);
    }
    return $url;
}

function extractFromInternalApi($url) {
    // Extract pin ID from URL
    preg_match('/pin\/(\d+)/', $url, $matches);
    if (!isset($matches[1])) return false;
    
    $pin_id = $matches[1];
    $api_url = "https://www.pinterest.com/resource/PinResource/get/?source_url=/pin/{$pin_id}/&data=" . 
               urlencode(json_encode([
                   "options" => [
                       "field_set_key" => "detailed",
                       "id" => $pin_id
                   ]
               ]));

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Accept: application/json',
        'X-Requested-With: XMLHttpRequest'
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);
    if (isset($data['resource_response']['data']['videos']['video_list']['V_720P']['url'])) {
        return $data['resource_response']['data']['videos']['video_list']['V_720P']['url'];
    }
    
    return false;
}

function extractFromHtml($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
    
    $html = curl_exec($ch);
    curl_close($ch);

    // Try multiple patterns
    $patterns = [
        '/"video_url":"([^"]+)"/',
        '/<meta property="og:video" content="([^"]+)"/',
        '/<meta property="og:video:url" content="([^"]+)"/',
        '/&quot;url&quot;:&quot;(https:\/\/v\.pinimg\.com[^&]+)&quot;/',
        '/data-video-id="[^"]+" data-test-id="video-root" src="([^"]+)"/'
    ];

    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $html, $matches)) {
            return str_replace('\/', '/', $matches[1]);
        }
    }
    
    return false;
}

function extractImage($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
    
    $html = curl_exec($ch);
    curl_close($ch);

    // Try multiple patterns for images
    $patterns = [
        '/<meta property="og:image" content="([^"]+)"/',
        '/"image_url":"([^"]+)"/',
        '/data-test-id="pin-image" src="([^"]+)"/',
        '/<img class="pinImage" src="([^"]+)"/'
    ];

    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $html, $matches)) {
            return str_replace('\/', '/', $matches[1]);
        }
    }
    
    return false;
}
?>
