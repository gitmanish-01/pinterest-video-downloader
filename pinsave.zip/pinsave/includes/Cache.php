<?php
class Cache {
    private $cachePath;
    
    public function __construct() {
        $this->cachePath = dirname(__DIR__) . '/cache';
        
        // Create cache directory if it doesn't exist
        if (!is_dir($this->cachePath)) {
            mkdir($this->cachePath, 0755, true);
        }
    }
    
    public function get($key) {
        $filename = $this->getFilename($key);
        
        if (!file_exists($filename)) {
            return false;
        }
        
        $content = file_get_contents($filename);
        $data = unserialize($content);
        
        // Check if cache has expired
        if (time() > $data['expires']) {
            unlink($filename);
            return false;
        }
        
        return $data['content'];
    }
    
    public function set($key, $content, $ttl = 3600) {
        $filename = $this->getFilename($key);
        
        $data = [
            'expires' => time() + $ttl,
            'content' => $content
        ];
        
        return file_put_contents($filename, serialize($data));
    }
    
    public function delete($key) {
        $filename = $this->getFilename($key);
        if (file_exists($filename)) {
            return unlink($filename);
        }
        return true;
    }
    
    public function clear() {
        $files = glob($this->cachePath . '/*');
        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file);
            }
        }
        return true;
    }
    
    private function getFilename($key) {
        return $this->cachePath . '/' . md5($key) . '.cache';
    }
}
