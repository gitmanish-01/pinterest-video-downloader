<?php
class CacheHandler {
    private $cache_dir;
    private $cache_time = 86400; // 24 hours

    public function __construct() {
        $this->cache_dir = dirname(__DIR__) . '/cache';
        if (!file_exists($this->cache_dir)) {
            mkdir($this->cache_dir, 0755, true);
        }
    }

    public function getCacheKey($url) {
        return md5($url);
    }

    public function get($key) {
        $cache_file = $this->cache_dir . '/' . $key . '.json';
        
        if (file_exists($cache_file)) {
            $content = file_get_contents($cache_file);
            $data = json_decode($content, true);
            
            // Check if cache is still valid
            if ($data['expires'] > time()) {
                return $data['content'];
            }
            
            // Delete expired cache
            unlink($cache_file);
        }
        
        return null;
    }

    public function set($key, $content, $ttl = null) {
        $cache_file = $this->cache_dir . '/' . $key . '.json';
        $data = [
            'content' => $content,
            'expires' => time() + ($ttl ?? $this->cache_time)
        ];
        
        return file_put_contents($cache_file, json_encode($data));
    }

    public function clear($key = null) {
        if ($key) {
            $cache_file = $this->cache_dir . '/' . $key . '.json';
            if (file_exists($cache_file)) {
                return unlink($cache_file);
            }
            return false;
        }
        
        // Clear all cache
        $files = glob($this->cache_dir . '/*.json');
        foreach ($files as $file) {
            unlink($file);
        }
        return true;
    }
}
?>
