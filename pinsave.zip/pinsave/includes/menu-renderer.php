<?php
function render_menu($location = 'top', $config = null) {
    if (!$config) {
        global $adminConfig;
        $config = $adminConfig;
    }

    $menu_items = $config['menus']['locations'][$location] ?? [];
    
    if (empty($menu_items)) {
        return '';
    }

    $output = '';
    
    switch ($location) {
        case 'top':
            $output .= '<nav class="bg-white shadow-sm rounded-lg px-6 py-3">';
            $output .= '<ul class="flex flex-wrap justify-center gap-6">';
            foreach ($menu_items as $item) {
                $output .= sprintf(
                    '<li><a href="%s" class="text-gray-600 hover:text-blue-600">%s</a></li>',
                    htmlspecialchars($item['url']),
                    htmlspecialchars($item['title'])
                );
            }
            $output .= '</ul>';
            $output .= '</nav>';
            break;
            
        case 'footer':
            $output .= '<ul class="space-y-2">';
            foreach ($menu_items as $item) {
                $output .= sprintf(
                    '<li><a href="%s" class="text-blue-600 hover:underline">%s</a></li>',
                    htmlspecialchars($item['url']),
                    htmlspecialchars($item['title'])
                );
            }
            $output .= '</ul>';
            break;
            
        case 'sidebar':
            $output .= '<nav class="bg-white rounded-lg shadow-md p-4">';
            $output .= '<ul class="space-y-2">';
            foreach ($menu_items as $item) {
                $output .= sprintf(
                    '<li><a href="%s" class="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded">%s</a></li>',
                    htmlspecialchars($item['url']),
                    htmlspecialchars($item['title'])
                );
            }
            $output .= '</ul>';
            $output .= '</nav>';
            break;
    }
    
    return $output;
}
?>
