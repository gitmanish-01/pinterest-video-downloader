<?php
require_once __DIR__ . '/../api/pinterest_api_handler.php';

class ApiHandler {
    private $config;
    private $stats_handler;
    private $pinterest_handler;
    
    public function __construct() {
        // Load config
        $configFile = __DIR__ . '/../config/admin_settings.json';
        if (file_exists($configFile)) {
            $this->config = json_decode(file_get_contents($configFile), true);
        } else {
            $this->config = [
                'api' => [
                    'rapidapi_key' => '',
                    'api_provider' => 'pinterest-video-downloader1',
                    'debug_mode' => false
                ]
            ];
        }
        
        // Initialize handlers
        require_once __DIR__ . '/stats_handler.php';
        $this->stats_handler = new StatsHandler();
        $this->pinterest_handler = new PinSave\Api\PinterestApiHandler();
    }
    
    public function checkApiStatus() {
        // Check if API key is set
        if (empty($this->config['api']['rapidapi_key'])) {
            return false;
        }
        
        // Get provider health from stats
        $stats = $this->stats_handler->getStats();
        $provider = $this->config['api']['api_provider'];
        
        if (isset($stats['health']['providers'][$provider])) {
            $health = $stats['health']['providers'][$provider];
            
            // Consider API healthy if:
            // 1. Last check was within 5 minutes
            // 2. Success rate is above 80%
            // 3. Average response time is under 2 seconds
            $last_check = strtotime($health['last_check']);
            $five_minutes_ago = time() - 300;
            
            if ($last_check > $five_minutes_ago &&
                $health['success_rate'] > 80 &&
                $health['avg_response_time'] < 2000) {
                return true;
            }
        }
        
        return false;
    }
    
    public function makeApiRequest($url) {
        $provider = $this->config['api']['api_provider'];
        $start_time = microtime(true);
        
        try {
            // Use the Pinterest API handler to get video data
            $result = $this->pinterest_handler->getVideoData($url);
            
            $end_time = microtime(true);
            $response_time = ($end_time - $start_time) * 1000; // Convert to milliseconds
            
            // Log the API request result
            $this->stats_handler->logAPIRequest(
                $provider,
                $result['success'],
                $response_time,
                $result['success'] ? null : ($result['message'] ?? 'Unknown error')
            );
            
            return [
                'success' => $result['success'],
                'data' => $result['success'] ? [
                    'video_url' => $result['video_url'],
                    'thumbnail' => $result['thumbnail'] ?? '',
                    'title' => $result['title'] ?? 'Pinterest Video'
                ] : null,
                'error' => $result['success'] ? null : $result['message']
            ];
            
        } catch (Exception $e) {
            $this->stats_handler->logAPIRequest($provider, false, 0, $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
}
