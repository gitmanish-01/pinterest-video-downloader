<?php
/**
 * Default content for pages when admin settings are not available
 */

// Default About page content
$defaultAboutContent = <<<EOT
<p><i class="fas fa-info-circle text-red-600"></i> <strong>PinSave</strong> is a free online Pinterest video downloader that helps you save videos in high-quality (HD) without any watermark - quickly and securely.</p>

<p><i class="fas fa-bolt text-yellow-500"></i> Designed for content creators, educators, designers, and Pinterest enthusiasts, PinSave makes downloading seamless so you can use videos for inspiration, tutorials, presentations, or offline viewing.</p>

<p><i class="fas fa-rocket text-red-600"></i> Our platform is fast, mobile-friendly, and easy to use. You do not need to register or install any software - just copy the Pinterest video link and paste it into PinSave.</p>

<p><i class="fas fa-user-lock text-indigo-500"></i> We value your privacy. PinSave does not track or store any personal data. No login, no watermark, no hassle.</p>

<p><i class="fas fa-calendar-check text-green-600"></i> Launched in 2023, we are continuously improving PinSave with feedback from our users. We aim to make it the best Pinterest downloader on the web.</p>

<p><i class="fas fa-heart text-red-600"></i> Thank you for using PinSave! For suggestions or support, visit our <a href="contact.php" class="text-red-600 underline">Contact</a> page.</p>
EOT;
