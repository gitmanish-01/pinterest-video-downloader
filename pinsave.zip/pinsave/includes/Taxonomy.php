<?php
class Taxonomy {
    private $adminConfig;
    
    public function __construct($config = null) {
        if (!$config) {
            global $adminConfig;
            $config = $adminConfig;
        }
        $this->adminConfig = $config;
    }
    
    /**
     * Get all categories with post counts
     */
    public function getCategories() {
        $categories = $this->adminConfig['categories'] ?? [];
        $posts = $this->adminConfig['posts'] ?? [];
        
        // Count posts in each category
        foreach ($categories as &$category) {
            $category['count'] = 0;
            foreach ($posts as $post) {
                if ($post['visibility'] === 'public' && ($post['category'] ?? '') === $category['slug']) {
                    $category['count']++;
                }
            }
        }
        
        return $categories;
    }
    
    /**
     * Get all tags with post counts
     */
    public function getTags() {
        $tags = [];
        $posts = $this->adminConfig['posts'] ?? [];
        
        foreach ($posts as $post) {
            if ($post['visibility'] === 'public') {
                foreach ($post['tags'] ?? [] as $tag) {
                    if (!isset($tags[$tag])) {
                        $tags[$tag] = [
                            'name' => $tag,
                            'count' => 0
                        ];
                    }
                    $tags[$tag]['count']++;
                }
            }
        }
        
        // Sort by count
        uasort($tags, function($a, $b) {
            return $b['count'] - $a['count'];
        });
        
        return $tags;
    }
    
    /**
     * Get popular tags (limited to top N)
     */
    public function getPopularTags($limit = 20) {
        return array_slice($this->getTags(), 0, $limit, true);
    }
    
    /**
     * Get related posts for a given post
     */
    public function getRelatedPosts($post, $limit = 3) {
        $related = [];
        $posts = $this->adminConfig['posts'] ?? [];
        
        foreach ($posts as $p) {
            if ($p['visibility'] === 'public' && $p['slug'] !== $post['slug']) {
                $score = 0;
                
                // Same category
                if (($p['category'] ?? '') === ($post['category'] ?? '')) {
                    $score += 2;
                }
                
                // Shared tags
                $shared_tags = array_intersect($p['tags'] ?? [], $post['tags'] ?? []);
                $score += count($shared_tags);
                
                if ($score > 0) {
                    $p['relevance_score'] = $score;
                    $related[] = $p;
                }
            }
        }
        
        // Sort by relevance score
        usort($related, function($a, $b) {
            return $b['relevance_score'] - $a['relevance_score'];
        });
        
        return array_slice($related, 0, $limit);
    }
    
    /**
     * Get posts by category
     */
    public function getPostsByCategory($category_slug) {
        return array_filter($this->adminConfig['posts'] ?? [], function($post) use ($category_slug) {
            return $post['visibility'] === 'public' && ($post['category'] ?? '') === $category_slug;
        });
    }
    
    /**
     * Get posts by tag
     */
    public function getPostsByTag($tag) {
        return array_filter($this->adminConfig['posts'] ?? [], function($post) use ($tag) {
            return $post['visibility'] === 'public' && in_array($tag, $post['tags'] ?? []);
        });
    }
    
    /**
     * Get category by slug
     */
    public function getCategoryBySlug($slug) {
        foreach ($this->adminConfig['categories'] ?? [] as $category) {
            if ($category['slug'] === $slug) {
                return $category;
            }
        }
        return null;
    }

    /**
     * Get all posts
     * @return array Array of all posts
     */
    public function getPosts() {
        return $this->adminConfig['posts'] ?? [];
    }
}
