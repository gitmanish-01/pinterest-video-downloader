<?php
class Template {
    protected $layout = 'default';
    protected $template;
    protected $data = [];
    protected $cache;
    protected $cacheTime = 3600; // 1 hour default
    
    public function __construct($template = null) {
        $this->template = $template;
        $this->cache = new Cache();
    }
    
    public function setLayout($layout) {
        $this->layout = $layout;
        return $this;
    }
    
    public function set($key, $value) {
        $this->data[$key] = $value;
        return $this;
    }
    
    public function setCacheTime($seconds) {
        $this->cacheTime = $seconds;
        return $this;
    }
    
    protected function getCacheKey() {
        return md5($this->layout . $this->template . serialize($this->data));
    }
    
    public function render() {
        $cacheKey = $this->getCacheKey();
        
        // Try to get from cache first
        if ($cached = $this->cache->get($cacheKey)) {
            return $cached;
        }
        
        // Start output buffering
        ob_start();
        
        // Extract data to make it available in template
        extract($this->data);
        
        // Include the layout
        require_once dirname(__DIR__) . "/templates/layouts/{$this->layout}.php";
        
        // Get the output and clean the buffer
        $output = ob_get_clean();
        
        // Save to cache
        $this->cache->set($cacheKey, $output, $this->cacheTime);
        
        return $output;
    }
    
    public function partial($name, $data = []) {
        // Extract data for the partial
        extract($data);
        
        // Include the partial
        require dirname(__DIR__) . "/templates/partials/{$name}.php";
    }
}
