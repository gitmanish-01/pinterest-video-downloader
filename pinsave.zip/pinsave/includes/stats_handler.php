<?php
class StatsHandler {
    private $stats_dir;
    private $daily_stats_file;
    private $provider_health_file;
    private $visitors_file;

    public function __construct() {
        $this->stats_dir = dirname(__DIR__) . '/stats';
        if (!file_exists($this->stats_dir)) {
            mkdir($this->stats_dir, 0755, true);
        }
        
        $this->daily_stats_file = $this->stats_dir . '/daily_stats.json';
        $this->provider_health_file = $this->stats_dir . '/provider_health.json';
        $this->visitors_file = $this->stats_dir . '/visitors.json';
        
        $this->initializeFiles();
    }

    private function initializeFiles() {
        if (!file_exists($this->daily_stats_file)) {
            file_put_contents($this->daily_stats_file, json_encode(['days' => []]));
        }
        if (!file_exists($this->provider_health_file)) {
            file_put_contents($this->provider_health_file, json_encode(['providers' => []]));
        }
        if (!file_exists($this->visitors_file)) {
            file_put_contents($this->visitors_file, json_encode([
                'total' => 0,
                'daily' => [],
                'countries' => [],
                'browsers' => []
            ]));
        }
    }

    public function logAPIRequest($provider, $success, $response_time, $error = null) {
        $hour = date('G'); // 0-23 hour format
        $minute = date('i');
        
        $today = date('Y-m-d');
        
        // Update daily stats
        $daily_stats = json_decode(file_get_contents($this->daily_stats_file), true);
        if (!isset($daily_stats['days'][$today])) {
            $daily_stats['days'][$today] = [
                'total_requests' => 0,
                'successful_requests' => 0,
                'failed_requests' => 0,
                'providers' => [],
                'hourly' => array_fill(0, 24, 0),
                'peak_hour' => null,
                'peak_requests' => 0,
                'response_times' => []
            ];
        }
        
        $daily_stats['days'][$today]['total_requests']++;
        $daily_stats['days'][$today]['hourly'][$hour]++;
        $daily_stats['days'][$today]['response_times'][] = $response_time;
        
        // Update peak hour
        if ($daily_stats['days'][$today]['hourly'][$hour] > $daily_stats['days'][$today]['peak_requests']) {
            $daily_stats['days'][$today]['peak_hour'] = $hour;
            $daily_stats['days'][$today]['peak_requests'] = $daily_stats['days'][$today]['hourly'][$hour];
        }
        if ($success) {
            $daily_stats['days'][$today]['successful_requests']++;
        } else {
            $daily_stats['days'][$today]['failed_requests']++;
        }
        
        if (!isset($daily_stats['days'][$today]['providers'][$provider])) {
            $daily_stats['days'][$today]['providers'][$provider] = [
                'requests' => 0,
                'successes' => 0,
                'failures' => 0,
                'avg_response_time' => 0
            ];
        }
        
        $provider_stats = &$daily_stats['days'][$today]['providers'][$provider];
        $provider_stats['requests']++;
        if ($success) {
            $provider_stats['successes']++;
        } else {
            $provider_stats['failures']++;
        }
        
        // Update average response time
        $provider_stats['avg_response_time'] = (
            ($provider_stats['avg_response_time'] * ($provider_stats['requests'] - 1)) + $response_time
        ) / $provider_stats['requests'];
        
        file_put_contents($this->daily_stats_file, json_encode($daily_stats, JSON_PRETTY_PRINT));
        
        // Update provider health
        $this->updateProviderHealth($provider, $success, $response_time, $error);
    }

    private function updateProviderHealth($provider, $success, $response_time, $error) {
        $health_data = json_decode(file_get_contents($this->provider_health_file), true);
        
        if (!isset($health_data['providers'][$provider])) {
            $health_data['providers'][$provider] = [
                'status' => 'healthy',
                'last_check' => time(),
                'success_rate' => 100,
                'avg_response_time' => 0,
                'recent_errors' => [],
                'consecutive_failures' => 0
            ];
        }
        
        $provider_health = &$health_data['providers'][$provider];
        $provider_health['last_check'] = time();
        
        if ($success) {
            $provider_health['consecutive_failures'] = 0;
        } else {
            $provider_health['consecutive_failures']++;
            array_unshift($provider_health['recent_errors'], [
                'time' => time(),
                'error' => $error
            ]);
            $provider_health['recent_errors'] = array_slice($provider_health['recent_errors'], 0, 5);
        }
        
        // Update status based on health checks
        if ($provider_health['consecutive_failures'] >= 5) {
            $provider_health['status'] = 'critical';
        } elseif ($provider_health['consecutive_failures'] >= 3) {
            $provider_health['status'] = 'warning';
        } else {
            $provider_health['status'] = 'healthy';
        }
        
        file_put_contents($this->provider_health_file, json_encode($health_data, JSON_PRETTY_PRINT));
    }

    public function logVisitor($ip, $user_agent, $country = null) {
        $hour = date('G');
        $referrer = $_SERVER['HTTP_REFERER'] ?? '';
        $device_type = $this->getDeviceType($user_agent);
        
        $today = date('Y-m-d');
        $visitors = json_decode(file_get_contents($this->visitors_file), true);
        
        // Update total visitors
        $visitors['total']++;
        
        // Update daily visitors
        if (!isset($visitors['daily'][$today])) {
            $visitors['daily'][$today] = 0;
        }
        $visitors['daily'][$today]++;
        
        // Update country stats
        if ($country) {
            if (!isset($visitors['countries'][$country])) {
                $visitors['countries'][$country] = 0;
            }
            $visitors['countries'][$country]++;
        }
        
        // Update browser and device stats
        $browser = $this->getBrowserInfo($user_agent);
        $device = $this->getDeviceType($user_agent);
        
        if (!isset($visitors['devices'][$device])) {
            $visitors['devices'][$device] = 0;
        }
        $visitors['devices'][$device]++;
        
        // Track hourly visits
        if (!isset($visitors['hourly'][$hour])) {
            $visitors['hourly'][$hour] = 0;
        }
        $visitors['hourly'][$hour]++;
        
        // Track referrers
        if ($referrer) {
            $domain = parse_url($referrer, PHP_URL_HOST);
            if ($domain) {
                if (!isset($visitors['referrers'][$domain])) {
                    $visitors['referrers'][$domain] = 0;
                }
                $visitors['referrers'][$domain]++;
            }
        }
        if (!isset($visitors['browsers'][$browser])) {
            $visitors['browsers'][$browser] = 0;
        }
        $visitors['browsers'][$browser]++;
        
        file_put_contents($this->visitors_file, json_encode($visitors, JSON_PRETTY_PRINT));
    }

    private function getDeviceType($user_agent) {
        if (preg_match('/(tablet|ipad|playbook|silk)|(android(?!.*mobile))/i', $user_agent)) {
            return 'Tablet';
        }
        if (preg_match('/(Mobile|iPhone|Android|Windows Phone)/i', $user_agent)) {
            return 'Mobile';
        }
        return 'Desktop';
    }

    private function getBrowserInfo($user_agent) {
        if (strpos($user_agent, 'Chrome') !== false) return 'Chrome';
        if (strpos($user_agent, 'Firefox') !== false) return 'Firefox';
        if (strpos($user_agent, 'Safari') !== false) return 'Safari';
        if (strpos($user_agent, 'Edge') !== false) return 'Edge';
        if (strpos($user_agent, 'MSIE') !== false || strpos($user_agent, 'Trident/') !== false) return 'IE';
        return 'Other';
    }

    public function getStats($start_date = null, $end_date = null) {
        $stats = [
            'daily' => json_decode(file_get_contents($this->daily_stats_file), true),
            'health' => json_decode(file_get_contents($this->provider_health_file), true),
            'visitors' => json_decode(file_get_contents($this->visitors_file), true)
        ];
        
        // Filter by date range if provided
        if ($start_date && $end_date) {
            foreach ($stats['daily']['days'] as $date => $day_stats) {
                if ($date < $start_date || $date > $end_date) {
                    unset($stats['daily']['days'][$date]);
                }
            }
            
            // Filter visitor stats
            foreach ($stats['visitors']['daily'] as $date => $count) {
                if ($date < $start_date || $date > $end_date) {
                    unset($stats['visitors']['daily'][$date]);
                }
            }
        }
        
        return $stats;
    }
    
    public function getMetricsByDateRange($start_date, $end_date) {
        return [
            'daily' => json_decode(file_get_contents($this->daily_stats_file), true),
            'health' => json_decode(file_get_contents($this->provider_health_file), true),
            'visitors' => json_decode(file_get_contents($this->visitors_file), true)
        ];
    }

    public function cleanOldStats() {
        $cutoff = date('Y-m-d', strtotime('-30 days'));
        
        // Clean daily stats
        $daily_stats = json_decode(file_get_contents($this->daily_stats_file), true);
        foreach ($daily_stats['days'] as $date => $stats) {
            if ($date < $cutoff) {
                unset($daily_stats['days'][$date]);
            }
        }
        file_put_contents($this->daily_stats_file, json_encode($daily_stats, JSON_PRETTY_PRINT));
        
        // Clean visitor stats
        $visitors = json_decode(file_get_contents($this->visitors_file), true);
        foreach ($visitors['daily'] as $date => $count) {
            if ($date < $cutoff) {
                unset($visitors['daily'][$date]);
            }
        }
        file_put_contents($this->visitors_file, json_encode($visitors, JSON_PRETTY_PRINT));
    }
}
?>
