<?php
class RateLimiter {
    private $cache_dir;
    private $limits = [
        'pinterest-video-downloader1' => ['requests' => 50, 'per_seconds' => 3600], // 50 requests per hour
        'pinterest-downloader2' => ['requests' => 100, 'per_seconds' => 3600],      // 100 requests per hour
        'pinterest-video-api3' => ['requests' => 75, 'per_seconds' => 3600],        // 75 requests per hour
        'pinterest-download-api4' => ['requests' => 80, 'per_seconds' => 3600],     // 80 requests per hour
        'pinterest-media-api5' => ['requests' => 60, 'per_seconds' => 3600],        // 60 requests per hour
        'default' => ['requests' => 50, 'per_seconds' => 3600]                      // Default limit
    ];

    public function __construct() {
        $this->cache_dir = dirname(__DIR__) . '/cache/rate_limits';
        if (!file_exists($this->cache_dir)) {
            mkdir($this->cache_dir, 0755, true);
        }
    }

    public function checkLimit($provider) {
        $limit_file = $this->cache_dir . '/' . $provider . '.json';
        $current_time = time();
        $limit_data = $this->getLimitData($provider);

        // Get provider limits
        $provider_limits = $this->limits[$provider] ?? $this->limits['default'];
        $max_requests = $provider_limits['requests'];
        $time_window = $provider_limits['per_seconds'];

        // Clean up old requests
        $requests = array_filter($limit_data['requests'], function($timestamp) use ($current_time, $time_window) {
            return ($current_time - $timestamp) < $time_window;
        });

        // Check if limit is exceeded
        if (count($requests) >= $max_requests) {
            $oldest_request = min($requests);
            $wait_time = $oldest_request + $time_window - $current_time;
            throw new Exception("Rate limit exceeded for $provider. Please wait $wait_time seconds.");
        }

        // Add new request
        $requests[] = $current_time;
        $this->saveLimitData($provider, ['requests' => $requests]);

        return true;
    }

    private function getLimitData($provider) {
        $limit_file = $this->cache_dir . '/' . $provider . '.json';
        if (file_exists($limit_file)) {
            return json_decode(file_get_contents($limit_file), true);
        }
        return ['requests' => []];
    }

    private function saveLimitData($provider, $data) {
        $limit_file = $this->cache_dir . '/' . $provider . '.json';
        return file_put_contents($limit_file, json_encode($data));
    }

    public function resetLimits() {
        $files = glob($this->cache_dir . '/*.json');
        foreach ($files as $file) {
            unlink($file);
        }
    }
}
?>
