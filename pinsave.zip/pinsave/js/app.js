/**
 * PinSave - Pinterest Video Downloader
 * Client-side JavaScript functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('downloadForm');
    const urlInput = document.getElementById('pinterest-url');
    
    // Form validation
    if (form) {
        form.addEventListener('submit', function(e) {
            const url = urlInput.value.trim();
            
            // Basic validation
            if (!url) {
                e.preventDefault();
                showMessage('Please enter a Pinterest URL', 'error');
                return;
            }
            
            // Check if it's a Pinterest URL (basic check)
            if (!url.includes('pinterest.com')) {
                e.preventDefault();
                showMessage('Please enter a valid Pinterest URL', 'error');
                return;
            }
            
            // Add loading state
            const submitButton = form.querySelector('button[type="submit"]');
            submitButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Processing...';
            submitButton.disabled = true;
        });
    }
    
    // URL paste enhancement
    if (urlInput) {
        // Auto-focus the input field
        urlInput.focus();
        
        // Auto-submit when pasting a valid URL
        urlInput.addEventListener('paste', function(e) {
            setTimeout(() => {
                const pastedUrl = urlInput.value.trim();
                if (pastedUrl && pastedUrl.includes('pinterest.com')) {
                    // Optionally auto-submit the form when a valid URL is pasted
                    // Uncomment the next line to enable auto-submit
                    // form.submit();
                }
            }, 100);
        });
    }
    
    // Helper function to show messages
    function showMessage(message, type = 'info') {
        // Remove any existing message
        const existingMessage = document.querySelector('.message-alert');
        if (existingMessage) {
            existingMessage.remove();
        }
        
        // Create message element
        const messageElement = document.createElement('div');
        messageElement.className = `message-alert ${type === 'error' ? 'bg-red-100 border-red-500 text-red-700' : 'bg-green-100 border-green-500 text-green-700'} border-l-4 p-4 mb-6`;
        messageElement.role = 'alert';
        messageElement.innerHTML = `<p>${message}</p>`;
        
        // Insert after the form
        form.parentNode.insertBefore(messageElement, form.nextSibling);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            messageElement.remove();
        }, 5000);
    }
    
    // Copy download link functionality
    document.addEventListener('click', function(e) {
        if (e.target && e.target.classList.contains('copy-link')) {
            const link = e.target.getAttribute('data-link');
            if (link) {
                navigator.clipboard.writeText(link).then(() => {
                    showMessage('Download link copied to clipboard!', 'info');
                }).catch(err => {
                    console.error('Could not copy text: ', err);
                });
            }
        }
    });
});
