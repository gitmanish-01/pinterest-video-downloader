<?php
require_once __DIR__ . '/../config.php';

// Load DMCA content from admin settings
$pageData = isset($adminConfig['pages']['dmca']) ? $adminConfig['pages']['dmca'] : array();
$pageTitle = isset($pageData['title']) ? $pageData['title'] : 'DMCA Policy';
$metaTitle = isset($pageData['meta_title']) ? $pageData['meta_title'] : 'DMCA Policy - PinSave Pinterest Video Downloader';
$metaDescription = isset($pageData['meta_description']) ? $pageData['meta_description'] : 'Read our DMCA Policy and learn about copyright infringement reporting procedures for PinSave Pinterest video downloader.';
$metaKeywords = isset($pageData['meta_keywords']) ? $pageData['meta_keywords'] : 'pinsave dmca, pinterest video downloader dmca, copyright policy, dmca takedown';

// Set default content if not available in admin settings
$pageContent = isset($pageData['content']) ? $pageData['content'] : '<div class="space-y-6">
    <div>
        <h2><i class="fas fa-balance-scale text-[#E60023]"></i> DMCA Policy</h2>
        <p>PinSave respects the intellectual property rights of others and expects its users to do the same. In accordance with the Digital Millennium Copyright Act (DMCA), we will respond expeditiously to notices of alleged copyright infringement.</p>
    </div>

    <div>
        <h3><i class="fas fa-file-signature text-[#E60023]"></i> Reporting Copyright Infringements</h3>
        <p>If you believe that your work has been copied in a way that constitutes copyright infringement, please provide our copyright agent with the following information:</p>
        <ul>
            <li>A physical or electronic signature of the copyright owner or a person authorized to act on their behalf</li>
            <li>Identification of the copyrighted work claimed to have been infringed</li>
            <li>Identification of the material that is claimed to be infringing or to be the subject of infringing activity</li>
            <li>Your contact information, including your address, telephone number, and email</li>
            <li>A statement by you that you have a good faith belief that use of the material in the manner complained of is not authorized by the copyright owner, its agent, or the law</li>
            <li>A statement that the information in the notification is accurate, and, under penalty of perjury, that you are authorized to act on behalf of the copyright owner</li>
        </ul>
    </div>

    <div>
        <h3><i class="fas fa-envelope text-[#E60023]"></i> Contact Information</h3>
        <div>
            <p><strong>Email:</strong> dmca@pinsave.in</p>
            <p><strong>Address:</strong> [Your Business Address]</p>
        </div>
    </div>

    <div>
        <h3><i class="fas fa-exclamation-triangle text-[#E60023]"></i> Counter-Notification</h3>
        <p>If you believe your material was removed by mistake or misidentification, you can file a counter-notification by providing our agent with the following information:</p>
        <ul>
            <li>Your physical or electronic signature</li>
            <li>Identification of the material removed and its previous location</li>
            <li>A statement under penalty of perjury that you have a good faith belief that the material was removed or misidentified</li>
            <li>Your name, address, and telephone number, and a statement that you consent to the jurisdiction of the Federal District Court for the judicial district in which your address is located</li>
        </ul>
    </div>

    <div>
        <h3><i class="fas fa-info-circle text-[#E60023]"></i> Policy Updates</h3>
        <p>We reserve the right to update this DMCA policy at any time without prior notice. Changes will be effective immediately upon posting on our website.</p>
        <p>This DMCA policy is provided for informational purposes and does not constitute legal advice. We recommend consulting with a legal professional for specific guidance regarding copyright matters.</p>
    </div>
</div>';

// Include header
require_once __DIR__ . '/../header.php';
?>

<style>
    .prose h2, .prose h3 {
        margin-top: 1.5rem;
        margin-bottom: 1rem;
        font-weight: 600;
    }
    .prose h2 {
        font-size: 1.75rem;
    }
    .prose h3 {
        font-size: 1.25rem;
    }
    .prose ul {
        list-style-type: disc;
        padding-left: 1.5rem;
        margin-top: 0.5rem;
        margin-bottom: 0.5rem;
    }
    .prose p {
        margin-top: 0.5rem;
        margin-bottom: 0.5rem;
    }
</style>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-6">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">
            <i class="fas fa-gavel text-[#E60023] mr-2"></i><?php echo htmlspecialchars($pageTitle); ?>
        </h1>
        <div class="prose max-w-none text-gray-700 leading-relaxed">
            <?php echo $pageContent; ?>
        </div>
    </div>
</div>

<?php
// Include footer
require_once __DIR__ . '/../footer.php';
?>
