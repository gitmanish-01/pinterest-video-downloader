<?php
require_once __DIR__ . '/../config.php';

// Load page content from admin settings
$pageData = isset($adminConfig['pages']['about']) ? $adminConfig['pages']['about'] : array();
$pageTitle = isset($pageData['title']) ? $pageData['title'] : 'About Us';
$metaTitle = isset($pageData['meta_title']) ? $pageData['meta_title'] : 'About Us - PinSave Pinterest Video Downloader';
$metaDescription = isset($pageData['meta_description']) ? $pageData['meta_description'] : 'PinSave is a free tool to download Pinterest videos in HD without watermark. Learn more about our features, mission, and privacy-first approach.';
$metaKeywords = isset($pageData['meta_keywords']) ? $pageData['meta_keywords'] : 'about pinsave, pinterest video downloader, hd video save, download pinterest video';

// Include default content file
require_once __DIR__ . '/../includes/default_content.php';

// About page content from admin panel or default content

$pageContent = isset($pageData['content']) ? $pageData['content'] : $defaultAboutContent;

// Include header
require_once __DIR__ . '/../header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-6">
        <h1 class="text-3xl font-bold text-gray-800 mb-6"><i class="fas fa-users text-red-600 mr-2"></i><?php echo htmlspecialchars($pageTitle); ?></h1>
        <div class="prose max-w-none text-gray-700 leading-relaxed">
            <?php echo $pageContent; ?>
        </div>
    </div>
</div>

<?php
// Include footer
require_once __DIR__ . '/../footer.php';
?>
