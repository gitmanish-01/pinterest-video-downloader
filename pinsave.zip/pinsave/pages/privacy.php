<?php
// Include configuration
require_once __DIR__ . '/../config.php';

// Get page content from admin config
$pageData = isset($adminConfig['pages']['privacy']) ? $adminConfig['pages']['privacy'] : array();
$pageTitle = isset($pageData['title']) ? $pageData['title'] : 'Privacy Policy';
$metaTitle = isset($pageData['meta_title']) ? $pageData['meta_title'] : 'Privacy Policy - PinSave Pinterest Video Downloader';
$metaDescription = isset($pageData['meta_description']) ? $pageData['meta_description'] : 'Read about how PinSave handles your data and protects your privacy when using our Pinterest video downloader tool.';
$metaKeywords = isset($pageData['meta_keywords']) ? $pageData['meta_keywords'] : 'pinsave privacy policy, pinterest video downloader privacy, data protection';

// Privacy policy content
$pageContent = isset($pageData['content']) ? $pageData['content'] : '<h2>Privacy Policy for PinSave</h2>
<p>Last Updated: ' . date('F d, Y') . '</p>

<p>At PinSave, we respect your privacy and are committed to protecting your personal data. This Privacy Policy explains how we collect, use, and safeguard your information when you use our Pinterest video downloader service.</p>

<h3>Information We Collect</h3>
<p>When you use PinSave, we may collect the following information:</p>
<ul>
    <li>Pinterest URLs you submit for video downloading</li>
    <li>IP address and browser information</li>
    <li>Usage data and analytics</li>
</ul>

<h3>How We Use Your Information</h3>
<p>We use the collected information for the following purposes:</p>
<ul>
    <li>To provide and maintain our service</li>
    <li>To improve and optimize our website</li>
    <li>To monitor usage and prevent abuse</li>
</ul>

<h3>Cookies and Tracking</h3>
<p>We use cookies and similar tracking technologies to track activity on our website and hold certain information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent.</p>

<h3>Third-Party Services</h3>
<p>We may employ third-party companies and individuals to facilitate our service, provide service-related assistance, or assist us in analyzing how our service is used.</p>

<h3>Data Security</h3>
<p>The security of your data is important to us, but remember that no method of transmission over the Internet or method of electronic storage is 100% secure.</p>

<h3>Changes to This Privacy Policy</h3>
<p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.</p>

<h3>Contact Us</h3>
<p>If you have any questions about this Privacy Policy, please contact us at <a href="contact.php" class="text-[#E60023] hover:underline">our contact page</a>.</p>';

// Include header
require_once __DIR__ . '/../header.php';
?>

<style>
    .prose h2 {
        font-size: 1.5rem;
        font-weight: 700;
        margin-top: 1.5rem;
        margin-bottom: 1rem;
    }
    .prose h3 {
        font-size: 1.25rem;
        font-weight: 600;
        margin-top: 1.25rem;
        margin-bottom: 0.75rem;
    }
    .prose ul {
        list-style-type: disc;
        padding-left: 1.5rem;
        margin-top: 0.5rem;
        margin-bottom: 0.5rem;
    }
    .prose p {
        margin-top: 0.5rem;
        margin-bottom: 0.5rem;
    }
</style>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-6">
        <h1 class="text-3xl font-bold text-gray-800 mb-6"><i class="fas fa-shield-alt text-[#E60023] mr-2"></i><?php echo htmlspecialchars($pageTitle); ?></h1>
        <div class="prose max-w-none">
            <?php echo $pageContent; ?>
        </div>
    </div>
</div>

<?php
// Include footer
require_once __DIR__ . '/../footer.php';
?>
