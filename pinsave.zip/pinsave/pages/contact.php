<?php
require_once __DIR__ . '/../config.php';

// Load page content from admin settings
$pageData = isset($adminConfig['pages']['contact']) ? $adminConfig['pages']['contact'] : array();
$pageTitle = isset($pageData['title']) ? $pageData['title'] : 'Contact Us';
$metaTitle = isset($pageData['meta_title']) ? $pageData['meta_title'] : 'Contact Us - PinSave Pinterest Video Downloader';
$metaDescription = isset($pageData['meta_description']) ? $pageData['meta_description'] : 'Contact the PinSave team for support, feedback, or inquiries about our Pinterest video downloader tool.';
$metaKeywords = isset($pageData['meta_keywords']) ? $pageData['meta_keywords'] : 'contact pinsave, pinterest video downloader support, pinterest video saver contact';
$contactEmail = isset($pageData['email']) ? $pageData['email'] : 'support@pinsave.in';
$pageBody = isset($pageData['body']) ? $pageData['body'] : 'Have questions or feedback? We\'d love to hear from you. Fill out the form below to get in touch with our team.';

// Handle form submission
$success = false;
$error = '';
$name = '';
$email = '';
$subject = '';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (empty($name)) {
        $error = 'Please enter your name.';
    } elseif (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (empty($subject)) {
        $error = 'Please enter a subject.';
    } elseif (empty($message)) {
        $error = 'Please enter your message.';
    } else {
        $success = true;
        $name = $email = $subject = $message = '';
    }
}

// Include header
require_once __DIR__ . '/../header.php';
?>

<style>
    .contact-form input:focus, .contact-form textarea:focus {
        outline: none;
        border-color: #E60023;
    }
</style>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-6">
        <h1 class="text-3xl font-bold text-gray-800 mb-4">
            <i class="fas fa-envelope text-[#E60023] mr-2"></i><?php echo htmlspecialchars($pageTitle); ?>
        </h1>
        
        <p class="text-gray-600 mb-6"><?php echo $pageBody; ?></p>
        
        <?php if ($success): ?>
            <div class="bg-green-100 text-green-700 px-4 py-3 mb-6 rounded">Your message has been sent successfully!</div>
        <?php elseif ($error): ?>
            <div class="bg-red-100 text-red-700 px-4 py-3 mb-6 rounded"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="grid md:grid-cols-2 gap-8">
            <!-- Contact Form -->
            <form method="POST" class="space-y-4 contact-form">
                <input type="text" name="name" placeholder="Your Name" value="<?php echo htmlspecialchars($name); ?>" 
                    class="w-full px-4 py-3 border rounded focus:ring-2 focus:ring-[#E60023]" required>
                
                <input type="email" name="email" placeholder="Your Email" value="<?php echo htmlspecialchars($email); ?>" 
                    class="w-full px-4 py-3 border rounded focus:ring-2 focus:ring-[#E60023]" required>
                
                <input type="text" name="subject" placeholder="Subject" value="<?php echo htmlspecialchars($subject); ?>" 
                    class="w-full px-4 py-3 border rounded focus:ring-2 focus:ring-[#E60023]" required>
                
                <textarea name="message" rows="5" placeholder="Your Message" 
                    class="w-full px-4 py-3 border rounded focus:ring-2 focus:ring-[#E60023]" required><?php echo htmlspecialchars($message); ?></textarea>
                
                <button type="submit" class="bg-[#E60023] text-white px-6 py-2 rounded hover:bg-[#D50021]">
                    <i class="fas fa-paper-plane mr-2"></i> Send Message
                </button>
            </form>

            <!-- Contact Info -->
            <div class="space-y-6">
                <div class="flex items-start">
                    <i class="fas fa-envelope text-[#E60023] text-xl mr-3 mt-1"></i>
                    <div>
                        <h3 class="font-semibold text-gray-700">Email Us</h3>
                        <p><a href="mailto:<?php echo htmlspecialchars($contactEmail); ?>" class="text-[#E60023] hover:underline"><?php echo htmlspecialchars($contactEmail); ?></a></p>
                    </div>
                </div>
                <div class="flex items-start">
                    <i class="fas fa-map-marker-alt text-[#E60023] text-xl mr-3 mt-1"></i>
                    <div>
                        <h3 class="font-semibold text-gray-700">Location</h3>
                        <p>India (Remote Support)</p>
                    </div>
                </div>
                <div class="flex items-start">
                    <i class="fas fa-clock text-[#E60023] text-xl mr-3 mt-1"></i>
                    <div>
                        <h3 class="font-semibold text-gray-700">Support Hours</h3>
                        <p>Mon - Sat: 10:00 AM - 6:00 PM IST</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
require_once __DIR__ . '/../footer.php';
?>
