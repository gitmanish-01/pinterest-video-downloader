<?php
require_once __DIR__ . '/../config.php';

// Load FAQ content from admin settings
$pageData = isset($adminConfig['pages']['faq']) ? $adminConfig['pages']['faq'] : array();
$pageTitle = isset($pageData['title']) ? $pageData['title'] : 'Frequently Asked Questions';
$metaTitle = isset($pageData['meta_title']) ? $pageData['meta_title'] : 'FAQ - PinSave Pinterest Video Downloader';
$metaDescription = isset($pageData['meta_description']) ? $pageData['meta_description'] : 'Frequently asked questions about using PinSave Pinterest video downloader. Learn how to download Pinterest videos easily.';
$metaKeywords = isset($pageData['meta_keywords']) ? $pageData['meta_keywords'] : 'pinsave faq, pinterest video downloader help, how to download pinterest videos, pinterest video download guide';

// FAQ content
$pageContent = isset($pageData['content']) ? $pageData['content'] : '<h2><i class="fas fa-question-circle text-[#E60023]"></i> Frequently Asked Questions</h2>
<p class="mb-6">Find answers to commonly asked questions about PinSave and our Pinterest video downloading service.</p>

<div class="space-y-6">
    <div>
        <h3><i class="fas fa-download text-[#E60023]"></i> How do I download a Pinterest video?</h3>
        <p>Simply copy the Pinterest video URL and paste it into our downloader tool. Click the "Download" button and wait for the video to process. Once ready, click the download button to save the video to your device.</p>
    </div>

    <div>
        <h3><i class="fas fa-link text-[#E60023]"></i> What Pinterest URLs are supported?</h3>
        <p>We support all Pinterest video URLs, including:</p>
        <ul>
            <li>Regular Pinterest URLs (pinterest.com/pin/...)</li>
            <li>Short URLs (pin.it/...)</li>
            <li>Mobile URLs (pinterest.com/pin/...)</li>
        </ul>
    </div>

    <div>
        <h3><i class="fas fa-video text-[#E60023]"></i> What is the maximum video quality available?</h3>
        <p>We provide the highest quality version available from Pinterest. The actual quality depends on the original video uploaded to Pinterest.</p>
    </div>

    <div>
        <h3><i class="fas fa-mobile-alt text-[#E60023]"></i> Can I download videos on mobile devices?</h3>
        <p>Yes, PinSave works on all devices including smartphones and tablets. Our website is fully mobile-responsive.</p>
    </div>

    <div>
        <h3><i class="fas fa-dollar-sign text-[#E60023]"></i> Is PinSave free to use?</h3>
        <p>Yes, PinSave is completely free to use. There are no hidden charges or subscription fees.</p>
    </div>

    <div>
        <h3><i class="fas fa-shield-alt text-[#E60023]"></i> Is it legal to download Pinterest videos?</h3>
        <p>PinSave is designed for downloading videos for personal use only. Please respect copyright laws and Pinterest\'s terms of service. Do not use downloaded videos for commercial purposes without proper authorization.</p>
    </div>

    <div>
        <h3><i class="fas fa-exclamation-circle text-[#E60023]"></i> Why isn\'t the download working?</h3>
        <p>If you\'re having trouble, try these steps:</p>
        <ul>
            <li>Verify that the URL is correct and contains a video</li>
            <li>Make sure the video is publicly accessible</li>
            <li>Try refreshing the page</li>
            <li>Contact our support if the issue persists</li>
        </ul>
    </div>

    <div>
        <h3><i class="fas fa-clock text-[#E60023]"></i> How long are downloaded videos stored?</h3>
        <p>We don\'t store downloaded videos on our servers. Videos are processed in real-time and delivered directly to your device.</p>
    </div>
</div>';

// Include header
require_once __DIR__ . '/../header.php';
?>

<style>
    .prose h2, .prose h3 {
        margin-top: 1.5rem;
        margin-bottom: 1rem;
        font-weight: 600;
    }
    .prose h2 {
        font-size: 1.75rem;
    }
    .prose h3 {
        font-size: 1.25rem;
    }
    .prose ul {
        list-style-type: disc;
        padding-left: 1.5rem;
        margin-top: 0.5rem;
        margin-bottom: 0.5rem;
    }
    .prose p {
        margin-top: 0.5rem;
        margin-bottom: 0.5rem;
    }
</style>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-6">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">
            <i class="fas fa-question-circle text-[#E60023] mr-2"></i><?php echo htmlspecialchars($pageTitle); ?>
        </h1>
        <div class="prose max-w-none text-gray-700 leading-relaxed">
            <?php echo $pageContent; ?>
        </div>
    </div>
</div>

<?php
// Include footer
require_once __DIR__ . '/../footer.php';
?>
