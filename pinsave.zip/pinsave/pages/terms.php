<?php
require_once __DIR__ . '/../config.php';

// Load Terms of Service content from admin settings
$pageData = isset($adminConfig['pages']['terms']) ? $adminConfig['pages']['terms'] : array();
$pageTitle = isset($pageData['title']) ? $pageData['title'] : 'Terms of Service';
$metaTitle = isset($pageData['meta_title']) ? $pageData['meta_title'] : 'Terms of Service - PinSave Pinterest Video Downloader';
$metaDescription = isset($pageData['meta_description']) ? $pageData['meta_description'] : 'Read the Terms of Service for using PinSave, the free Pinterest video downloader tool.';
$metaKeywords = isset($pageData['meta_keywords']) ? $pageData['meta_keywords'] : 'pinsave terms, pinterest video downloader terms, terms of service, pinterest video saver terms';

// Terms of Service content
$pageContent = isset($pageData['content']) ? $pageData['content'] : '<h2><i class="fas fa-file-contract text-[#E60023]"></i> Terms of Service for PinSave</h2>
<p><strong>Last Updated:</strong> ' . date('F d, Y') . '</p>

<p>Welcome to PinSave. By accessing or using our website, you agree to be bound by these Terms of Service.</p>

<h3><i class="fas fa-check-circle text-[#E60023]"></i> 1. Acceptance of Terms</h3>
<p>By using PinSave, you agree to be bound by these Terms and all applicable laws. If you do not agree, please do not use the site.</p>

<h3><i class="fas fa-user-shield text-[#E60023]"></i> 2. Use License</h3>
<p>You are granted a temporary license to use our materials for personal, non-commercial use. Under this license, you may NOT:</p>
<ul>
    <li>Modify or copy the materials</li>
    <li>Use for commercial purposes</li>
    <li>Reverse engineer any software on the site</li>
    <li>Remove copyright notices</li>
    <li>Mirror the materials on other servers</li>
</ul>

<h3><i class="fas fa-exclamation-triangle text-yellow-500"></i> 3. Disclaimer</h3>
<p>PinSave provides materials "as is" without warranties. We disclaim all warranties including merchantability and fitness for a particular purpose.</p>

<h3><i class="fas fa-ban text-red-500"></i> 4. Limitations</h3>
<p>PinSave is not liable for any damages arising from use or inability to use our tools.</p>

<h3><i class="fas fa-search text-[#E60023]"></i> 5. Accuracy of Materials</h3>
<p>Content may contain technical or typographical errors. We may update content at any time without notice.</p>

<h3><i class="fas fa-link text-green-600"></i> 6. Links</h3>
<p>We are not responsible for content on third-party websites linked from PinSave.</p>

<h3><i class="fas fa-edit text-purple-600"></i> 7. Modifications</h3>
<p>We may revise these terms without notice. By continuing to use the site, you agree to the current version.</p>

<h3><i class="fas fa-gavel text-gray-700"></i> 8. Governing Law</h3>
<p>These terms are governed by applicable laws. Disputes shall be resolved in appropriate local courts.</p>

<h3><i class="fas fa-shield-alt text-indigo-500"></i> 9. DMCA Compliance</h3>
<p>If you believe your copyrighted work is being used unlawfully, please contact us using our <a href="contact.php" class="text-[#E60023] hover:underline">Contact page</a>.</p>';

// Include header
require_once __DIR__ . '/../header.php';
?>

<style>
  .prose h2, .prose h3 {
    margin-top: 1.5rem;
    margin-bottom: 1rem;
    font-weight: 600;
  }
  .prose h2 {
    font-size: 1.75rem;
  }
  .prose h3 {
    font-size: 1.25rem;
  }
  .prose ul {
    list-style-type: disc;
    padding-left: 1.5rem;
    margin-top: 0.5rem;
    margin-bottom: 0.5rem;
  }
  .prose p {
    margin-top: 0.5rem;
    margin-bottom: 0.5rem;
  }
</style>

<div class="container mx-auto px-4 py-8">
  <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-6">
    <h1 class="text-3xl font-bold text-gray-800 mb-6"><i class="fas fa-scroll text-[#E60023] mr-2"></i><?php echo htmlspecialchars($pageTitle); ?></h1>
    <div class="prose max-w-none text-gray-700 leading-relaxed">
      <?php echo $pageContent; ?>
    </div>
  </div>
</div>

<?php
// Include footer
require_once __DIR__ . '/../footer.php';
?>
