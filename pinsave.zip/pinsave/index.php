<?php
// Include configuration
require_once 'config.php';
require_once 'includes/stats_handler.php';

// Track visitor
$stats_handler = new StatsHandler();
$ip = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$country = null;

// Get country from IP (you can use a GeoIP service here)
if (isset($_SERVER['HTTP_CF_IPCOUNTRY'])) { // If using Cloudflare
    $country = $_SERVER['HTTP_CF_IPCOUNTRY'];
}

$stats_handler->logVisitor($ip, $user_agent, $country);

// Initialize variables
$videoUrl = "";
$error = "";
$debug = "";
$thumbnail = "";
$title = "";

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['url'])) {
    $pinterestUrl = trim($_POST['url']);
    
    // Validate URL (basic check for Pinterest URL)
    if (strpos($pinterestUrl, 'pinterest.com') !== false || strpos($pinterestUrl, 'pin.it') !== false) {
        // API call function
        require_once 'api/pinterest_api_handler.php';
        $apiHandler = new PinSave\Api\PinterestApiHandler();
        $result = $apiHandler->getVideoData($pinterestUrl);
        
        if (isset($result['success']) && $result['success']) {
            $videoUrl = $result['video_url'];
            $thumbnail = $result['thumbnail'] ?? '';
            $title = $result['title'] ?? 'Pinterest Video';
        } else {
            $error = $result['message'] ?? "Failed to fetch video data. Please try again.";
            
            // Show debug info if available and debug mode is on
            if (defined('DEBUG_MODE') && DEBUG_MODE && isset($result['debug'])) {
                $debug = '<pre class="mt-4 p-3 bg-gray-800 text-white text-xs overflow-auto max-h-40 rounded">' . 
                         htmlspecialchars(print_r($result['debug'], true)) . 
                         '</pre>';
            }
        }
    } else {
        $error = "Please enter a valid Pinterest URL (pinterest.com or pin.it)";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Primary SEO Meta Tags -->
    <title>PinSave - Free Pinterest Video Downloader | Download Videos in HD Without Watermark</title>
    <meta name="description" content="PinSave is the best free Pinterest video downloader. Download Pinterest videos in HD without watermark. Save videos from Pinterest to your device quickly and easily.">
    <meta name="keywords" content="Pinterest video downloader, Pinterest image downloader, download Pinterest videos, Pinterest downloader, Pinterest video download HD, Pinterest downloader APK, Pinterest video download status, Pinterest downloader Chrome, Pinterest downloader PDF, Pinterest video iPhone, Pinterest video PC, download Pinterest video Android, Pinterest gallery download, Pinterest to gallery, save Pinterest video gallery, download Pinterest images, Pinterest photo download, how to download Pinterest videos, how to download video from Pinterest, save Pinterest videos without watermark, download Pinterest videos in HD, free Pinterest video downloader, Pinterest video downloader without watermark, Pinterest video saver online">
    
    <!-- Admin Panel Link (visible only in debug mode) -->
    <?php if (defined('DEBUG_MODE') && DEBUG_MODE): ?>
    <meta name="robots" content="noindex, nofollow">
    <?php endif; ?>
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>">
    <meta property="og:title" content="PinSave - Free Pinterest Video Downloader | Download Videos in HD Without Watermark">
    <meta property="og:description" content="PinSave is the best free Pinterest video downloader. Download Pinterest videos in HD without watermark. Save videos from Pinterest to your device quickly and easily.">
    <meta property="og:image" content="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']; ?>/img/pinsave-preview.jpg">
    
    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>">
    <meta property="twitter:title" content="PinSave - Free Pinterest Video Downloader | Download Videos in HD Without Watermark">
    <meta property="twitter:description" content="PinSave is the best free Pinterest video downloader. Download Pinterest videos in HD without watermark. Save videos from Pinterest to your device quickly and easily.">
    <meta property="twitter:image" content="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']; ?>/img/pinsave-preview.jpg">
    
    <!-- Canonical URL -->
    <link rel="canonical" href="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']; ?>/">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="pinlogo.png">
    
    <!-- Stylesheets -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Mobile Navigation Styles */
        @media (max-width: 1023px) {
            #nav-items {
                background: white;
                position: absolute;
                left: 0;
                right: 0;
                top: 100%;
                z-index: 50;
                padding: 1rem;
                border-bottom: 1px solid #e5e7eb;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            }
            
            .group > div {
                position: static !important;
                width: 100% !important;
                margin-top: 0.5rem !important;
                box-shadow: none !important;
            }
            
            .group > button {
                width: 100%;
                text-align: left;
                justify-content: space-between;
            }
            
            .group > div a {
                padding: 0.75rem 1rem;
            }
        }
        
        /* Smooth Transitions */
        #nav-items, .group > div {
            transition: all 0.3s ease-in-out;
        }
        
        /* Active States */
        .nav-item-active {
            color: #2563eb; /* blue-600 */
            background-color: #f3f4f6; /* gray-100 */
        }
    </style>
    <script src="js/app.js" defer></script>
    
    <script>
        function copyToClipboard(elementId) {
            const element = document.getElementById(elementId);
            if (!element) return;
            
            element.select();
            element.setSelectionRange(0, 99999); // For mobile devices
            
            try {
                document.execCommand('copy');
                // Optional: Show a copied confirmation
                const button = document.activeElement;
                if (button) {
                    const originalText = button.innerHTML;
                    button.innerHTML = '<i class="fas fa-check"></i>';
                    setTimeout(() => {
                        button.innerHTML = originalText;
                    }, 1500);
                }
            } catch (err) {
                console.error('Failed to copy text: ', err);
            }
        }
    </script>
    
    <?php if ($ezoicAdsEnabled && !empty($ezoicScript)): ?>
    <!-- Ezoic Ad Integration -->
    <?php echo $ezoicScript; ?>
    <?php endif; ?>
    
    <?php if ($googleAdsEnabled && !empty($googleAdsPublisherId)): ?>
    <!-- Google AdSense -->
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=<?php echo htmlspecialchars($googleAdsPublisherId); ?>" crossorigin="anonymous"></script>
    <?php if (isset($adminConfig['ads']['google_ads']['auto_ads_enabled']) && $adminConfig['ads']['google_ads']['auto_ads_enabled']): ?>
    <script>
        (adsbygoogle = window.adsbygoogle || []).push({
            google_ad_client: "<?php echo htmlspecialchars($googleAdsPublisherId); ?>",
            enable_page_level_ads: true
        });
    </script>
    <?php endif; ?>
    <?php endif; ?>
</head>
<body class="bg-gray-100 min-h-screen">
    <!-- JSON-LD structured data for SEO -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        "name": "PinSave - Pinterest Video Downloader",
        "url": "<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']; ?>/",
        "description": "Free online tool to download Pinterest videos and images in HD quality without watermark. Works with all Pinterest content types.",
        "applicationCategory": "DownloadApplication",
        "operatingSystem": "Any",
        "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "USD"
        },
        "keywords": "Pinterest video downloader, Pinterest image downloader, download Pinterest videos, Pinterest downloader, Pinterest video download HD, Pinterest downloader APK, Pinterest video download status, Pinterest downloader Chrome, Pinterest video iPhone, Pinterest video PC, download Pinterest video Android, Pinterest gallery download, Pinterest to gallery, save Pinterest video gallery, download Pinterest images, Pinterest photo download, how to download Pinterest videos",
        "potentialAction": {
            "@type": "SearchAction",
            "target": "<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']; ?>/?url={search_term_string}",
            "query-input": "required name=search_term_string"
        },
        "sameAs": [
            "https://pinsave.in/"
        ]
    }
    </script>
    
    <div class="container mx-auto px-4 py-8">
        <!-- Navigation Menu -->
        <nav class="bg-white shadow-md rounded-lg mb-8">
            <div class="container mx-auto px-4">
                <!-- Mobile Menu Button and Logo -->
                <div class="flex justify-between items-center py-3 lg:hidden">
                    <!-- Logo -->
                    <a href="/pinsave/" class="flex items-center">
                        <img src="/host/pinsave/img/logo.svg" alt="PinSave" class="h-8 w-auto mr-2">
                        <span class="text-xl font-bold text-[#E60023]">PinSave</span>
                    </a>

                    <!-- Mobile Menu Button -->
                    <button class="text-gray-600 hover:text-blue-600" id="mobileMenuBtn">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path>
                        </svg>
                    </button>
                </div>

                <!-- Desktop/Mobile Menu Items -->
                <div class="flex justify-between items-center w-full py-3">
                    <!-- Logo on the left -->
                    <a href="/pinsave/" class="flex items-center">
                        <img src="/host/pinsave/img/logo.svg" alt="PinSave" class="h-8 w-auto mr-2">
                        <span class="text-xl font-bold text-[#E60023]">PinSave</span>
                    </a>

                    <!-- Navigation items on the right -->
                    <div id="nav-items" class="hidden lg:flex items-center space-x-6">
                        <a href="/pinsave/" class="text-gray-700 hover:text-[#E60023] px-3 py-2 rounded-md text-sm font-medium">Home</a>
                        <a href="/pinsave/pages/about.php" class="text-gray-700 hover:text-[#E60023] px-3 py-2 rounded-md text-sm font-medium">About</a>
                        <a href="/pinsave/blog.php" class="text-gray-700 hover:text-[#E60023] px-3 py-2 rounded-md text-sm font-medium">Blog</a>
                        <a href="/pinsave/pages/faq.php" class="text-gray-700 hover:text-[#E60023] px-3 py-2 rounded-md text-sm font-medium">FAQ</a>
                        <a href="/pinsave/pages/contact.php" class="text-gray-700 hover:text-[#E60023] px-3 py-2 rounded-md text-sm font-medium">Contact</a>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Mobile Menu -->
        <div class="lg:hidden">
            <div id="mobileMenu" class="hidden bg-white border-t border-gray-200 py-2">
                <div class="container mx-auto px-4 space-y-1">
                    <a href="/pinsave/" class="block px-3 py-2 text-blue-600 hover:text-blue-800 font-medium">Home</a>
                    <a href="/pinsave/pages/about.php" class="block px-3 py-2 text-blue-600 hover:text-blue-800 font-medium">About</a>
                    <a href="/pinsave/blog.php" class="block px-3 py-2 text-blue-600 hover:text-blue-800 font-medium">Blog</a>
                    <a href="/pinsave/pages/faq.php" class="block px-3 py-2 text-blue-600 hover:text-blue-800 font-medium">FAQ</a>
                    <a href="/pinsave/pages/contact.php" class="block px-3 py-2 text-blue-600 hover:text-blue-800 font-medium">Contact</a>
                </div>
            </div>
        </div>

        <!-- Mobile Menu Script -->
        <script>
            // Execute immediately without waiting for DOMContentLoaded
            (function() {
                // Wait a small amount of time to ensure elements are available
                setTimeout(function() {
                    const mobileMenuButton = document.getElementById('mobile-menu-button');
                    if (!mobileMenuButton) {
                        console.error('Mobile menu button not found');
                        return;
                    }
                    
                    const navItems = document.getElementById('nav-items');
                    const menuOpen = mobileMenuButton.querySelector('.menu-open');
                    const menuClose = mobileMenuButton.querySelector('.menu-close');
                    let isOpen = false;
                    
                    console.log('Mobile menu initialized');
                    
                    // Toggle mobile menu with direct event handler
                    mobileMenuButton.onclick = function() {
                        console.log('Mobile menu clicked');
                        isOpen = !isOpen;
                        navItems.classList.toggle('hidden');
                        menuOpen.classList.toggle('hidden');
                        menuClose.classList.toggle('hidden');
                    };

                // Handle dropdowns in mobile view
                const dropdownButtons = document.querySelectorAll('.group > button');
                dropdownButtons.forEach(button => {
                    button.addEventListener('click', function(e) {
                        if (window.innerWidth < 1024) { // lg breakpoint
                            e.preventDefault();
                            const dropdown = this.nextElementSibling;
                            dropdown.classList.toggle('invisible');
                            dropdown.classList.toggle('opacity-0');
                        }
                    });
                });

                // Close mobile menu on window resize
                window.addEventListener('resize', function() {
                    if (window.innerWidth >= 1024) { // lg breakpoint
                        navItems.classList.remove('hidden');
                        if (isOpen) {
                            menuOpen.classList.remove('hidden');
                            menuClose.classList.add('hidden');
                            isOpen = false;
                        }
                    }
                });

                // Close dropdowns when clicking outside
                document.addEventListener('click', function(e) {
                    if (!e.target.closest('.group')) {
                        document.querySelectorAll('.group > div').forEach(dropdown => {
                            if (window.innerWidth >= 1024) {
                                dropdown.classList.add('invisible', 'opacity-0');
                            }
                        });
                    }
                });
            });
        </script>
        
        <!-- Main Header -->
        <header class="text-center mb-8">
            <div class="flex flex-col items-center justify-center mb-4">
                <img src="pinlogo.png" alt="PinSave Logo" class="h-16 mb-3">
                <h1 class="text-3xl font-bold text-blue-600"><?php echo htmlspecialchars($seoH1); ?></h1>
                <p class="text-gray-600">Download Pinterest Videos in HD Quality Without Watermark</p>
            </div>
            <?php if (defined('DEBUG_MODE') && DEBUG_MODE): ?>
            <div class="mt-2">
                <a href="admin/login.php" class="text-sm text-blue-500 hover:underline">Admin Panel</a>
            </div>
            <?php endif; ?>
        </header>
        
        <?php if ($googleAdsEnabled && !empty($googleAdsSlotTop)): ?>
        <!-- Google Ad - Top -->
        <div class="mb-6 text-center">
            <ins class="adsbygoogle"
                 style="display:block"
                 data-ad-client="<?php echo htmlspecialchars($googleAdsPublisherId); ?>"
                 data-ad-slot="<?php echo htmlspecialchars($googleAdsSlotTop); ?>"
                 data-ad-format="auto"
                 data-full-width-responsive="true"></ins>
            <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
        </div>
        <?php endif; ?>

        <!-- Main Content -->
        <div class="max-w-3xl mx-auto bg-white rounded-lg shadow-md p-6">
            <form id="downloadForm" method="POST" action="" class="mb-6">
                <div class="flex flex-col md:flex-row gap-4">
                    <input 
                        type="text" 
                        name="url" 
                        id="pinterest-url" 
                        placeholder="Paste Pinterest video URL here" 
                        value="<?php echo htmlspecialchars($videoUrl); ?>"
                        class="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                        required
                    >
                    <button 
                        type="submit" 
                        class="bg-red-600 hover:bg-red-700 text-white font-medium py-3 px-6 rounded-lg transition duration-300"
                    >
                        Download Video
                    </button>
                </div>
            </form>

            <?php if ($error): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p class="font-medium"><?php echo $error; ?></p>
                    <?php if (strpos($error, 'Could not extract video URL') !== false): ?>
                        <div class="mt-3 text-sm">
                            <p class="font-medium">Troubleshooting tips:</p>
                            <ul class="list-disc pl-5 mt-1 space-y-1">
                                <li>Make sure the Pinterest URL contains a video (not just an image)</li>
                                <li>Try using the full Pinterest URL (starts with https://www.pinterest.com/pin/...)</li>
                                <li>Check if the Pinterest post is public and not private</li>
                                <li>Try copying the URL directly from your browser address bar</li>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <?php echo $debug; ?>
                </div>
            <?php endif; ?>

            <?php if ($googleAdsEnabled && !empty($googleAdsSlotSidebar)): ?>
            <!-- Google Ad - Sidebar -->
            <div class="mb-6 text-center">
                <ins class="adsbygoogle"
                     style="display:block"
                     data-ad-client="<?php echo htmlspecialchars($googleAdsPublisherId); ?>"
                     data-ad-slot="<?php echo htmlspecialchars($googleAdsSlotSidebar); ?>"
                     data-ad-format="auto"
                     data-full-width-responsive="true"></ins>
                <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
            </div>
            <?php endif; ?>
            
            <?php if ($videoUrl): ?>
                <div class="bg-white p-6 rounded-lg shadow-md mb-6">
                    <h2 class="text-xl font-semibold mb-4">Video Preview</h2>
                    
                    <div class="flex flex-col md:flex-row gap-4">
                        <!-- Thumbnail and Video Preview -->
                        <div class="md:w-1/2">
                            <?php if (!empty($thumbnail)): ?>
                                <div class="relative mb-3 group cursor-pointer">
                                    <img src="<?php echo htmlspecialchars($thumbnail); ?>" alt="Video thumbnail" class="w-full h-auto rounded shadow-sm">
                                    <div class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30 group-hover:bg-opacity-20 transition-all duration-200">
                                        <div class="w-16 h-16 rounded-full bg-white bg-opacity-80 flex items-center justify-center">
                                            <i class="fas fa-play text-blue-600 text-2xl"></i>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="aspect-w-16 aspect-h-9">
                                <video class="w-full h-auto rounded shadow" controls>
                                    <source src="<?php echo htmlspecialchars($videoUrl); ?>" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            </div>
                        </div>
                        
                        <!-- Download Options -->
                        <div class="md:w-1/2 flex flex-col justify-center space-y-4">
                            <?php if (!empty($title)): ?>
                                <h3 class="text-lg font-medium text-gray-800"><?php echo htmlspecialchars($title); ?></h3>
                            <?php endif; ?>
                            
                            <div class="flex items-center">
                                <input type="text" id="videoUrl" value="<?php echo htmlspecialchars($videoUrl); ?>" class="flex-grow p-2 border rounded-l focus:outline-none focus:ring-2 focus:ring-blue-500" readonly>
                                <button onclick="copyToClipboard('videoUrl')" class="bg-gray-200 hover:bg-gray-300 px-4 py-2 rounded-r transition-colors duration-200" title="Copy URL">
                                    <i class="fas fa-copy"></i>
                                </button>
                            </div>
                            
                            <div class="flex flex-col sm:flex-row gap-2">
                                <a href="<?php echo htmlspecialchars($videoUrl); ?>" download class="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded flex items-center justify-center transition-colors duration-200 flex-grow">
                                    <i class="fas fa-download mr-2"></i> Download Video
                                </a>
                                <button onclick="window.open('<?php echo htmlspecialchars($videoUrl); ?>', '_blank')" class="bg-gray-700 hover:bg-gray-800 text-white py-2 px-4 rounded flex items-center justify-center transition-colors duration-200">
                                    <i class="fas fa-external-link-alt mr-2"></i> Open
                                </button>
                            </div>
                            
                            <div class="text-sm text-gray-500 mt-2">
                                <p><i class="fas fa-info-circle mr-1"></i> Right-click on the video and select "Save video as..." if the download button doesn't work.</p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- How to use section -->
            <div class="mt-10 border-t pt-6">
                <h2 class="text-xl font-semibold mb-4">How to use:</h2>
                <ol class="list-decimal pl-5 space-y-2">
                    <li>Copy the URL of the Pinterest video you want to download</li>
                    <li>Paste the URL in the input field above</li>
                    <li>Click the "Download Video" button</li>
                    <li>Wait for the video to process</li>
                    <li>Click the download button to save the video to your device</li>
                </ol>
            </div>
        </div>

        <!-- Blog Articles Section -->
        <?php
        function getRecentBlogArticles($limit = 2) {
            global $adminConfig;
            $articles = [];
            
            // Check if posts exist in admin config
            if (isset($adminConfig['posts']) && is_array($adminConfig['posts'])) {
                $posts = $adminConfig['posts'];
                
                // Sort posts by date (newest first)
                uasort($posts, function($a, $b) {
                    $dateA = isset($a['created_at']) ? strtotime($a['created_at']) : 0;
                    $dateB = isset($b['created_at']) ? strtotime($b['created_at']) : 0;
                    return $dateB - $dateA;
                });
                
                // Filter public posts and format for display
                $count = 0;
                foreach ($posts as $post_id => $post) {
                    if (isset($post['visibility']) && $post['visibility'] === 'public') {
                        // Create excerpt from content if needed
                        $excerpt = '';
                        if (!empty($post['content'])) {
                            $excerpt = strip_tags($post['content']);
                            $excerpt = substr($excerpt, 0, 150) . (strlen($excerpt) > 150 ? '...' : '');
                        }
                        
                        // Determine image path based on post ID
                        $imageName = '';
                        if (strpos($post_id, 'pinterest-video-viral') !== false) {
                            $imageName = 'pinterest-viral-videos.jpg';
                        } elseif (strpos($post_id, 'pinterest-business-ideas') !== false) {
                            $imageName = 'pinterest-business-ideas.jpg';
                        } elseif (strpos($post_id, 'pinterest-video-download-guide') !== false) {
                            $imageName = 'pinterest-download-guide.jpg';
                        }
                        
                        $articles[] = [
                            'title' => $post['title'],
                            'excerpt' => $excerpt,
                            'image' => 'assets/images/blog/' . $imageName,
                            'url' => 'blog-post.php?id=' . urlencode($post_id),
                            'date' => $post['created_at']
                        ];
                        
                        $count++;
                        if ($count >= $limit) break;
                    }
                }
            }
            
            return $articles;
        }
        
        $blogArticles = getRecentBlogArticles(2);
        if (!empty($blogArticles)):
        ?>
        <div class="max-w-3xl mx-auto mt-8 mb-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6 text-center">Featured Articles</h2>
            <div class="grid md:grid-cols-2 gap-6">
                <?php foreach ($blogArticles as $article): ?>
                <div class="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:transform hover:scale-105">
                    <?php if (!empty($article['image']) && file_exists($article['image'])): ?>
                    <img src="<?php echo htmlspecialchars($article['image']); ?>" alt="<?php echo htmlspecialchars($article['title']); ?>" class="w-full h-48 object-cover">
                    <?php else: ?>
                    <div class="w-full h-48 bg-gray-200 flex items-center justify-center">
                        <i class="fas fa-image text-gray-400 text-4xl"></i>
                    </div>
                    <?php endif; ?>
                    <div class="p-4">
                        <h3 class="text-lg font-semibold mb-2"><?php echo htmlspecialchars($article['title']); ?></h3>
                        <p class="text-gray-600 text-sm mb-3"><?php echo htmlspecialchars($article['excerpt']); ?></p>
                        <div class="flex justify-between items-center">
                            <span class="text-xs text-gray-500"><?php echo date('M j, Y', strtotime($article['date'])); ?></span>
                            <a href="<?php echo htmlspecialchars($article['url']); ?>" class="text-blue-600 hover:text-blue-800 text-sm font-medium">Read More →</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="text-center mt-6">
                <a href="blog.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-lg transition-colors duration-200">View All Articles</a>
            </div>
        </div>
        <?php endif; ?>

        <!-- SEO Content Section -->
        <section class="max-w-3xl mx-auto mt-12 bg-white rounded-lg shadow-md p-6">
            <h2 class="text-2xl font-bold text-gray-800 mb-4">How to Download Pinterest Videos</h2>
            <div class="space-y-4 text-gray-700">
                <p>PinSave is a free online tool that allows you to download Pinterest videos quickly and easily. Our Pinterest video downloader works with all Pinterest videos, including Pins, Idea Pins, and Story Pins. Follow these simple steps to save your favorite Pinterest videos:</p>
                
                <ol class="list-decimal pl-5 space-y-2">
                    <li><strong>Copy the Pinterest video URL</strong> - Find the video on Pinterest and copy its URL from your browser's address bar.</li>
                    <li><strong>Paste the URL</strong> - Paste the Pinterest URL into the input field above.</li>
                    <li><strong>Click Download</strong> - Click the "Download Video" button and wait for the video to process.</li>
                    <li><strong>Save the video</strong> - Once processed, you can preview the video and download it to your device.</li>
                </ol>
                
                <p>Our tool supports both full Pinterest URLs (pinterest.com) and shortened URLs (pin.it). You can download Pinterest videos in high quality without watermarks for free.</p>
            </div>
            
            <!-- FAQ Section with Schema Markup -->
            <div class="mt-10" itemscope itemtype="https://schema.org/FAQPage">
                <h2 class="text-2xl font-bold text-gray-800 mb-4">Frequently Asked Questions</h2>
                
                <div class="space-y-6">
                    <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" class="border-b pb-4">
                        <h3 itemprop="name" class="text-lg font-semibold text-gray-700">Is it free to download Pinterest videos?</h3>
                        <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
                            <div itemprop="text" class="mt-2 text-gray-600">
                                <p>Yes, PinSave is completely free to use. You can download any Pinterest video without paying anything or creating an account.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" class="border-b pb-4">
                        <h3 itemprop="name" class="text-lg font-semibold text-gray-700">Can I download Pinterest videos on mobile?</h3>
                        <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
                            <div itemprop="text" class="mt-2 text-gray-600">
                                <p>Yes, PinSave works on all devices including smartphones and tablets. You can download Pinterest videos on Android, iPhone, or any other mobile device with a web browser.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" class="border-b pb-4">
                        <h3 itemprop="name" class="text-lg font-semibold text-gray-700">How to download Pinterest videos without watermark?</h3>
                        <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
                            <div itemprop="text" class="mt-2 text-gray-600">
                                <p>PinSave automatically downloads Pinterest videos without watermarks. Simply paste the Pinterest video URL, click download, and you'll get the original video without any watermarks.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question" class="border-b pb-4">
                        <h3 itemprop="name" class="text-lg font-semibold text-gray-700">Why can't I download some Pinterest videos?</h3>
                        <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
                            <div itemprop="text" class="mt-2 text-gray-600">
                                <p>Some Pinterest videos may be private or protected by the creator. Our tool can only download publicly available Pinterest videos. If you're having trouble downloading a video, make sure it's a public video and try copying the URL directly from the Pinterest post.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
                        <h3 itemprop="name" class="text-lg font-semibold text-gray-700">What Pinterest video formats are supported?</h3>
                        <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
                            <div itemprop="text" class="mt-2 text-gray-600">
                                <p>PinSave supports all Pinterest video formats including regular Pins with videos, Idea Pins (formerly Story Pins), and video Pins. You can download videos from both pinterest.com and pin.it URLs.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        

        
        <!-- Footer -->
        <?php if ($googleAdsEnabled && !empty($googleAdsSlotBottom)): ?>
        <!-- Google Ad - Bottom -->
        <div class="mt-8 mb-6 text-center">
            <ins class="adsbygoogle"
                 style="display:block"
                 data-ad-client="<?php echo htmlspecialchars($googleAdsPublisherId); ?>"
                 data-ad-slot="<?php echo htmlspecialchars($googleAdsSlotBottom); ?>"
                 data-ad-format="auto"
                 data-full-width-responsive="true"></ins>
            <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
        </div>
        <?php endif; ?>
        
        <footer class="text-center mt-10 text-gray-500">
            
            <!-- Footer Card -->
            <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-6 mb-8">
                <!-- Disclaimer -->
                <div class="mb-6 border-b pb-4">
                    <h2 class="text-lg font-semibold text-gray-700 mb-3">Disclaimer</h2>
                    <p class="text-sm text-gray-600">
                        <?php echo !empty($footerConfig['disclaimer']) 
                            ? nl2br(htmlspecialchars($footerConfig['disclaimer'])) 
                            : 'PinterestDownloader does not host any pirated or copyright content on its server, and all videos or images that you download from our tool are downloaded from their respective CDN servers. And this tool is not associated with Pinterest in any ways.'; ?>
                    </p>
                </div>
                
                <!-- Footer Navigation -->
                <div class="flex flex-col md:flex-row justify-between items-center border-b pb-4 mb-4">
                    <div class="mb-4 md:mb-0">
                        <h3 class="text-md font-medium text-gray-700 mb-2">Quick Links</h3>
                        <ul class="flex flex-wrap gap-x-6 gap-y-2">
                            <li><a href="pages/about.php" class="text-blue-600 hover:text-blue-800 text-sm flex items-center"><i class="fas fa-info-circle mr-1"></i> About Us</a></li>
                            <li><a href="pages/contact.php" class="text-blue-600 hover:text-blue-800 text-sm flex items-center"><i class="fas fa-envelope mr-1"></i> Contact Us</a></li>
                            <li><a href="blog.php" class="text-blue-600 hover:text-blue-800 text-sm flex items-center"><i class="fas fa-blog mr-1"></i> Blog</a></li>
                            <li><a href="pages/faq.php" class="text-blue-600 hover:text-blue-800 text-sm flex items-center"><i class="fas fa-question-circle mr-1"></i> FAQ</a></li>
                            <li><a href="pages/dmca.php" class="text-blue-600 hover:text-blue-800 text-sm flex items-center"><i class="fas fa-copyright mr-1"></i> DMCA Policy</a></li>
                            <li><a href="pages/privacy.php" class="text-blue-600 hover:text-blue-800 text-sm flex items-center"><i class="fas fa-shield-alt mr-1"></i> Privacy Policy</a></li>
                            <li><a href="pages/terms.php" class="text-blue-600 hover:text-blue-800 text-sm flex items-center"><i class="fas fa-gavel mr-1"></i> Terms of Service</a></li>
                        </ul>
                    </div>
                    
                    <!-- Info Links -->
                    <?php if (!empty($footerConfig['links'])): ?>
                    <div>
                        <h3 class="text-md font-medium text-gray-700 mb-2">Resources</h3>
                        <ul class="flex flex-wrap gap-x-6 gap-y-2">
                            <?php foreach ($footerConfig['links'] as $link): ?>
                            <?php if (!empty($link['text']) && !empty($link['url'])): ?>
                            <li>
                                <a href="<?php echo htmlspecialchars($link['url']); ?>" class="text-blue-600 hover:text-blue-800 text-sm">
                                    <?php echo htmlspecialchars($link['text']); ?>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Copyright -->
                <div class="text-center text-gray-600 text-sm">
                    <p><?php echo htmlspecialchars($footerConfig['copyright_text'] ?? '© ' . date('Y') . ' PinSave - Pinterest Video Downloader | All Rights Reserved'); ?></p>
                </div>
            </div>
            
            <?php if (defined('DEBUG_MODE') && DEBUG_MODE): ?>
            <p class="mt-2">
                <a href="admin/login.php" class="text-xs text-gray-400 hover:underline">Admin Login</a>
            </p>
            <?php endif; ?>
    </div>
</body>
</html>