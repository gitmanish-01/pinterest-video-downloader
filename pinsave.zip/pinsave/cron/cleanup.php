<?php
require_once dirname(__DIR__) . '/includes/cache_handler.php';
require_once dirname(__DIR__) . '/includes/stats_handler.php';

// Initialize handlers
$cache_handler = new CacheHandler();
$stats_handler = new StatsHandler();

// Clean old cache files (older than 24 hours)
$cache_handler->cleanExpired();

// Clean old statistics (older than 30 days)
$stats_handler->cleanOldStats();

// Log cleanup execution
file_put_contents(
    dirname(__DIR__) . '/logs/cleanup.log',
    date('Y-m-d H:i:s') . " - Cleanup executed successfully\n",
    FILE_APPEND
);
?>
