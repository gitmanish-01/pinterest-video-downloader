<?php
// Start session
session_start();

// Include configuration
require_once 'includes/config.php';
require_once '../includes/stats_handler.php';

// Check if user is logged in
if (!isset($_SESSION[SESSION_NAME]) || $_SESSION[SESSION_NAME] !== true) {
    header('Location: login.php');
    exit;
}

// Load admin settings
$admin_settings_file = '../config/admin_settings.json';
$admin_settings = json_decode(file_get_contents($admin_settings_file), true);

// Initialize notification
$notification = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_page'])) {
        $slug = $_POST['slug'];
        $title = $_POST['title'];
        $content = $_POST['content'];
        $meta_description = $_POST['meta_description'];
        $show_in_footer = isset($_POST['show_in_footer']);
        
        // Update or create page
        $admin_settings['pages'][$slug] = [
            'title' => $title,
            'content' => $content,
            'slug' => $slug,
            'show_in_footer' => $show_in_footer,
            'meta_description' => $meta_description
        ];
        
        // Save settings
        file_put_contents($admin_settings_file, json_encode($admin_settings, JSON_PRETTY_PRINT));
        
        // Set notification
        $notification = '<div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
            <p>Page updated successfully!</p>
        </div>';
    } elseif (isset($_POST['delete_page'])) {
        $slug = $_POST['slug'];
        
        // Delete page
        if (isset($admin_settings['pages'][$slug])) {
            unset($admin_settings['pages'][$slug]);
            
            // Save settings
            file_put_contents($admin_settings_file, json_encode($admin_settings, JSON_PRETTY_PRINT));
            
            // Set notification
            $notification = '<div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                <p>Page deleted successfully!</p>
            </div>';
        }
    }
}

// Get current page for editing
$current_page = null;
$current_slug = '';
if (isset($_GET['edit']) && isset($admin_settings['pages'][$_GET['edit']])) {
    $current_slug = $_GET['edit'];
    $current_page = $admin_settings['pages'][$current_slug];
}

// Include header
include 'header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">Pages Management</h1>
        <div>
            <button id="new-page-btn" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md">
                <i class="fas fa-plus mr-2"></i> New Page
            </button>
        </div>
    </div>
    
    <?php echo $notification; ?>
    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Pages List -->
        <div class="md:col-span-1 bg-white rounded-lg shadow p-6">
            <h2 class="text-xl font-semibold mb-4">Pages</h2>
            <div class="overflow-y-auto max-h-96">
                <ul class="divide-y divide-gray-200">
                    <?php foreach ($admin_settings['pages'] as $slug => $page): ?>
                        <li class="py-3">
                            <div class="flex justify-between items-center">
                                <a href="?edit=<?php echo $slug; ?>" class="text-blue-600 hover:text-blue-800 font-medium">
                                    <?php echo htmlspecialchars($page['title']); ?>
                                </a>
                                <div class="flex space-x-2">
                                    <a href="../page.php?slug=<?php echo $slug; ?>" target="_blank" class="text-gray-500 hover:text-gray-700">
                                        <i class="fas fa-external-link-alt"></i>
                                    </a>
                                    <form method="POST" action="" class="inline" onsubmit="return confirm('Are you sure you want to delete this page?');">
                                        <input type="hidden" name="slug" value="<?php echo $slug; ?>">
                                        <button type="submit" name="delete_page" class="text-red-500 hover:text-red-700">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                            <p class="text-sm text-gray-500 truncate">
                                <?php echo htmlspecialchars(substr($page['content'], 0, 100)) . '...'; ?>
                            </p>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        
        <!-- Page Editor -->
        <div class="md:col-span-2 bg-white rounded-lg shadow p-6">
            <h2 class="text-xl font-semibold mb-4"><?php echo $current_page ? 'Edit Page' : 'New Page'; ?></h2>
            <form method="POST" action="">
                <div class="mb-4">
                    <label for="title" class="block text-sm font-medium text-gray-700 mb-1">Page Title</label>
                    <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($current_page['title'] ?? ''); ?>" 
                           class="border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 w-full" required>
                </div>
                
                <div class="mb-4">
                    <label for="slug" class="block text-sm font-medium text-gray-700 mb-1">Slug</label>
                    <input type="text" id="slug" name="slug" value="<?php echo htmlspecialchars($current_slug); ?>" 
                           class="border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 w-full" required>
                    <p class="mt-1 text-sm text-gray-500">Used in the URL: example.com/page.php?slug=<span class="font-mono">your-slug</span></p>
                </div>
                
                <div class="mb-4">
                    <label for="content" class="block text-sm font-medium text-gray-700 mb-1">Content</label>
                    <textarea id="content" name="content" rows="10" 
                              class="border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 w-full"><?php echo htmlspecialchars($current_page['content'] ?? ''); ?></textarea>
                </div>
                
                <div class="mb-4">
                    <label for="meta_description" class="block text-sm font-medium text-gray-700 mb-1">Meta Description</label>
                    <textarea id="meta_description" name="meta_description" rows="3" 
                              class="border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 w-full"><?php echo htmlspecialchars($current_page['meta_description'] ?? ''); ?></textarea>
                    <p class="mt-1 text-sm text-gray-500">Brief description for search engines. Recommended 150-160 characters.</p>
                </div>
                
                <div class="mb-6">
                    <div class="flex items-center">
                        <input type="checkbox" id="show_in_footer" name="show_in_footer" 
                               <?php echo ($current_page['show_in_footer'] ?? false) ? 'checked' : ''; ?> 
                               class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                        <label for="show_in_footer" class="ml-2 block text-sm text-gray-900">
                            Show in Footer
                        </label>
                    </div>
                </div>
                
                <div>
                    <button type="submit" name="update_page" class="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-md">
                        <?php echo $current_page ? 'Update Page' : 'Create Page'; ?>
                    </button>
                    <?php if ($current_page): ?>
                        <a href="pages.php" class="ml-2 text-gray-600 hover:text-gray-800">
                            Cancel
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('new-page-btn').addEventListener('click', function() {
    window.location.href = 'pages.php';
});
</script>

<?php include 'footer.php'; ?>
