<?php
// Start session
session_start();

// Include configuration
require_once 'includes/config.php';
require_once '../includes/stats_handler.php';

// Check if user is logged in
if (!isset($_SESSION[SESSION_NAME]) || $_SESSION[SESSION_NAME] !== true) {
    header('Location: login.php');
    exit;
}

$stats_handler = new StatsHandler();

// Handle date range filter
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-30 days'));

$stats = $stats_handler->getStats($start_date, $end_date);

// Calculate summary statistics
$total_visitors = $stats['visitors']['total'];
$visitors_in_range = 0;
foreach ($stats['visitors']['daily'] as $date => $count) {
    if ($date >= $start_date && $date <= $end_date) {
        $visitors_in_range += $count;
    }
}

// Calculate API metrics
$total_requests = 0;
$successful_requests = 0;
$avg_response_time = 0;
$response_times = [];
$provider_stats = [];

foreach ($stats['daily']['days'] as $date => $day_stats) {
    if ($date >= $start_date && $date <= $end_date) {
        $total_requests += $day_stats['total_requests'];
        $successful_requests += $day_stats['successful_requests'];
        
        foreach ($day_stats['providers'] as $provider => $pstats) {
            if (!isset($provider_stats[$provider])) {
                $provider_stats[$provider] = [
                    'requests' => 0,
                    'successes' => 0,
                    'failures' => 0,
                    'total_time' => 0
                ];
            }
            $provider_stats[$provider]['requests'] += $pstats['requests'];
            $provider_stats[$provider]['successes'] += $pstats['successes'];
            $provider_stats[$provider]['failures'] += $pstats['failures'];
            $provider_stats[$provider]['total_time'] += $pstats['avg_response_time'] * $pstats['requests'];
            $response_times[] = $pstats['avg_response_time'];
        }
    }
}

$success_rate = $total_requests > 0 ? round(($successful_requests / $total_requests) * 100, 2) : 0;
$avg_response_time = count($response_times) > 0 ? array_sum($response_times) / count($response_times) : 0;

// Calculate peak hours
$hourly_stats = [];
foreach ($stats['daily']['days'] as $date => $day_stats) {
    if ($date >= $start_date && $date <= $end_date && isset($day_stats['hourly'])) {
        foreach ($day_stats['hourly'] as $hour => $count) {
            if (!isset($hourly_stats[$hour])) {
                $hourly_stats[$hour] = 0;
            }
            $hourly_stats[$hour] += $count;
        }
    }
}
arsort($hourly_stats);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics - Pinterest Video Downloader Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
</head>
<body class="bg-gray-100">
    <?php include 'header.php'; ?>
    
    <div class="container mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold">Analytics Dashboard</h1>
            
            <!-- Date Range Filter -->
            <form class="flex space-x-4 items-center">
                <div>
                    <input type="text" id="start_date" name="start_date" value="<?php echo $start_date; ?>" 
                           class="border rounded px-3 py-2" placeholder="Start Date">
                </div>
                <div>
                    <input type="text" id="end_date" name="end_date" value="<?php echo $end_date; ?>" 
                           class="border rounded px-3 py-2" placeholder="End Date">
                </div>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                    Apply Filter
                </button>
            </form>
        </div>
        
        <!-- Summary Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-gray-500 text-sm">Visitors (Period)</h3>
                <p class="text-3xl font-bold"><?php echo number_format($visitors_in_range); ?></p>
                <p class="text-sm text-gray-500">Total: <?php echo number_format($total_visitors); ?></p>
            </div>
            
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-gray-500 text-sm">API Success Rate</h3>
                <p class="text-3xl font-bold"><?php echo $success_rate; ?>%</p>
                <p class="text-sm text-gray-500"><?php echo number_format($successful_requests); ?> of <?php echo number_format($total_requests); ?></p>
            </div>
            
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-gray-500 text-sm">Avg Response Time</h3>
                <p class="text-3xl font-bold"><?php echo round($avg_response_time, 2); ?>ms</p>
            </div>
            
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-gray-500 text-sm">Peak Hour</h3>
                <p class="text-3xl font-bold"><?php echo key($hourly_stats); ?>:00</p>
                <p class="text-sm text-gray-500"><?php echo number_format(current($hourly_stats)); ?> requests</p>
            </div>
        </div>
        
        <!-- Provider Performance -->
        <div class="bg-white p-6 rounded-lg shadow mb-8">
            <h2 class="text-xl font-semibold mb-4">Provider Performance</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead>
                        <tr class="bg-gray-50">
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Provider</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Requests</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Success Rate</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Avg Response Time</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($provider_stats as $provider => $pstats): ?>
                            <tr>
                                <td class="px-6 py-4"><?php echo $provider; ?></td>
                                <td class="px-6 py-4"><?php echo number_format($pstats['requests']); ?></td>
                                <td class="px-6 py-4">
                                    <?php
                                    $provider_success_rate = $pstats['requests'] > 0 ? 
                                        round(($pstats['successes'] / $pstats['requests']) * 100, 2) : 0;
                                    echo $provider_success_rate . '%';
                                    ?>
                                </td>
                                <td class="px-6 py-4">
                                    <?php
                                    $avg_time = $pstats['requests'] > 0 ? 
                                        round($pstats['total_time'] / $pstats['requests'], 2) : 0;
                                    echo $avg_time . 'ms';
                                    ?>
                                </td>
                                <td class="px-6 py-4">
                                    <?php
                                    $status = $stats['health']['providers'][$provider]['status'] ?? 'unknown';
                                    $status_color = [
                                        'healthy' => 'bg-green-100 text-green-800',
                                        'warning' => 'bg-yellow-100 text-yellow-800',
                                        'critical' => 'bg-red-100 text-red-800',
                                        'unknown' => 'bg-gray-100 text-gray-800'
                                    ][$status];
                                    ?>
                                    <span class="px-2 py-1 rounded text-sm <?php echo $status_color; ?>">
                                        <?php echo ucfirst($status); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Charts -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <!-- Traffic by Hour -->
            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-xl font-semibold mb-4">Traffic by Hour</h2>
                <canvas id="hourlyChart"></canvas>
            </div>
            
            <!-- Response Time Trend -->
            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-xl font-semibold mb-4">Response Time Trend</h2>
                <canvas id="responseTimeChart"></canvas>
            </div>
        </div>
        
        <!-- Geographic & Device Analytics -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Geographic Distribution -->
            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-xl font-semibold mb-4">Geographic Distribution</h2>
                <div class="space-y-2">
                    <?php
                    arsort($stats['visitors']['countries']);
                    $top_countries = array_slice($stats['visitors']['countries'], 0, 10);
                    foreach ($top_countries as $country => $count):
                        $percentage = ($count / $total_visitors) * 100;
                    ?>
                        <div class="flex items-center">
                            <span class="w-24"><?php echo $country; ?></span>
                            <div class="flex-1 mx-4">
                                <div class="bg-blue-100 h-4 rounded-full overflow-hidden">
                                    <div class="bg-blue-500 h-full rounded-full" style="width: <?php echo $percentage; ?>%"></div>
                                </div>
                            </div>
                            <span class="w-20 text-right"><?php echo number_format($count); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- Device & Browser Analytics -->
            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-xl font-semibold mb-4">Device & Browser Analytics</h2>
                <canvas id="browserChart"></canvas>
            </div>
        </div>
    </div>
    
    <script>
    // Initialize date pickers
    flatpickr("#start_date", {
        dateFormat: "Y-m-d",
        maxDate: "today"
    });
    flatpickr("#end_date", {
        dateFormat: "Y-m-d",
        maxDate: "today"
    });
    
    // Prepare chart data
    const hourlyData = <?php
        $hours = range(0, 23);
        $hourly_counts = array_map(function($hour) use ($hourly_stats) {
            return $hourly_stats[$hour] ?? 0;
        }, $hours);
        echo json_encode([
            'labels' => array_map(function($h) { return sprintf('%02d:00', $h); }, $hours),
            'data' => $hourly_counts
        ]);
    ?>;
    
    const responseTimeData = <?php
        $dates = array_keys($stats['daily']['days']);
        $times = array_map(function($date) use ($stats) {
            $day_stats = $stats['daily']['days'][$date];
            if (empty($day_stats['providers'])) return 0;
            $total_time = 0;
            $total_requests = 0;
            foreach ($day_stats['providers'] as $pstats) {
                $total_time += $pstats['avg_response_time'] * $pstats['requests'];
                $total_requests += $pstats['requests'];
            }
            return $total_requests > 0 ? $total_time / $total_requests : 0;
        }, $dates);
        echo json_encode([
            'labels' => $dates,
            'data' => $times
        ]);
    ?>;
    
    const browserData = <?php
        echo json_encode([
            'labels' => array_keys($stats['visitors']['browsers']),
            'data' => array_values($stats['visitors']['browsers'])
        ]);
    ?>;
    
    // Create charts
    new Chart(document.getElementById('hourlyChart'), {
        type: 'bar',
        data: {
            labels: hourlyData.labels,
            datasets: [{
                label: 'Requests per Hour',
                data: hourlyData.data,
                backgroundColor: '#3b82f6'
            }]
        }
    });
    
    new Chart(document.getElementById('responseTimeChart'), {
        type: 'line',
        data: {
            labels: responseTimeData.labels,
            datasets: [{
                label: 'Average Response Time (ms)',
                data: responseTimeData.data,
                borderColor: '#10b981',
                tension: 0.1
            }]
        }
    });
    
    new Chart(document.getElementById('browserChart'), {
        type: 'doughnut',
        data: {
            labels: browserData.labels,
            datasets: [{
                data: browserData.data,
                backgroundColor: [
                    '#3b82f6',
                    '#ef4444',
                    '#22c55e',
                    '#f59e0b',
                    '#8b5cf6'
                ]
            }]
        }
    });
    </script>
    
    <?php include 'footer.php'; ?>
</body>
</html>
