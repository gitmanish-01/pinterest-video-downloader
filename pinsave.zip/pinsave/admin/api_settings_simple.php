<?php
// Start session
session_start();

// Include configuration
require_once 'includes/config.php';
require_once '../includes/stats_handler.php';

// Check if user is logged in
if (!isset($_SESSION[SESSION_NAME]) || $_SESSION[SESSION_NAME] !== true) {
    header('Location: login.php');
    exit;
}

// Load admin settings
$admin_settings_file = '../config/admin_settings.json';
$admin_settings = json_decode(file_get_contents($admin_settings_file), true);

// Initialize notification
$notification = '';

// Set default values if not set
if (!isset($admin_settings['api']['providers'])) {
    $admin_settings['api']['providers'] = [];
}

// Ensure the main provider exists
if (!isset($admin_settings['api']['providers']['pinterest-video-downloader1'])) {
    $admin_settings['api']['providers']['pinterest-video-downloader1'] = [
        'enabled' => true,
        'api_key' => '',
        'host' => '',
        'endpoint' => '',
        'rate_limit' => 0,
        'priority' => 0
    ];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_api_settings'])) {
        // Update main provider settings
        $admin_settings['api']['providers']['pinterest-video-downloader1'] = [
            'enabled' => isset($_POST['provider_enabled']),
            'api_key' => $_POST['api_key'],
            'host' => $_POST['host'],
            'endpoint' => $_POST['endpoint'] ?? '',
            'rate_limit' => 0,
            'priority' => 0
        ];
        
        // Update cache settings
        $admin_settings['api']['cache_enabled'] = isset($_POST['cache_enabled']);
        $admin_settings['api']['cache_duration'] = (int)$_POST['cache_duration'];
        
        // Save settings
        file_put_contents($admin_settings_file, json_encode($admin_settings, JSON_PRETTY_PRINT));
        
        // Set notification
        $notification = '<div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
            <p>API settings updated successfully!</p>
        </div>';
    } elseif (isset($_POST['clear_cache'])) {
        // Clear cache
        $cache_dir = '../cache/';
        $files = glob($cache_dir . '*.json');
        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file);
            }
        }
        
        // Set notification
        $notification = '<div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
            <p>Cache cleared successfully!</p>
        </div>';
    }
}

// Get main provider
$main_provider = $admin_settings['api']['providers']['pinterest-video-downloader1'];

// Get cache settings
$cache_enabled = $admin_settings['api']['cache_enabled'] ?? false;
$cache_duration = $admin_settings['api']['cache_duration'] ?? 3600;

// Include header
include 'header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">API Settings</h1>
        <div>
            <form method="POST" action="" class="inline">
                <button type="submit" name="clear_cache" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md">
                    Clear Cache
                </button>
            </form>
        </div>
    </div>
    
    <?php echo $notification; ?>
    
    <form method="POST" action="">
        <div class="bg-white rounded-lg shadow p-6 mb-8">
            <h2 class="text-xl font-semibold mb-4">Pinterest API Settings</h2>
            <p class="text-gray-600 mb-4">Enter your RapidAPI credentials to enable Pinterest video downloading.</p>
            
            <div class="space-y-6">
                <!-- API Provider Settings -->
                <div class="bg-gray-50 p-4 rounded-md border">
                    <div class="flex items-center mb-4">
                        <input type="checkbox" name="provider_enabled" id="provider_enabled" 
                               <?php echo isset($main_provider['enabled']) && $main_provider['enabled'] ? 'checked' : ''; ?> 
                               class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                        <label for="provider_enabled" class="ml-2 text-lg font-medium text-gray-700">Enable Pinterest API</label>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 mb-2">API Key <span class="text-red-500">*</span></label>
                            <input type="text" name="api_key" value="<?php echo htmlspecialchars($main_provider['api_key'] ?? ''); ?>" 
                                   class="w-full px-3 py-2 border rounded" required>
                            <p class="text-sm text-gray-500 mt-1">Your RapidAPI key</p>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 mb-2">Host <span class="text-red-500">*</span></label>
                            <input type="text" name="host" value="<?php echo htmlspecialchars($main_provider['host'] ?? ''); ?>" 
                                   class="w-full px-3 py-2 border rounded" required>
                            <p class="text-sm text-gray-500 mt-1">The RapidAPI host (e.g., pinterest-video-downloader.p.rapidapi.com)</p>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 mb-2">Endpoint (Optional)</label>
                            <input type="text" name="endpoint" value="<?php echo htmlspecialchars($main_provider['endpoint'] ?? ''); ?>" 
                                   class="w-full px-3 py-2 border rounded">
                            <p class="text-sm text-gray-500 mt-1">Leave blank to use default endpoint</p>
                        </div>
                    </div>
                </div>
                
                <!-- Cache Settings -->
                <div class="bg-gray-50 p-4 rounded-md border">
                    <h3 class="text-lg font-medium text-gray-700 mb-4">Cache Settings</h3>
                    
                    <div class="flex items-center mb-4">
                        <input type="checkbox" name="cache_enabled" id="cache_enabled" 
                               <?php echo $cache_enabled ? 'checked' : ''; ?> 
                               class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                        <label for="cache_enabled" class="ml-2 text-gray-700">Enable Caching</label>
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 mb-2">Cache Duration (seconds)</label>
                        <input type="number" name="cache_duration" value="<?php echo (int)$cache_duration; ?>" 
                               class="w-full px-3 py-2 border rounded">
                        <p class="text-sm text-gray-500 mt-1">How long to cache results (3600 = 1 hour)</p>
                    </div>
                </div>
            </div>
            
            <div class="mt-6">
                <button type="submit" name="update_api_settings" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md">
                    Save API Settings
                </button>
            </div>
        </div>
    </form>
    
    <!-- How to Get API Key -->
    <div class="bg-white rounded-lg shadow p-6">
        <h2 class="text-xl font-semibold mb-4">How to Get Your RapidAPI Key</h2>
        
        <div class="space-y-4">
            <div class="flex items-start">
                <div class="flex-shrink-0 bg-blue-100 rounded-full p-2">
                    <span class="text-blue-600 font-bold">1</span>
                </div>
                <div class="ml-4">
                    <p>Visit <a href="https://rapidapi.com/" target="_blank" class="text-blue-600 hover:underline">RapidAPI.com</a> and create an account if you don't have one.</p>
                </div>
            </div>
            
            <div class="flex items-start">
                <div class="flex-shrink-0 bg-blue-100 rounded-full p-2">
                    <span class="text-blue-600 font-bold">2</span>
                </div>
                <div class="ml-4">
                    <p>Search for "Pinterest Video Downloader" and subscribe to a plan (there are free options available).</p>
                </div>
            </div>
            
            <div class="flex items-start">
                <div class="flex-shrink-0 bg-blue-100 rounded-full p-2">
                    <span class="text-blue-600 font-bold">3</span>
                </div>
                <div class="ml-4">
                    <p>Copy your API Key from the API documentation page.</p>
                </div>
            </div>
            
            <div class="flex items-start">
                <div class="flex-shrink-0 bg-blue-100 rounded-full p-2">
                    <span class="text-blue-600 font-bold">4</span>
                </div>
                <div class="ml-4">
                    <p>Copy the Host value from the API documentation page (it looks like "pinterest-video-downloader.p.rapidapi.com").</p>
                </div>
            </div>
            
            <div class="flex items-start">
                <div class="flex-shrink-0 bg-blue-100 rounded-full p-2">
                    <span class="text-blue-600 font-bold">5</span>
                </div>
                <div class="ml-4">
                    <p>Paste both values in the form above and click "Save API Settings".</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
