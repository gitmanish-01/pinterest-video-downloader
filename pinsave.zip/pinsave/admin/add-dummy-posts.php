<?php
// Include configuration
require_once '../config.php';
require_once 'includes/config.php';

// Check if user is logged in
if (!isAdminLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Create 5 dummy blog posts
$dummyPosts = [
    [
        'title' => 'How to Download Pinterest Videos in High Quality',
        'slug' => 'how-to-download-pinterest-videos-high-quality',
        'content' => "<p>Pinterest has become a popular platform for sharing not just images but also videos. Whether you're looking to save a cooking tutorial, DIY guide, or any other interesting video from Pinterest, our tool makes it easy to download them in high quality.</p>

<h2>Why Download Pinterest Videos?</h2>
<p>There are many reasons you might want to download videos from Pinterest:</p>
<ul>
<li>Save tutorials for offline viewing</li>
<li>Create content collections for inspiration</li>
<li>Share videos with friends who don't use Pinterest</li>
<li>Use content for educational purposes (with proper attribution)</li>
</ul>

<h2>Step-by-Step Guide</h2>
<p>Follow these simple steps to download any Pinterest video:</p>
<ol>
<li>Copy the Pinterest video URL from your browser</li>
<li>Paste the URL into our downloader tool</li>
<li>Click the \"Download\" button</li>
<li>Choose your preferred quality option</li>
<li>Save the video to your device</li>
</ol>

<p>With PinSave, you can download videos without any watermarks and in the highest quality available. Our tool is completely free and doesn't require any registration.</p>",
        'tags' => ['Pinterest', 'Video Downloader', 'Tutorial'],
        'category' => 'Tutorials',
        'visibility' => 'public',
        'seo' => [
            'meta_title' => 'How to Download Pinterest Videos in High Quality | PinSave',
            'meta_description' => 'Learn how to download Pinterest videos in high quality with our step-by-step guide. Save videos without watermarks using our free tool.'
        ],
        'template' => 'default',
        'created_at' => date('Y-m-d H:i:s', strtotime('-5 days')),
        'updated_at' => date('Y-m-d H:i:s', strtotime('-5 days'))
    ],
    [
        'title' => '5 Creative Ways to Use Pinterest Videos for Marketing',
        'slug' => '5-creative-ways-use-pinterest-videos-marketing',
        'content' => "<p>Pinterest is not just a platform for sharing images and ideas; it's also a powerful marketing tool, especially when you leverage video content. In this article, we'll explore five creative ways to use Pinterest videos to boost your marketing efforts.</p>

<h2>1. Create Engaging Product Demonstrations</h2>
<p>Videos are perfect for showing your products in action. Create short, engaging demonstrations that highlight key features and benefits. Pinterest users are often looking for solutions to problems, so showing how your product solves a specific issue can be very effective.</p>

<h2>2. Share Behind-the-Scenes Content</h2>
<p>People love seeing the human side of businesses. Share videos that show your team at work, your production process, or even casual office moments. This type of content helps build trust and connection with your audience.</p>

<h2>3. Develop Educational Tutorials</h2>
<p>Tutorial videos perform exceptionally well on Pinterest. Create short how-to videos related to your industry or products. These videos position your brand as an authority and provide value to viewers, increasing the likelihood they'll engage with your other content.</p>",
        'tags' => ['Pinterest Marketing', 'Video Marketing', 'Social Media'],
        'category' => 'Marketing',
        'visibility' => 'public',
        'seo' => [
            'meta_title' => '5 Creative Ways to Use Pinterest Videos for Marketing | PinSave',
            'meta_description' => 'Discover 5 creative ways to use Pinterest videos for effective marketing. Learn how to leverage video content to boost your brand presence.'
        ],
        'template' => 'default',
        'created_at' => date('Y-m-d H:i:s', strtotime('-3 days')),
        'updated_at' => date('Y-m-d H:i:s', strtotime('-3 days'))
    ],
    [
        'title' => 'Pinterest Video Size Guide: Best Dimensions for 2023',
        'slug' => 'pinterest-video-size-guide-best-dimensions-2023',
        'content' => "<p>Creating videos for Pinterest requires understanding the platform's specific requirements and best practices. In this guide, we'll cover everything you need to know about Pinterest video dimensions and specifications for 2023.</p>

<h2>Recommended Pinterest Video Dimensions</h2>
<p>For optimal display across all devices, follow these dimension guidelines:</p>
<ul>
<li><strong>Standard Pin Videos:</strong> 1000 x 1500 pixels (2:3 aspect ratio)</li>
<li><strong>Square Videos:</strong> 1000 x 1000 pixels (1:1 aspect ratio)</li>
<li><strong>Widescreen Videos:</strong> 1000 x 566 pixels (16:9 aspect ratio)</li>
</ul>

<h2>Video Length Requirements</h2>
<p>Pinterest supports videos of different lengths depending on the type:</p>
<ul>
<li><strong>Standard Pins:</strong> 4 seconds to 15 minutes</li>
<li><strong>Idea Pins:</strong> Up to 60 seconds per page</li>
<li><strong>Pinterest Ads:</strong> 4 seconds to 15 minutes (though 6-15 seconds is recommended)</li>
</ul>",
        'tags' => ['Pinterest', 'Video Dimensions', 'Social Media Tips'],
        'category' => 'Tips & Tricks',
        'visibility' => 'public',
        'seo' => [
            'meta_title' => 'Pinterest Video Size Guide: Best Dimensions for 2023 | PinSave',
            'meta_description' => 'Learn the optimal Pinterest video dimensions and specifications for 2023. Our complete guide covers aspect ratios, file sizes, and best practices.'
        ],
        'template' => 'default',
        'created_at' => date('Y-m-d H:i:s', strtotime('-1 day')),
        'updated_at' => date('Y-m-d H:i:s', strtotime('-1 day'))
    ],
    [
        'title' => 'Are Pinterest Videos Copyright Protected?',
        'slug' => 'are-pinterest-videos-copyright-protected',
        'content' => '<p>As Pinterest continues to grow as a platform for sharing videos, questions about copyright protection and fair use become increasingly important. In this article, we'll explore the copyright considerations for Pinterest videos.</p>

<h2>Copyright Protection on Pinterest</h2>
<p>Yes, videos posted on Pinterest are protected by copyright law. When someone creates and uploads a video to Pinterest, they retain the copyright to that content unless they've explicitly transferred those rights. This means that other users cannot legally download, redistribute, or use these videos without permission from the copyright holder.</p>

<h2>Pinterest's Official Stance</h2>
<p>Pinterest's Terms of Service clearly state that users should only pin content they have the right to use. According to Pinterest:</p>
<blockquote>
<p>\"You grant Pinterest and our users a non-exclusive, royalty-free, transferable, sublicensable, worldwide license to use, store, display, reproduce, save, modify, create derivative works, perform, and distribute your User Content on Pinterest solely for the purposes of operating, developing, providing, and using Pinterest.\"</p>
</blockquote>",
        'tags' => ['Copyright', 'Legal', 'Pinterest'],
        'category' => 'Legal',
        'visibility' => 'public',
        'seo' => [
            'meta_title' => 'Are Pinterest Videos Copyright Protected? | PinSave',
            'meta_description' => 'Learn about copyright protection for Pinterest videos. Understand your rights and responsibilities when downloading and using Pinterest video content.'
        ],
        'template' => 'default',
        'created_at' => date('Y-m-d H:i:s', strtotime('-12 hours')),
        'updated_at' => date('Y-m-d H:i:s', strtotime('-12 hours'))
    ],
    [
        'title' => 'How to Convert Pinterest Videos to MP4 Format',
        'slug' => 'how-to-convert-pinterest-videos-to-mp4-format',
        'content' => "<p>Pinterest videos are a great source of inspiration and information, but sometimes you might want to save them in MP4 format for offline viewing or other purposes. In this guide, we'll show you how to easily convert Pinterest videos to MP4 format.</p>

<h2>Why Convert Pinterest Videos to MP4?</h2>
<p>MP4 is one of the most widely supported video formats across devices and platforms. Converting Pinterest videos to MP4 offers several advantages:</p>
<ul>
<li>Better compatibility with various media players and devices</li>
<li>Easier to edit in most video editing software</li>
<li>Suitable for uploading to other platforms</li>
<li>Efficient compression while maintaining good quality</li>
<li>Ability to watch offline without internet connection</li>
</ul>

<h2>Using PinSave to Download Videos in MP4 Format</h2>
<p>Our PinSave tool makes it incredibly simple to download Pinterest videos directly in MP4 format:</p>
<ol>
<li>Copy the URL of the Pinterest video you want to download</li>
<li>Paste the URL into the PinSave downloader tool</li>
<li>Click the \"Download\" button</li>
<li>The video will automatically be converted and downloaded in MP4 format</li>
</ol>",
        'tags' => ['MP4', 'Video Conversion', 'Tutorial'],
        'category' => 'Tutorials',
        'visibility' => 'public',
        'seo' => [
            'meta_title' => 'How to Convert Pinterest Videos to MP4 Format | PinSave',
            'meta_description' => 'Learn how to easily convert Pinterest videos to MP4 format. Step-by-step guide for downloading and converting Pinterest videos for offline viewing.'
        ],
        'template' => 'default',
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ]
];

// Add posts to admin config
if (!isset($adminConfig['posts']) || !is_array($adminConfig['posts'])) {
    $adminConfig['posts'] = [];
}

// Add each dummy post with a unique ID
foreach ($dummyPosts as $post) {
    $post_id = 'post_' . uniqid();
    $adminConfig['posts'][$post_id] = $post;
}

// Save updated config
if (saveConfig($adminConfig)) {
    echo '<div style="padding: 20px; background-color: #d4edda; color: #155724; border-radius: 5px; margin-bottom: 20px;">
            <h2>Success!</h2>
            <p>5 dummy blog posts have been added to your blog. You can now manage them from the Posts section in the admin panel.</p>
            <p><a href="index.php?page=posts" style="color: #155724; text-decoration: underline;">Go to Posts</a></p>
          </div>';
} else {
    echo '<div style="padding: 20px; background-color: #f8d7da; color: #721c24; border-radius: 5px; margin-bottom: 20px;">
            <h2>Error</h2>
            <p>Failed to save the dummy blog posts. Please check file permissions and try again.</p>
          </div>';
}
?>
