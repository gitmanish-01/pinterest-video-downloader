<?php
require_once '../auth.php';
require_once '../../includes/stats_handler.php';

$stats_handler = new StatsHandler();
$stats = $stats_handler->getStats();

// Calculate summary statistics
$total_visitors = $stats['visitors']['total'];
$today = date('Y-m-d');
$visitors_today = $stats['visitors']['daily'][$today] ?? 0;

$total_requests = 0;
$successful_requests = 0;
foreach ($stats['daily']['days'] as $day_stats) {
    $total_requests += $day_stats['total_requests'];
    $successful_requests += $day_stats['successful_requests'];
}

$success_rate = $total_requests > 0 ? round(($successful_requests / $total_requests) * 100, 2) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics - Pinterest Video Downloader Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-100">
    <?php include 'header.php'; ?>
    
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-2xl font-bold mb-6">Analytics Dashboard</h1>
        
        <!-- Summary Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-gray-500 text-sm">Total Visitors</h3>
                <p class="text-3xl font-bold"><?php echo number_format($total_visitors); ?></p>
            </div>
            
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-gray-500 text-sm">Visitors Today</h3>
                <p class="text-3xl font-bold"><?php echo number_format($visitors_today); ?></p>
            </div>
            
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-gray-500 text-sm">Total API Requests</h3>
                <p class="text-3xl font-bold"><?php echo number_format($total_requests); ?></p>
            </div>
            
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-gray-500 text-sm">API Success Rate</h3>
                <p class="text-3xl font-bold"><?php echo $success_rate; ?>%</p>
            </div>
        </div>
        
        <!-- Provider Health -->
        <div class="bg-white p-6 rounded-lg shadow mb-8">
            <h2 class="text-xl font-semibold mb-4">Provider Health Status</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <?php foreach ($stats['health']['providers'] as $provider => $health): ?>
                    <div class="border rounded p-4">
                        <div class="flex items-center justify-between mb-2">
                            <span class="font-medium"><?php echo $provider; ?></span>
                            <span class="px-2 py-1 rounded text-sm <?php
                                echo $health['status'] === 'healthy' ? 'bg-green-100 text-green-800' :
                                    ($health['status'] === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                                    'bg-red-100 text-red-800');
                            ?>"><?php echo ucfirst($health['status']); ?></span>
                        </div>
                        <div class="text-sm text-gray-600">
                            <p>Last Check: <?php echo date('Y-m-d H:i', $health['last_check']); ?></p>
                            <p>Consecutive Failures: <?php echo $health['consecutive_failures']; ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <!-- Visitors Graph -->
        <div class="bg-white p-6 rounded-lg shadow mb-8">
            <h2 class="text-xl font-semibold mb-4">Daily Visitors</h2>
            <canvas id="visitorsChart"></canvas>
        </div>
        
        <!-- API Usage Graph -->
        <div class="bg-white p-6 rounded-lg shadow mb-8">
            <h2 class="text-xl font-semibold mb-4">API Usage</h2>
            <canvas id="apiUsageChart"></canvas>
        </div>
        
        <!-- Visitor Demographics -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-xl font-semibold mb-4">Top Countries</h2>
                <div class="space-y-2">
                    <?php
                    arsort($stats['visitors']['countries']);
                    $top_countries = array_slice($stats['visitors']['countries'], 0, 5);
                    foreach ($top_countries as $country => $count):
                    ?>
                        <div class="flex justify-between">
                            <span><?php echo $country; ?></span>
                            <span class="font-medium"><?php echo number_format($count); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-xl font-semibold mb-4">Browser Distribution</h2>
                <canvas id="browserChart"></canvas>
            </div>
        </div>
    </div>
    
    <script>
    // Prepare data for charts
    const visitorsData = <?php
        $dates = array_keys($stats['visitors']['daily']);
        $counts = array_values($stats['visitors']['daily']);
        echo json_encode([
            'labels' => $dates,
            'data' => $counts
        ]);
    ?>;
    
    const apiUsageData = <?php
        $api_dates = array_keys($stats['daily']['days']);
        $api_success = array_map(function($day) {
            return $day['successful_requests'];
        }, array_values($stats['daily']['days']));
        $api_failed = array_map(function($day) {
            return $day['failed_requests'];
        }, array_values($stats['daily']['days']));
        echo json_encode([
            'labels' => $api_dates,
            'success' => $api_success,
            'failed' => $api_failed
        ]);
    ?>;
    
    const browserData = <?php
        echo json_encode([
            'labels' => array_keys($stats['visitors']['browsers']),
            'data' => array_values($stats['visitors']['browsers'])
        ]);
    ?>;
    
    // Create charts
    new Chart(document.getElementById('visitorsChart'), {
        type: 'line',
        data: {
            labels: visitorsData.labels,
            datasets: [{
                label: 'Daily Visitors',
                data: visitorsData.data,
                borderColor: '#3b82f6',
                tension: 0.1
            }]
        }
    });
    
    new Chart(document.getElementById('apiUsageChart'), {
        type: 'bar',
        data: {
            labels: apiUsageData.labels,
            datasets: [{
                label: 'Successful Requests',
                data: apiUsageData.success,
                backgroundColor: '#22c55e'
            }, {
                label: 'Failed Requests',
                data: apiUsageData.failed,
                backgroundColor: '#ef4444'
            }]
        },
        options: {
            scales: {
                x: { stacked: true },
                y: { stacked: true }
            }
        }
    });
    
    new Chart(document.getElementById('browserChart'), {
        type: 'doughnut',
        data: {
            labels: browserData.labels,
            datasets: [{
                data: browserData.data,
                backgroundColor: [
                    '#3b82f6',
                    '#ef4444',
                    '#22c55e',
                    '#f59e0b',
                    '#8b5cf6'
                ]
            }]
        }
    });
    </script>
    
    <?php include 'footer.php'; ?>
</body>
</html>
