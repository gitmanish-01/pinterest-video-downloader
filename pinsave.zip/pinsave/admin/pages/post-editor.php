<?php
// This file is included by index.php, no need to include header

// Get post ID if editing
$post_id = isset($_GET['id']) ? $_GET['id'] : null;
$post = null;

// Load existing post if editing
if ($post_id && isset($adminConfig['posts'][$post_id])) {
    $post = $adminConfig['posts'][$post_id];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Debug logging
    error_log('Post form submitted');
    error_log('Content received: ' . (isset($_POST['content']) ? 'Yes (' . strlen($_POST['content']) . ' bytes)' : 'No'));
    
    $title = $_POST['title'] ?? '';
    $slug = $_POST['slug'] ?? '';
    $content = $_POST['content'] ?? '';
    $tags = !empty($_POST['tags']) ? explode(',', $_POST['tags']) : [];
    $category = $_POST['category'] ?? '';
    $visibility = $_POST['visibility'] ?? 'public';
    $meta_title = $_POST['meta_title'] ?? '';
    $meta_description = $_POST['meta_description'] ?? '';
    $template = $_POST['template'] ?? 'default';
    
    // Generate new post ID if creating
    if (!$post_id) {
        $post_id = uniqid('post_');
    }
    
    // Prepare post data
    $post_data = [
        'title' => $title,
        'slug' => $slug ?: sanitize_slug($title),
        'content' => $content,
        'tags' => array_map('trim', $tags),
        'category' => $category,
        'visibility' => $visibility,
        'seo' => [
            'meta_title' => $meta_title,
            'meta_description' => $meta_description
        ],
        'template' => $template,
        'updated_at' => date('Y-m-d H:i:s'),
        'created_at' => isset($post['created_at']) ? $post['created_at'] : date('Y-m-d H:i:s')
    ];
    
    // Save to config
    $adminConfig['posts'][$post_id] = $post_data;
    $saveResult = saveConfig($adminConfig);
    
    if ($saveResult) {
        error_log('Post saved successfully: ' . $post_id);
        // Use JavaScript redirect instead of header() to avoid 'headers already sent' errors
        echo "<script>window.location.href = 'index.php?page=posts&success=1';</script>";
    } else {
        error_log('Failed to save post: ' . $post_id);
        echo "<div class='bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4' role='alert'>
                <p>Failed to save post. Please check error logs.</p>
              </div>";
    }
    exit;
}

// Helper function to sanitize slug
function sanitize_slug($text) {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    $text = strtolower($text);
    return $text ?: 'post';
}
?>

<div class="p-6">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-2xl font-bold text-gray-800"><?php echo $post ? 'Edit Post' : 'Create New Post'; ?></h1>
            <p class="text-sm text-gray-500 mt-1"><?php echo $post ? 'Update your existing content' : 'Create new content for your blog'; ?></p>
        </div>
        <a href="index.php?page=posts" class="btn btn-secondary flex items-center">
            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
            </svg>
            Back to Posts
        </a>
    </div>

    <form method="post" class="card">
        <div class="card-header">
            <h3 class="card-title"><?php echo $post ? 'Edit Post Details' : 'New Post Details'; ?></h3>
            <div class="text-sm text-gray-500">
                <?php if ($post): ?>
                Last updated: <?php echo date('M j, Y', strtotime($post['updated_at'])); ?>
                <?php else: ?>
                All fields marked with * are required
                <?php endif; ?>
            </div>
        </div>
        <div class="card-body">
        <!-- Title -->
            <div class="mb-6">
                <label class="block text-gray-700 text-sm font-medium mb-2" for="title">
                    Title <span class="text-red-500">*</span>
                </label>
                <input class="form-input w-full rounded-lg border border-gray-300 focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-20" 
                       id="title" 
                       name="title" 
                       type="text" 
                       value="<?php echo htmlspecialchars($post['title'] ?? ''); ?>" 
                       required>
            </div>

        <!-- Slug -->
            <div class="mb-6">
                <label class="block text-gray-700 text-sm font-medium mb-2" for="slug">
                    Slug (URL)
                </label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">/blog/</span>
                    <input class="form-input w-full rounded-lg border border-gray-300 pl-14 focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-20" 
                           id="slug" 
                           name="slug" 
                           type="text" 
                           value="<?php echo htmlspecialchars($post['slug'] ?? ''); ?>"
                           placeholder="leave-empty-to-generate-from-title">
                </div>
                <p class="text-xs text-gray-500 mt-1">The URL-friendly version of the title. Leave empty to generate automatically.</p>
            </div>

        <!-- Content Editor -->
            <div class="mb-6">
                <label class="block text-gray-700 text-sm font-medium mb-2" for="content">
                    Content <span class="text-red-500">*</span>
                </label>
                <div class="border rounded-lg border-gray-300 overflow-hidden shadow-inner bg-white p-2">
                    <textarea id="editor" name="content" class="w-full min-h-[400px]"><?php echo htmlspecialchars($post['content'] ?? ''); ?></textarea>
                </div>
                <p class="text-xs text-gray-500 mt-1">Use the toolbar to format your content. You can add images, links, and more.</p>
            </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <!-- Tags -->
                <div>
                    <label class="block text-gray-700 text-sm font-medium mb-2" for="tags">
                        Tags
                    </label>
                    <div class="relative">
                        <input class="form-input w-full rounded-lg border border-gray-300 focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-20" 
                               id="tags" 
                               name="tags" 
                               type="text" 
                               value="<?php echo htmlspecialchars(implode(',', $post['tags'] ?? [])); ?>"
                               placeholder="e.g. pinterest, video, tutorial">
                        <svg class="w-4 h-4 text-gray-400 absolute right-3 top-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"></path>
                        </svg>
                    </div>
                    <p class="text-xs text-gray-500 mt-1">Separate multiple tags with commas</p>
                </div>

                <!-- Category -->
                <div>
                    <label class="block text-gray-700 text-sm font-medium mb-2" for="category">
                        Category
                    </label>
                    <div class="relative">
                        <input class="form-input w-full rounded-lg border border-gray-300 focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-20" 
                               id="category" 
                               name="category" 
                               type="text" 
                               value="<?php echo htmlspecialchars($post['category'] ?? ''); ?>"
                               placeholder="e.g. Tutorials">
                        <svg class="w-4 h-4 text-gray-400 absolute right-3 top-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path>
                        </svg>
                    </div>
                    <p class="text-xs text-gray-500 mt-1">Main category for this post</p>
                </div>
            </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <!-- Visibility -->
                <div>
                    <label class="block text-gray-700 text-sm font-medium mb-2" for="visibility">
                        Visibility
                    </label>
                    <div class="relative">
                        <select class="form-select w-full rounded-lg border border-gray-300 focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-20 appearance-none" 
                                id="visibility" 
                                name="visibility">
                            <option value="public" <?php echo (($post['visibility'] ?? 'public') === 'public') ? 'selected' : ''; ?>>Public</option>
                            <option value="private" <?php echo (($post['visibility'] ?? '') === 'private') ? 'selected' : ''; ?>>Private</option>
                        </select>
                        <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-500">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                            </svg>
                        </div>
                    </div>
                    <p class="text-xs text-gray-500 mt-1">Control who can see this post</p>
                </div>

                <!-- Template -->
                <div>
                    <label class="block text-gray-700 text-sm font-medium mb-2" for="template">
                        Template
                    </label>
                    <div class="relative">
                        <select class="form-select w-full rounded-lg border border-gray-300 focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-20 appearance-none" 
                                id="template" 
                                name="template">
                            <option value="default" <?php echo (($post['template'] ?? 'default') === 'default') ? 'selected' : ''; ?>>Default</option>
                            <option value="full-width" <?php echo (($post['template'] ?? '') === 'full-width') ? 'selected' : ''; ?>>Full Width</option>
                            <option value="sidebar" <?php echo (($post['template'] ?? '') === 'sidebar') ? 'selected' : ''; ?>>With Sidebar</option>
                        </select>
                        <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-500">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                            </svg>
                        </div>
                    </div>
                    <p class="text-xs text-gray-500 mt-1">Choose the layout for this post</p>
                </div>
            </div>

        <!-- SEO Section -->
            <div class="mb-6 border-t border-gray-200 pt-6">
                <div class="flex items-center mb-4">
                    <svg class="w-5 h-5 text-primary mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                    </svg>
                    <h3 class="text-lg font-semibold text-gray-800">SEO Settings</h3>
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-medium mb-2" for="meta_title">
                        Meta Title
                    </label>
                    <input class="form-input w-full rounded-lg border border-gray-300 focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-20" 
                           id="meta_title" 
                           name="meta_title" 
                           type="text" 
                           value="<?php echo htmlspecialchars($post['seo']['meta_title'] ?? ''); ?>"
                           placeholder="Enter SEO title (recommended: 50-60 characters)">
                    <p class="text-xs text-gray-500 mt-1">Leave empty to use the post title</p>
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-medium mb-2" for="meta_description">
                        Meta Description
                    </label>
                    <textarea class="form-textarea w-full rounded-lg border border-gray-300 focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-20" 
                              id="meta_description" 
                              name="meta_description" 
                              rows="3"
                              placeholder="Enter SEO description (recommended: 150-160 characters)"><?php echo htmlspecialchars($post['seo']['meta_description'] ?? ''); ?></textarea>
                    <p class="text-xs text-gray-500 mt-1">A good description helps with search engine rankings</p>
                </div>
            </div>

                </div>
        <div class="card-footer flex items-center justify-between">
            <a href="index.php?page=posts" class="text-gray-600 hover:text-gray-800">
                Cancel
            </a>
            <div class="flex space-x-2">
                <button type="submit" name="save_draft" class="btn btn-secondary">
                    Save as Draft
                </button>
                <button type="submit" class="btn btn-primary flex items-center">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    <?php echo $post ? 'Update Post' : 'Publish Post'; ?>
                </button>
            </div>
        </div>
    </form>
</div>

<!-- Include CKEditor -->
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize CKEditor with Classic editor for better compatibility
    ClassicEditor
        .create(document.querySelector('#editor'), {
            toolbar: [
                'heading',
                '|',
                'bold', 'italic', 'underline', 'strikethrough',
                '|',
                'alignment',
                '|',
                'link', 'bulletedList', 'numberedList',
                '|',
                'outdent', 'indent',
                '|',
                'blockQuote', 'insertTable', 'mediaEmbed',
                '|',
                'undo', 'redo'
            ],
            placeholder: 'Start writing your content here...'
        })
        .then(editor => {
            // Store editor instance
            window.editor = editor;
            console.log('CKEditor initialized successfully');
        })
        .catch(error => {
            console.error('CKEditor error:', error);
            // No need for fallback since we're using the textarea directly
        });
        
    // Auto-generate slug from title
    document.querySelector('#title').addEventListener('blur', function() {
        const slugInput = document.querySelector('#slug');
        if (!slugInput.value) {
            slugInput.value = this.value
                .toLowerCase()
                .replace(/[^\w\s-]/g, '')
                .replace(/\s+/g, '-');
        }
    });
});
</script>
