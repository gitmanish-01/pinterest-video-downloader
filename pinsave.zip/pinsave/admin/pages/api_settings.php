<?php
// Handle API settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $config['api']['rapidapi_key'] = $_POST['rapidapi_key'] ?? '';
    $config['api']['api_provider'] = $_POST['api_provider'] ?? 'pinterest-video-downloader1';
    $config['api']['debug_mode'] = isset($_POST['debug_mode']);
    
    if (saveConfig($config)) {
        $success = 'API settings updated successfully!';
    } else {
        $error = 'Failed to save API settings.';
    }
}
require_once '../../includes/rate_limiter.php';
require_once '../../includes/cache_handler.php';

$rate_limiter = new RateLimiter();
$cache_handler = new CacheHandler();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update_api_settings':
                $config['api']['debug_mode'] = isset($_POST['debug_mode']);
                $config['api']['api_provider'] = $_POST['default_provider'];
                $config['api']['rapidapi_key'] = $_POST['rapidapi_key'];
                
                // Update provider rate limits
                foreach ($_POST['provider_limits'] as $provider => $limits) {
                    $config['api']['providers'][$provider] = [
                        'enabled' => isset($limits['enabled']),
                        'requests' => (int)$limits['requests'],
                        'per_seconds' => (int)$limits['per_seconds']
                    ];
                }
                
                file_put_contents('../../config/admin_settings.json', json_encode($config, JSON_PRETTY_PRINT));
                $success_message = 'API settings updated successfully';
                break;
                
            case 'clear_cache':
                $cache_handler->clear();
                $success_message = 'Cache cleared successfully';
                break;
                
            case 'reset_rate_limits':
                $rate_limiter->resetLimits();
                $success_message = 'Rate limits reset successfully';
                break;
        }
    }
}

// Get current usage stats
$usage_stats = [];
$rate_limit_files = glob('../../cache/rate_limits/*.json');
foreach ($rate_limit_files as $file) {
    $provider = basename($file, '.json');
    $data = json_decode(file_get_contents($file), true);
    $current_time = time();
    $active_requests = array_filter($data['requests'], function($timestamp) use ($current_time) {
        return ($current_time - $timestamp) < 3600;
    });
    $usage_stats[$provider] = count($active_requests);
}

// Get cache stats
$cache_files = glob('../../cache/*.json');
$cache_size = 0;
$cache_count = count($cache_files);
foreach ($cache_files as $file) {
    $cache_size += filesize($file);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Settings - Pinterest Video Downloader Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <?php include 'header.php'; ?>
    
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-2xl font-bold mb-6">API Settings</h1>
        
        <?php if (isset($success_message)): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- API Configuration -->
            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-xl font-semibold mb-4">API Configuration</h2>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="update_api_settings">
                    
                    <div class="mb-4">
                        <label class="block text-gray-700 mb-2">RapidAPI Key</label>
                        <input type="text" name="rapidapi_key" value="<?php echo htmlspecialchars($config['api']['rapidapi_key']); ?>" 
                               class="w-full px-3 py-2 border rounded">
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-gray-700 mb-2">Default Provider</label>
                        <select name="default_provider" class="w-full px-3 py-2 border rounded">
                            <?php foreach ($config['api']['providers'] as $provider => $settings): ?>
                                <option value="<?php echo $provider; ?>" <?php echo $config['api']['api_provider'] === $provider ? 'selected' : ''; ?>>
                                    <?php echo $provider; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-4">
                        <label class="flex items-center">
                            <input type="checkbox" name="debug_mode" <?php echo $config['api']['debug_mode'] ? 'checked' : ''; ?> class="mr-2">
                            Enable Debug Mode
                        </label>
                    </div>
                    
                    <h3 class="font-semibold mt-6 mb-4">Provider Rate Limits</h3>
                    <?php foreach ($config['api']['providers'] as $provider => $settings): ?>
                        <div class="border p-4 rounded mb-4">
                            <div class="flex items-center mb-2">
                                <input type="checkbox" name="provider_limits[<?php echo $provider; ?>][enabled]" 
                                       <?php echo $settings['enabled'] ? 'checked' : ''; ?> class="mr-2">
                                <span class="font-medium"><?php echo $provider; ?></span>
                            </div>
                            
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-sm text-gray-600">Requests</label>
                                    <input type="number" name="provider_limits[<?php echo $provider; ?>][requests]" 
                                           value="<?php echo $settings['requests']; ?>" class="w-full px-2 py-1 border rounded">
                                </div>
                                <div>
                                    <label class="block text-sm text-gray-600">Per Seconds</label>
                                    <input type="number" name="provider_limits[<?php echo $provider; ?>][per_seconds]" 
                                           value="<?php echo $settings['per_seconds']; ?>" class="w-full px-2 py-1 border rounded">
                                </div>
                            </div>
                            
                            <?php if (isset($usage_stats[$provider])): ?>
                                <div class="mt-2 text-sm text-gray-600">
                                    Current Usage: <?php echo $usage_stats[$provider]; ?> requests in last hour
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                    
                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                        Save API Settings
                    </button>
                </form>
            </div>
            
            <!-- Cache Management -->
            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-xl font-semibold mb-4">Cache Management</h2>
                
                <div class="mb-6">
                    <h3 class="font-medium mb-2">Cache Statistics</h3>
                    <div class="text-sm text-gray-600">
                        <p>Total Cache Files: <?php echo $cache_count; ?></p>
                        <p>Total Cache Size: <?php echo round($cache_size / 1024 / 1024, 2); ?> MB</p>
                    </div>
                </div>
                
                <form method="POST" action="" class="mb-4">
                    <input type="hidden" name="action" value="clear_cache">
                    <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">
                        Clear Cache
                    </button>
                </form>
                
                <form method="POST" action="">
                    <input type="hidden" name="action" value="reset_rate_limits">
                    <button type="submit" class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600">
                        Reset Rate Limits
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <?php include 'footer.php'; ?>
</body>
</html>
