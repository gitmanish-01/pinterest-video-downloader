<?php

// Handle category actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add' || $action === 'edit') {
        $category_id = $_POST['category_id'] ?? uniqid('cat_');
        $name = $_POST['name'] ?? '';
        $slug = $_POST['slug'] ?? sanitize_slug($name);
        $description = $_POST['description'] ?? '';
        
        if (!empty($name)) {
            if (!isset($adminConfig['categories'])) {
                $adminConfig['categories'] = [];
            }
            
            $adminConfig['categories'][$category_id] = [
                'name' => $name,
                'slug' => $slug,
                'description' => $description,
                'updated_at' => date('Y-m-d H:i:s')
            ];
            
            saveConfig($adminConfig);
            header('Location: categories.php?success=1');
            exit;
        }
    }
    
    if ($action === 'delete' && !empty($_POST['category_id'])) {
        $category_id = $_POST['category_id'];
        if (isset($adminConfig['categories'][$category_id])) {
            unset($adminConfig['categories'][$category_id]);
            saveConfig($adminConfig);
            header('Location: categories.php?deleted=1');
            exit;
        }
    }
}

// Helper function to sanitize slug
function sanitize_slug($text) {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    $text = strtolower($text);
    return $text ?: 'category';
}

// Get categories with post counts
$taxonomy = new Taxonomy();
$categories = $taxonomy->getCategories();
?>

<div class="container px-6 py-8 mx-auto">
    <div class="mb-6 flex justify-between items-center">
        <h1 class="text-2xl font-bold">Manage Categories</h1>
        <button onclick="openCategoryModal()" class="bg-blue-500 hover:bg-blue-700 text-white px-4 py-2 rounded">
            Add New Category
        </button>
    </div>

    <?php if (isset($_GET['success'])): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
        <span class="block sm:inline">Category saved successfully!</span>
    </div>
    <?php endif; ?>

    <?php if (isset($_GET['deleted'])): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
        <span class="block sm:inline">Category deleted successfully!</span>
    </div>
    <?php endif; ?>

    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Name
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Slug
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Posts
                    </th>
                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                    </th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php if (empty($categories)): ?>
                <tr>
                    <td colspan="4" class="px-6 py-4 text-center text-gray-500">
                        No categories found. Create your first category!
                    </td>
                </tr>
                <?php else: ?>
                    <?php foreach ($categories as $id => $category): ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">
                                <?php echo htmlspecialchars($category['name']); ?>
                            </div>
                            <?php if (!empty($category['description'])): ?>
                            <div class="text-sm text-gray-500">
                                <?php echo htmlspecialchars(substr($category['description'], 0, 50)) . '...'; ?>
                            </div>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <?php echo htmlspecialchars($category['slug']); ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <?php echo $category['count']; ?> posts
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button onclick="editCategory('<?php echo $id; ?>')" class="text-blue-600 hover:text-blue-900 mr-3">
                                Edit
                            </button>
                            <form method="post" class="inline-block" onsubmit="return confirm('Are you sure? This will not delete the posts in this category.');">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="category_id" value="<?php echo htmlspecialchars($id); ?>">
                                <button type="submit" class="text-red-600 hover:text-red-900">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Category Modal -->
<div id="categoryModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4" id="modalTitle">Add New Category</h3>
            <form method="post">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="category_id" id="categoryId" value="">
                
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="name">
                        Name
                    </label>
                    <input type="text" id="categoryName" name="name" required
                           class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="slug">
                        Slug (optional)
                    </label>
                    <input type="text" id="categorySlug" name="slug"
                           class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="description">
                        Description
                    </label>
                    <textarea id="categoryDescription" name="description" rows="3"
                              class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"></textarea>
                </div>
                
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="closeCategoryModal()"
                            class="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300">
                        Cancel
                    </button>
                    <button type="submit"
                            class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700">
                        Save Category
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openCategoryModal() {
    document.getElementById('modalTitle').textContent = 'Add New Category';
    document.getElementById('categoryId').value = '';
    document.getElementById('categoryName').value = '';
    document.getElementById('categorySlug').value = '';
    document.getElementById('categoryDescription').value = '';
    document.querySelector('form [name="action"]').value = 'add';
    document.getElementById('categoryModal').classList.remove('hidden');
}

function closeCategoryModal() {
    document.getElementById('categoryModal').classList.add('hidden');
}

function editCategory(id) {
    const categories = <?php echo json_encode($categories); ?>;
    const category = categories[id];
    
    document.getElementById('modalTitle').textContent = 'Edit Category';
    document.getElementById('categoryId').value = id;
    document.getElementById('categoryName').value = category.name;
    document.getElementById('categorySlug').value = category.slug;
    document.getElementById('categoryDescription').value = category.description || '';
    document.querySelector('form [name="action"]').value = 'edit';
    document.getElementById('categoryModal').classList.remove('hidden');
}

// Auto-generate slug from name
document.getElementById('categoryName').addEventListener('blur', function() {
    const slugInput = document.getElementById('categorySlug');
    if (!slugInput.value) {
        slugInput.value = this.value
            .toLowerCase()
            .replace(/[^\w\s-]/g, '')
            .replace(/\s+/g, '-');
    }
});
</script>

