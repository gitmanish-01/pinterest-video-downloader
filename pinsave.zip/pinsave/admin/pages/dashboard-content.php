<?php
// This file contains the dashboard content that was previously in index.php
// It's included by index.php when the dashboard page is requested

// Variables used in this template should be defined in the parent file (index.php)
// $stats_handler, $api_handler, $taxonomy, $stats, $today_stats, $api_health, etc.

// Calculate total articles and published count
$total_articles = count($all_posts ?? []);
$published_count = count($published_posts ?? []);

// Sort categories and tags by count for popular display
$popular_categories = $categories;
usort($popular_categories, function($a, $b) {
    return ($b['count'] ?? 0) - ($a['count'] ?? 0);
});

$popular_tags = $tags;
usort($popular_tags, function($a, $b) {
    return ($b['count'] ?? 0) - ($a['count'] ?? 0);
});

// Get config file status
$config_file = '../config/admin_settings.json';
$config_status = file_exists($config_file) ? 'OK' : 'Missing';
$config_writable = is_writable($config_file) ? 'Yes' : 'No';

// Get debug mode status
$debug_mode = isset($GLOBALS['adminConfig']['api']['debug_mode']) && $GLOBALS['adminConfig']['api']['debug_mode'] ? 'Enabled' : 'Disabled';
?>

<!-- Dashboard Header -->
<div class="mb-6">
    <div class="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <div>
            <h1 class="text-2xl font-bold text-gray-800">Dashboard</h1>
            <p class="text-sm text-gray-500 mt-1">Plan, prioritize, and accomplish your tasks with ease.</p>
        </div>
        <div class="flex flex-col sm:flex-row gap-3">
            <a href="index.php?page=post-editor" class="btn btn-primary flex items-center justify-center">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                </svg>
                Add Content
            </a>
            <div class="text-sm text-gray-600 bg-white px-3 py-2 rounded-lg shadow-sm flex items-center">
                <svg class="w-4 h-4 mr-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <span>Last updated: <?php echo date('Y-m-d H:i:s'); ?></span>
            </div>
        </div>
    </div>
</div>
    
<!-- Status Cards -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
    <!-- API Status -->
    <div class="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-gray-500 text-sm font-medium">API Status</h3>
            <span class="px-2 py-1 text-xs font-medium rounded-full <?php
                echo count($critical_providers) > 0 ? 'bg-red-100 text-red-800' :
                    (count($warning_providers) > 0 ? 'bg-yellow-100 text-yellow-800' :
                    'bg-green-100 text-green-800');
            ?>">
                <?php
                if (count($critical_providers) > 0) echo 'Critical';
                elseif (count($warning_providers) > 0) echo 'Warning';
                else echo 'Healthy';
                ?>
            </span>
        </div>
        <div class="text-3xl font-bold text-gray-800"><?php echo count($healthy_providers); ?>/<?php echo count($api_health); ?></div>
        <div class="text-sm text-gray-500 mb-4">Healthy Providers</div>
        <div class="flex items-center text-xs text-green-600">
            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
            </svg>
            <span>From last month</span>
        </div>
    </div>
    
    <!-- Today's Downloads -->
    <div class="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-gray-500 text-sm font-medium">Today's Downloads</h3>
            <span class="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">Today</span>
        </div>
        <div class="text-3xl font-bold text-gray-800"><?php echo number_format($today_stats['total_requests'] ?? 0); ?></div>
        <div class="text-sm text-gray-500 mb-2">Total Requests</div>
        <div class="flex items-center justify-between mb-2">
            <div class="flex items-center">
                <span class="inline-block w-2 h-2 rounded-full bg-green-500 mr-1"></span>
                <span class="text-xs text-gray-600"><?php echo number_format($today_stats['successful_requests'] ?? 0); ?> successful</span>
            </div>
            <div class="flex items-center">
                <span class="inline-block w-2 h-2 rounded-full bg-red-500 mr-1"></span>
                <span class="text-xs text-gray-600"><?php echo number_format($today_stats['failed_requests'] ?? 0); ?> failed</span>
            </div>
        </div>
        <div class="flex items-center text-xs text-green-600">
            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
            </svg>
            <span>From last month</span>
        </div>
    </div>
        
    <!-- Articles -->    
    <div class="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-gray-500 text-sm font-medium">Articles</h3>
            <span class="px-2 py-1 text-xs font-medium rounded-full bg-primary-light text-primary">Content</span>
        </div>
        <div class="text-3xl font-bold text-gray-800"><?php echo $published_count; ?>/<?php echo $total_articles; ?></div>
        <div class="text-sm text-gray-500 mb-4">Published Pages</div>
        <div class="flex items-center text-xs text-green-600">
            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
            </svg>
            <span>From last month</span>
        </div>
    </div>
    
    <!-- Today's Visitors -->
    <div class="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
        <div class="flex items-center justify-between mb-3">
            <h3 class="text-gray-500 text-sm font-medium">Today's Visitors</h3>
            <span class="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">Today</span>
        </div>
        <div class="text-3xl font-bold text-gray-800"><?php echo number_format($stats['visitors']['daily'][$today] ?? 0); ?></div>
        <div class="text-sm text-gray-500 mb-2">Unique Visitors</div>
        <div class="flex items-center justify-between mb-2">
            <div class="flex items-center">
                <span class="inline-block w-2 h-2 rounded-full bg-blue-500 mr-1"></span>
                <span class="text-xs text-gray-600">Total: <?php echo number_format($stats['visitors']['total'] ?? 0); ?></span>
            </div>
        </div>
        <div class="flex items-center text-xs text-green-600">
            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
            </svg>
            <span>From last month</span>
        </div>
    </div>
    </div>
    
    <!-- Content Stats -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <!-- Popular Categories -->
        <div class="card p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-gray-700 font-semibold">Popular Categories</h3>
                <a href="index.php?page=categories" class="text-primary hover:text-primary-dark text-sm">View All</a>
            </div>
            <div class="space-y-4">
                <?php 
                $displayed = 0;
                foreach ($popular_categories as $category): 
                    if ($displayed >= 5) break; // Show only top 5
                    $displayed++;
                ?>
                <div class="flex items-center justify-between">
                    <span class="text-gray-700"><?php echo htmlspecialchars($category['name']); ?></span>
                    <span class="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                        <?php echo $category['count'] ?? 0; ?> posts
                    </span>
                </div>
                <?php endforeach; ?>
                
                <?php if (count($popular_categories) === 0): ?>
                <div class="text-gray-500 text-sm">No categories found</div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Popular Tags -->
        <div class="card p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-gray-700 font-semibold">Popular Tags</h3>
                <a href="index.php?page=tags" class="text-primary hover:text-primary-dark text-sm">View All</a>
            </div>
            <div class="flex flex-wrap gap-2">
                <?php 
                $displayed = 0;
                foreach ($popular_tags as $tag): 
                    if ($displayed >= 10) break; // Show only top 10
                    $displayed++;
                ?>
                <span class="px-2 py-1 bg-gray-100 text-gray-800 rounded text-xs">
                    <?php echo htmlspecialchars($tag['name']); ?> (<?php echo $tag['count'] ?? 0; ?>)
                </span>
                <?php endforeach; ?>
                
                <?php if (count($popular_tags) === 0): ?>
                <div class="text-gray-500 text-sm">No tags found</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- API Requests Analytics -->
    <div class="card p-6 mb-8">
        <div class="flex items-center justify-between mb-6">
            <h3 class="text-gray-700 font-semibold">API Requests Analytics</h3>
            <div class="flex space-x-2">
                <button class="px-3 py-1 text-sm bg-primary-light text-primary rounded-md">Week</button>
                <button class="px-3 py-1 text-sm text-gray-500 hover:bg-gray-100 rounded-md">Month</button>
                <button class="px-3 py-1 text-sm text-gray-500 hover:bg-gray-100 rounded-md">Year</button>
            </div>
        </div>
        
        <?php
        // Get last 7 days data
        $days = [];
        $max_requests = 0;
        
        // Current date
        $date = new DateTime();
        
        // Get data for the last 7 days
        for ($i = 0; $i < 7; $i++) {
            $day_key = $date->format('Y-m-d');
            $day_name = $date->format('D');
            
            $day_stats = $stats['daily']['days'][$day_key] ?? [
                'total_requests' => 0,
                'successful_requests' => 0,
                'failed_requests' => 0
            ];
            
            $days[$day_key] = [
                'name' => $day_name,
                'total' => $day_stats['total_requests'],
                'success' => $day_stats['successful_requests'],
                'failed' => $day_stats['failed_requests']
            ];
            
            $max_requests = max($max_requests, $day_stats['total_requests']);
            
            // Go to previous day
            $date->modify('-1 day');
        }
        
        // Reverse to show oldest to newest
        $days = array_reverse($days, true);
        ?>
        
        <div class="grid grid-cols-7 gap-2 h-64">
            <?php foreach ($days as $day): ?>
                <?php 
                $height_percent = $max_requests > 0 ? ($day['total'] / $max_requests) * 100 : 0;
                $success_height = $day['total'] > 0 ? ($day['success'] / $day['total']) * $height_percent : 0;
                $failed_height = $day['total'] > 0 ? ($day['failed'] / $day['total']) * $height_percent : 0;
                ?>
                <div class="flex flex-col items-center">
                    <div class="flex-1 w-full flex flex-col-reverse">
                        <div class="bg-gray-200 w-full relative" style="height: <?php echo $height_percent; ?>%">
                            <div class="absolute bottom-0 left-0 right-0 bg-green-500" style="height: <?php echo $success_height; ?>%"></div>
                            <div class="absolute bottom-0 left-0 right-0 bg-red-500" style="height: <?php echo $failed_height; ?>%; top: <?php echo $success_height; ?>%"></div>
                        </div>
                    </div>
                    <div class="text-xs text-gray-500 mt-2"><?php echo $day['name']; ?></div>
                    <div class="text-xs font-semibold"><?php echo $day['total']; ?></div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="flex justify-center mt-4 text-sm">
            <div class="flex items-center mr-4">
                <div class="w-3 h-3 bg-green-500 mr-1"></div>
                <span>Success</span>
            </div>
            <div class="flex items-center">
                <div class="w-3 h-3 bg-red-500 mr-1"></div>
                <span>Failed</span>
            </div>
        </div>
    </div>
    
    <!-- System Info -->
    <div class="card p-6">
        <div class="flex items-center justify-between mb-4">
            <h3 class="text-gray-700 font-semibold">System Information</h3>
            <span class="text-xs text-gray-500">Last updated: <?php echo date('Y-m-d H:i:s'); ?></span>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <div class="mb-2">
                    <span class="text-gray-600 font-semibold">PHP Version:</span>
                    <span class="text-gray-800"><?php echo phpversion(); ?></span>
                </div>
                <div class="mb-2">
                    <span class="text-gray-600 font-semibold">Server:</span>
                    <span class="text-gray-800"><?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?></span>
                </div>
                <div class="mb-2">
                    <span class="text-gray-600 font-semibold">Debug Mode:</span>
                    <span class="<?php echo $debug_mode === 'Enabled' ? 'text-yellow-600' : 'text-green-600'; ?>">
                        <?php echo $debug_mode; ?>
                    </span>
                </div>
            </div>
            <div>
                <div class="mb-2">
                    <span class="text-gray-600 font-semibold">Config File:</span>
                    <span class="<?php echo $config_status === 'OK' ? 'text-green-600' : 'text-red-600'; ?>">
                        <?php echo $config_status; ?>
                    </span>
                </div>
                <div class="mb-2">
                    <span class="text-gray-600 font-semibold">Config Writable:</span>
                    <span class="<?php echo $config_writable === 'Yes' ? 'text-green-600' : 'text-yellow-600'; ?>">
                        <?php echo $config_writable; ?>
                    </span>
                </div>
                <div class="mb-2">
                    <span class="text-gray-600 font-semibold">API Key Set:</span>
                    <span class="<?php echo !empty($GLOBALS['adminConfig']['api']['rapidapi_key']) ? 'text-green-600' : 'text-red-600'; ?>">
                        <?php echo !empty($GLOBALS['adminConfig']['api']['rapidapi_key']) ? 'Yes' : 'No'; ?>
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>
