<?php
// Initialize variables
$articleId = $_GET['id'] ?? '';
$article = [
    'title' => '',
    'slug' => '',
    'meta_description' => '',
    'excerpt' => '',
    'content' => '',
    'featured_image' => '',
    'author' => '',
    'tags' => '',
    'published_date' => date('Y-m-d'),
    'status' => 'published'
];

// If editing an existing article
if (!empty($articleId) && isset($config['articles'][$articleId])) {
    $article = $config['articles'][$articleId];
}

// Process form submission
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $title = $_POST['title'] ?? '';
    $slug = $_POST['slug'] ?? '';
    $metaDescription = $_POST['meta_description'] ?? '';
    $content = $_POST['content'] ?? '';
    
    // Generate slug if empty
    if (empty($slug) && !empty($title)) {
        $slug = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $title));
        $slug = trim($slug, '-');
    }
    
    // Get additional form data
    $excerpt = $_POST['excerpt'] ?? '';
    $featuredImage = $_POST['featured_image'] ?? '';
    $author = $_POST['author'] ?? '';
    $tags = $_POST['tags'] ?? '';
    $publishedDate = $_POST['published_date'] ?? date('Y-m-d');
    
    // Create or update article
    $newArticle = [
        'title' => $title,
        'slug' => $slug,
        'meta_description' => $metaDescription,
        'excerpt' => $excerpt,
        'content' => $content,
        'featured_image' => $featuredImage,
        'author' => $author,
        'tags' => $tags,
        'published_date' => $publishedDate,
        'status' => 'published'
    ];
    
    // Generate new ID if needed
    if (empty($articleId)) {
        $articleId = 'article_' . time();
    }
    
    // Save article
    $config['articles'][$articleId] = $newArticle;
    
    if (saveConfig($config)) {
        $message = 'Article saved successfully!';
        $messageType = 'success';
        $article = $newArticle; // Update current article with saved data
    } else {
        $message = 'Failed to save article. Please check file permissions.';
        $messageType = 'error';
    }
}
?>

<div class="bg-white shadow rounded-lg p-6">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-xl font-semibold"><?php echo empty($articleId) || !isset($config['articles'][$articleId]) ? 'Add New Article' : 'Edit Article'; ?></h2>
        <a href="?page=articles" class="text-blue-600 hover:text-blue-800">
            <i class="fas fa-arrow-left mr-1"></i> Back to Articles
        </a>
    </div>
    
    <?php if ($message): ?>
        <div class="mb-4 p-4 rounded <?php echo $messageType === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>
    
    <form method="POST" action="">
        <div class="mb-6">
            <label for="title" class="block text-sm font-medium text-gray-700 mb-1">Article Title</label>
            <input 
                type="text" 
                id="title" 
                name="title" 
                value="<?php echo htmlspecialchars($article['title']); ?>"
                class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                placeholder="How to Download Pinterest Videos"
                required
            >
        </div>
        
        <div class="mb-6">
            <label for="slug" class="block text-sm font-medium text-gray-700 mb-1">Slug (URL)</label>
            <div class="flex">
                <span class="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 sm:text-sm">
                    /article/
                </span>
                <input 
                    type="text" 
                    id="slug" 
                    name="slug" 
                    value="<?php echo htmlspecialchars($article['slug']); ?>"
                    class="flex-1 min-w-0 block w-full px-3 py-2 rounded-none rounded-r-md focus:ring-blue-500 focus:border-blue-500 sm:text-sm border-gray-300"
                    placeholder="how-to-download-pinterest-videos"
                >
            </div>
            <p class="mt-1 text-sm text-gray-500">
                Leave empty to generate automatically from title
            </p>
        </div>
        
        <div class="mb-6">
            <label for="meta_description" class="block text-sm font-medium text-gray-700 mb-1">Meta Description</label>
            <textarea 
                id="meta_description" 
                name="meta_description" 
                rows="2"
                class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                placeholder="A brief description of your article (150-160 characters recommended)"
            ><?php echo htmlspecialchars($article['meta_description'] ?? ''); ?></textarea>
            <p class="mt-1 text-xs text-gray-500">Used for SEO purposes in meta tags (150-160 characters recommended)</p>
        </div>
        
        <div class="mb-6">
            <label for="excerpt" class="block text-sm font-medium text-gray-700 mb-1">Article Excerpt</label>
            <textarea 
                id="excerpt" 
                name="excerpt" 
                rows="3"
                class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                placeholder="A short summary of your article to display in listings and previews"
            ><?php echo htmlspecialchars($article['excerpt'] ?? ''); ?></textarea>
            <p class="mt-1 text-xs text-gray-500">This will be displayed in article previews and listings</p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
                <label for="featured_image" class="block text-sm font-medium text-gray-700 mb-1">Featured Image URL</label>
                <input 
                    type="text" 
                    id="featured_image" 
                    name="featured_image" 
                    value="<?php echo htmlspecialchars($article['featured_image'] ?? ''); ?>"
                    class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                    placeholder="https://example.com/images/pinterest-video.jpg"
                >
                <p class="mt-1 text-xs text-gray-500">Full URL to the article's featured image</p>
            </div>
            
            <div>
                <label for="author" class="block text-sm font-medium text-gray-700 mb-1">Author</label>
                <input 
                    type="text" 
                    id="author" 
                    name="author" 
                    value="<?php echo htmlspecialchars($article['author'] ?? ''); ?>"
                    class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                    placeholder="John Doe"
                >
            </div>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
                <label for="tags" class="block text-sm font-medium text-gray-700 mb-1">Tags</label>
                <input 
                    type="text" 
                    id="tags" 
                    name="tags" 
                    value="<?php echo htmlspecialchars($article['tags'] ?? ''); ?>"
                    class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                    placeholder="pinterest, videos, download, social media"
                >
                <p class="mt-1 text-xs text-gray-500">Comma-separated list of tags</p>
            </div>
            
            <div>
                <label for="published_date" class="block text-sm font-medium text-gray-700 mb-1">Published Date</label>
                <input 
                    type="date" 
                    id="published_date" 
                    name="published_date" 
                    value="<?php echo htmlspecialchars($article['published_date'] ?? date('Y-m-d')); ?>"
                    class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                >
            </div>
        </div>
        
        <div class="mb-6">
            <label for="content" class="block text-sm font-medium text-gray-700 mb-1">Article Content</label>
            <textarea 
                id="article-content" 
                name="content" 
                rows="15"
                class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
            ><?php echo htmlspecialchars($article['content']); ?></textarea>
        </div>
        
        <div class="flex justify-end space-x-3">
            <a 
                href="?page=articles" 
                class="inline-flex justify-center py-2 px-4 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
                Cancel
            </a>
            <button 
                type="submit" 
                class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
                Save Article
            </button>
        </div>
    </form>
</div>
