<?php
session_start();
require_once '../auth.php';
require_once '../functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: ../login.php');
    exit;
}

$config = loadConfig();
$success = $error = '';
$page = [];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $slug = $_POST['slug'] ?? '';
    $page = [
        'title' => $_POST['title'] ?? '',
        'content' => $_POST['content'] ?? '',
        'slug' => $slug,
        'show_in_footer' => isset($_POST['show_in_footer']),
        'meta_description' => $_POST['meta_description'] ?? ''
    ];

    // Validate inputs
    if (empty($page['title']) || empty($page['content']) || empty($page['slug'])) {
        $error = 'All fields are required.';
    } else {
        // Update or add the page
        $config['pages'][$slug] = $page;
        
        if (saveConfig($config)) {
            $success = 'Page saved successfully!';
        } else {
            $error = 'Failed to save page.';
        }
    }
} else {
    // Get page data for editing
    $slug = $_GET['slug'] ?? '';
    if ($slug && isset($config['pages'][$slug])) {
        $page = $config['pages'][$slug];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo empty($page) ? 'Add New Page' : 'Edit Page'; ?> - Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Quill.js Editor -->
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/quill-emoji@0.2.0/dist/quill-emoji.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/quill-emoji@0.2.0/dist/quill-emoji.js"></script>
    <style>
        /* Editor Styles */
        #editor-container {
            height: 400px;
            margin-bottom: 15px;
        }
        
        /* Preview Styles */
        #preview-container {
            display: none;
            height: 400px;
            margin-bottom: 15px;
            padding: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            overflow-y: auto;
            background: white;
        }
        
        /* Image Upload Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
        }
        
        .modal-content {
            position: relative;
            background: white;
            margin: 10% auto;
            padding: 20px;
            width: 80%;
            max-width: 500px;
            border-radius: 8px;
        }
        
        .close {
            position: absolute;
            right: 20px;
            top: 10px;
            font-size: 24px;
            cursor: pointer;
        }
        
        /* Custom Toolbar Styles */
        .ql-toolbar.ql-snow {
            border-top-left-radius: 4px;
            border-top-right-radius: 4px;
            background: #f8f9fa;
        }
        
        .ql-toolbar button {
            margin: 0 2px;
        }
        
        .ql-formats {
            margin-right: 10px !important;
        }
        .ql-editor {
            font-size: 16px;
            line-height: 1.5;
        }
        .ql-toolbar.ql-snow {
            border-top-left-radius: 4px;
            border-top-right-radius: 4px;
        }
        .ql-container.ql-snow {
            border-bottom-left-radius: 4px;
            border-bottom-right-radius: 4px;
            background: white;
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-2xl font-bold mb-6"><?php echo empty($page) ? 'Add New Page' : 'Edit Page'; ?></h1>
        
        <?php if ($success): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?php echo $success; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="post" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="title">
                    Title
                </label>
                <input type="text" name="title" id="title" value="<?php echo htmlspecialchars($page['title'] ?? ''); ?>" 
                       class="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-400">
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="slug">
                    Slug
                </label>
                <input type="text" name="slug" id="slug" value="<?php echo htmlspecialchars($page['slug'] ?? ''); ?>" 
                       class="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-400">
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="meta_description">
                    Meta Description
                </label>
                <textarea name="meta_description" id="meta_description" 
                          class="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-400"><?php echo htmlspecialchars($page['meta_description'] ?? ''); ?></textarea>
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2">
                    Content
                </label>
                <div class="flex space-x-4 mb-2">
                    <button type="button" id="edit-mode" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400">Edit</button>
                    <button type="button" id="preview-mode" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-400">Preview</button>
                </div>
                <div id="editor-container"><?php echo $page['content'] ?? ''; ?></div>
                <div id="preview-container"></div>
                <input type="hidden" name="content" id="content">
            </div>
            
            <!-- Image Upload Modal -->
            <div id="image-modal" class="modal">
                <div class="modal-content">
                    <span class="close">&times;</span>
                    <h2 class="text-xl font-bold mb-4">Insert Image</h2>
                    
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2">Upload Image</label>
                        <input type="file" id="image-upload" accept="image/*" class="w-full">
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2">Or Pinterest Image URL</label>
                        <input type="text" id="pinterest-url" placeholder="https://pinterest.com/pin/..." class="w-full px-3 py-2 border rounded">
                    </div>
                    
                    <button type="button" id="insert-image" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Insert Image</button>
                </div>
            </div>
            
            <div class="mb-6">
                <label class="flex items-center">
                    <input type="checkbox" name="show_in_footer" value="1" 
                           <?php echo (!empty($page['show_in_footer'])) ? 'checked' : ''; ?> 
                           class="mr-2">
                    <span class="text-gray-700">Show in Footer</span>
                </label>
            </div>
            
            <div class="flex items-center justify-between">
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:ring-2 focus:ring-blue-400">
                    Save Page
                </button>
                <a href="index.php" class="text-blue-500 hover:text-blue-700">Back to Pages</a>
            </div>
        </form>
    </div>

    <script>
        // Initialize Quill with extended options
        var quill = new Quill('#editor-container', {
            theme: 'snow',
            modules: {
                toolbar: {
                    container: [
                        [{ 'header': [1, 2, 3, false] }],
                        ['bold', 'italic', 'underline', 'strike'],
                        [{ 'color': [] }, { 'background': [] }],
                        [{ 'align': [] }],
                        [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                        [{ 'indent': '-1'}, { 'indent': '+1' }],
                        ['blockquote', 'code-block'],
                        ['link', 'image'],
                        ['clean'],
                        ['emoji']
                    ],
                    handlers: {
                        image: function() {
                            document.getElementById('image-modal').style.display = 'block';
                        }
                    }
                },
                'emoji-toolbar': true,
                'emoji-textarea': false,
                'emoji-shortname': true
            },
            placeholder: 'Write your content here...'
        });

        // Auto-generate slug from title
        document.getElementById('title').addEventListener('input', function() {
            if (!document.getElementById('slug').value) {
                document.getElementById('slug').value = this.value
                    .toLowerCase()
                    .replace(/[^a-z0-9]+/g, '-')
                    .replace(/(^-|-$)/g, '');
            }
        });

        // Preview Mode Toggle
        const editorContainer = document.getElementById('editor-container');
        const previewContainer = document.getElementById('preview-container');
        const editButton = document.getElementById('edit-mode');
        const previewButton = document.getElementById('preview-mode');

        editButton.addEventListener('click', function() {
            editorContainer.style.display = 'block';
            previewContainer.style.display = 'none';
            editButton.classList.replace('bg-gray-500', 'bg-blue-500');
            previewButton.classList.replace('bg-blue-500', 'bg-gray-500');
        });

        previewButton.addEventListener('click', function() {
            previewContainer.innerHTML = quill.root.innerHTML;
            editorContainer.style.display = 'none';
            previewContainer.style.display = 'block';
            previewButton.classList.replace('bg-gray-500', 'bg-blue-500');
            editButton.classList.replace('bg-blue-500', 'bg-gray-500');
        });

        // Image Upload Handling
        const imageModal = document.getElementById('image-modal');
        const closeBtn = document.querySelector('.close');
        const insertBtn = document.getElementById('insert-image');
        const fileInput = document.getElementById('image-upload');
        const urlInput = document.getElementById('pinterest-url');

        closeBtn.onclick = function() {
            imageModal.style.display = 'none';
        }

        window.onclick = function(event) {
            if (event.target == imageModal) {
                imageModal.style.display = 'none';
            }
        }

        insertBtn.onclick = function() {
            const formData = new FormData();
            
            if (fileInput.files.length > 0) {
                formData.append('image', fileInput.files[0]);
            } else if (urlInput.value) {
                formData.append('pinterest_url', urlInput.value);
            } else {
                alert('Please select an image or enter a Pinterest URL');
                return;
            }

            fetch('../upload_handler.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const range = quill.getSelection(true);
                    quill.insertEmbed(range.index, 'image', data.url);
                    imageModal.style.display = 'none';
                    fileInput.value = '';
                    urlInput.value = '';
                } else {
                    alert('Failed to upload image');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to upload image');
            });
        }

        // Update hidden input before form submission
        document.querySelector('form').onsubmit = function() {
            document.getElementById('content').value = quill.root.innerHTML;
            return true;
        };
    </script>
</body>
</html>
