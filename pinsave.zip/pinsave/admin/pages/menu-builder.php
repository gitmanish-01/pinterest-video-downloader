<?php
// Handle menu save
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['menu_data'])) {
    $menu_data = json_decode($_POST['menu_data'], true);
    $location = $_POST['menu_location'] ?? 'top';
    
    // Update menu in config
    if (!isset($config['menus'])) {
        $config['menus'] = ['locations' => []];
    }
    $config['menus']['locations'][$location] = $menu_data;
    saveConfig($config);
    
    header('Content-Type: application/json');
    echo json_encode(['success' => true]);
    exit;
}

// Get current menus
$menus = $config['menus']['locations'] ?? [
    'top' => [],
    'footer' => [],
    'sidebar' => []
];

// Get all posts and pages for the item selector
$posts = $config['articles'] ?? [];
$pages = $config['pages'] ?? [];
?>

<div class="container px-6 py-8 mx-auto">
    <div class="mb-6 flex justify-between items-center">
        <h1 class="text-2xl font-bold">Menu Builder</h1>
        <div class="flex gap-4">
            <select id="menuLocation" class="bg-white border rounded px-3 py-2">
                <option value="top">Top Menu</option>
                <option value="footer">Footer Menu</option>
                <option value="sidebar">Sidebar Menu</option>
            </select>
            <button id="saveMenu" class="bg-blue-500 hover:bg-blue-700 text-white px-4 py-2 rounded">
                Save Menu
            </button>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <!-- Menu Items Selector -->
        <div class="md:col-span-1 bg-white rounded-lg shadow-md p-4">
            <h2 class="font-bold text-lg mb-4">Add Menu Items</h2>
            
            <!-- Posts -->
            <div class="mb-4">
                <h3 class="font-semibold mb-2">Posts</h3>
                <div class="space-y-2 max-h-40 overflow-y-auto">
                    <?php foreach ($posts as $post_id => $post): ?>
                    <div class="flex items-center">
                        <button class="text-left w-full px-2 py-1 hover:bg-gray-100 rounded text-sm add-menu-item" 
                                data-type="post"
                                data-id="<?php echo htmlspecialchars($post_id); ?>"
                                data-title="<?php echo htmlspecialchars($post['title']); ?>"
                                data-url="/blog/<?php echo htmlspecialchars($post['slug']); ?>">
                            <?php echo htmlspecialchars($post['title']); ?>
                        </button>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Pages -->
            <div class="mb-4">
                <h3 class="font-semibold mb-2">Pages</h3>
                <div class="space-y-2 max-h-40 overflow-y-auto">
                    <?php foreach ($pages as $page_id => $page): ?>
                    <div class="flex items-center">
                        <button class="text-left w-full px-2 py-1 hover:bg-gray-100 rounded text-sm add-menu-item"
                                data-type="page"
                                data-id="<?php echo htmlspecialchars($page_id); ?>"
                                data-title="<?php echo htmlspecialchars($page['title']); ?>"
                                data-url="/page/<?php echo htmlspecialchars($page['slug']); ?>">
                            <?php echo htmlspecialchars($page['title']); ?>
                        </button>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Custom Link -->
            <div class="mb-4">
                <h3 class="font-semibold mb-2">Custom Link</h3>
                <div class="space-y-2">
                    <input type="text" id="customLinkTitle" placeholder="Link Text" 
                           class="w-full px-3 py-2 border rounded text-sm mb-2">
                    <input type="text" id="customLinkUrl" placeholder="URL (e.g., https://...)" 
                           class="w-full px-3 py-2 border rounded text-sm mb-2">
                    <button id="addCustomLink" 
                            class="w-full bg-gray-100 hover:bg-gray-200 px-3 py-2 rounded text-sm">
                        Add Custom Link
                    </button>
                </div>
            </div>
        </div>

        <!-- Menu Structure -->
        <div class="md:col-span-3 bg-white rounded-lg shadow-md p-4">
            <h2 class="font-bold text-lg mb-4">Menu Structure</h2>
            <div id="menuItems" class="space-y-2">
                <!-- Menu items will be inserted here -->
            </div>
            
            <!-- Empty State -->
            <div id="emptyMenu" class="text-center py-8 text-gray-500">
                Add menu items from the left panel to get started
            </div>
        </div>
    </div>
</div>

<!-- Menu Item Template -->
<template id="menuItemTemplate">
    <div class="menu-item bg-gray-50 border rounded p-3 cursor-move" data-id="">
        <div class="flex items-center justify-between">
            <div class="flex items-center space-x-3">
                <i class="fas fa-grip-vertical text-gray-400"></i>
                <div>
                    <input type="text" class="menu-item-title px-2 py-1 border rounded text-sm" value="">
                    <input type="text" class="menu-item-url px-2 py-1 border rounded text-sm mt-1" value="">
                </div>
            </div>
            <div class="flex items-center space-x-2">
                <button class="delete-menu-item text-red-600 hover:text-red-800">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    </div>
</template>

<!-- Include Sortable.js -->
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const menuItems = document.getElementById('menuItems');
    const emptyMenu = document.getElementById('emptyMenu');
    const menuLocation = document.getElementById('menuLocation');
    let currentMenuData = <?php echo json_encode($menus); ?>;
    
    // Initialize Sortable
    new Sortable(menuItems, {
        animation: 150,
        handle: '.fa-grip-vertical',
        onEnd: function() {
            updateEmptyState();
        }
    });

    // Load menu for selected location
    function loadMenu(location) {
        menuItems.innerHTML = '';
        const menuData = currentMenuData[location] || [];
        
        menuData.forEach(item => {
            addMenuItem(item.title, item.url, item.id);
        });
        
        updateEmptyState();
    }

    // Add menu item
    function addMenuItem(title, url, id = 'menu_' + Date.now()) {
        const template = document.getElementById('menuItemTemplate');
        const clone = template.content.cloneNode(true);
        
        const menuItem = clone.querySelector('.menu-item');
        menuItem.dataset.id = id;
        
        const titleInput = clone.querySelector('.menu-item-title');
        titleInput.value = title;
        
        const urlInput = clone.querySelector('.menu-item-url');
        urlInput.value = url;
        
        // Delete button
        clone.querySelector('.delete-menu-item').addEventListener('click', function() {
            menuItem.remove();
            updateEmptyState();
        });
        
        menuItems.appendChild(clone);
        updateEmptyState();
    }

    // Update empty state visibility
    function updateEmptyState() {
        emptyMenu.style.display = menuItems.children.length ? 'none' : 'block';
    }

    // Add menu item buttons
    document.querySelectorAll('.add-menu-item').forEach(button => {
        button.addEventListener('click', function() {
            const title = this.dataset.title;
            const url = this.dataset.url;
            addMenuItem(title, url);
        });
    });

    // Add custom link
    document.getElementById('addCustomLink').addEventListener('click', function() {
        const title = document.getElementById('customLinkTitle').value.trim();
        const url = document.getElementById('customLinkUrl').value.trim();
        
        if (title && url) {
            addMenuItem(title, url);
            document.getElementById('customLinkTitle').value = '';
            document.getElementById('customLinkUrl').value = '';
        }
    });

    // Save menu
    document.getElementById('saveMenu').addEventListener('click', function() {
        const items = [];
        menuItems.querySelectorAll('.menu-item').forEach(item => {
            items.push({
                id: item.dataset.id,
                title: item.querySelector('.menu-item-title').value,
                url: item.querySelector('.menu-item-url').value
            });
        });
        
        const location = menuLocation.value;
        
        // Save to server
        fetch('menu-builder.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `menu_data=${encodeURIComponent(JSON.stringify(items))}&menu_location=${encodeURIComponent(location)}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update current menu data
                currentMenuData[location] = items;
                alert('Menu saved successfully!');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error saving menu');
        });
    });

    // Handle menu location change
    menuLocation.addEventListener('change', function() {
        loadMenu(this.value);
    });

    // Load initial menu
    loadMenu('top');
});
</script>
