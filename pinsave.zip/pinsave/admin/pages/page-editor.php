<?php
// Check if user is logged in
if (!isAdminLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Get the page to edit
$page_type = isset($_GET['type']) ? $_GET['type'] : 'about';
$valid_pages = ['about', 'contact', 'privacy', 'terms', 'faq', 'dmca'];
if (!in_array($page_type, $valid_pages)) {
    $page_type = 'about';
}

// Page titles
$page_titles = [
    'about' => 'About Us',
    'contact' => 'Contact Us',
    'privacy' => 'Privacy Policy',
    'terms' => 'Terms of Service',
    'faq' => 'Frequently Asked Questions',
    'dmca' => 'DMCA Policy'
];

// Get current page content
$pageContent = $adminConfig['pages'][$page_type] ?? [];

// Default values
$defaults = [
    'about' => [
        'title' => 'About Us',
        'content' => '<p>Welcome to PinSave, your go-to solution for downloading Pinterest videos without watermark.</p><p>Our mission is to provide a simple, fast, and reliable tool for saving Pinterest videos in high quality. Whether you need content for personal use, inspiration, or creative projects, PinSave makes it easy to download and save Pinterest videos.</p><p>Founded in 2023, PinSave has helped thousands of users download their favorite Pinterest videos hassle-free.</p>',
        'meta_title' => 'About Us - PinSave Pinterest Video Downloader',
        'meta_description' => 'Learn more about PinSave, the free online tool for downloading Pinterest videos without watermark in high quality.',
        'meta_keywords' => 'about pinsave, pinterest video downloader about, pinterest video saver'
    ],
    'contact' => [
        'title' => 'Contact Us',
        'content' => '<p>Have questions or feedback about PinSave? We would love to hear from you!</p><p>For general inquiries, technical support, or feedback, please use the contact form below or email us directly.</p>',
        'email' => 'contact@example.com',
        'meta_title' => 'Contact Us - PinSave Pinterest Video Downloader',
        'meta_description' => 'Contact the PinSave team for support, feedback, or inquiries about our Pinterest video downloader tool.',
        'meta_keywords' => 'contact pinsave, pinterest video downloader support, pinterest video saver contact'
    ],
    'privacy' => [
        'title' => 'Privacy Policy',
        'content' => '<h2>Privacy Policy for PinSave</h2><p>Last Updated: ' . date('F d, Y') . '</p><p>At PinSave, we respect your privacy and are committed to protecting your personal data. This Privacy Policy explains how we collect, use, and safeguard your information when you use our Pinterest video downloader service.</p>',
        'meta_title' => 'Privacy Policy - PinSave Pinterest Video Downloader',
        'meta_description' => 'Read about how PinSave handles your data and protects your privacy when using our Pinterest video downloader tool.',
        'meta_keywords' => 'pinsave privacy policy, pinterest video downloader privacy, data protection'
    ],
    'terms' => [
        'title' => 'Terms of Service',
        'content' => '<h2><i class="fas fa-file-contract text-blue-600"></i> Terms of Service for PinSave</h2><p><strong>Last Updated:</strong> ' . date('F d, Y') . '</p><p>Welcome to PinSave. By accessing or using our website, you agree to be bound by these Terms of Service.</p>',
        'meta_title' => 'Terms of Service - PinSave Pinterest Video Downloader',
        'meta_description' => 'Read the Terms of Service for using PinSave, the free Pinterest video downloader tool.',
        'meta_keywords' => 'pinsave terms, pinterest video downloader terms, terms of service, pinterest video saver terms'
    ],
    'faq' => [
        'title' => 'Frequently Asked Questions',
        'content' => '<h2><i class="fas fa-question-circle text-blue-600"></i> Frequently Asked Questions</h2><p>Find answers to the most common questions about using PinSave to download Pinterest videos.</p><h3>How do I download a Pinterest video?</h3><p>Simply copy the Pinterest video URL and paste it into the input field on our homepage, then click the Download button.</p><h3>Is PinSave free to use?</h3><p>Yes, PinSave is completely free to use with no hidden charges.</p><h3>What video quality can I download?</h3><p>PinSave allows you to download Pinterest videos in the highest available quality.</p>',
        'meta_title' => 'FAQ - PinSave Pinterest Video Downloader',
        'meta_description' => 'Frequently asked questions about using PinSave to download Pinterest videos without watermark.',
        'meta_keywords' => 'pinsave faq, pinterest video downloader help, pinterest video saver questions, how to download pinterest videos'
    ],
    'dmca' => [
        'title' => 'DMCA Policy',
        'content' => '<h2><i class="fas fa-gavel text-blue-600"></i> DMCA Policy</h2><p><strong>Last Updated:</strong> ' . date('F d, Y') . '</p><p>PinSave respects the intellectual property rights of others and expects its users to do the same. In accordance with the Digital Millennium Copyright Act of 1998 ("DMCA"), we will respond expeditiously to claims of copyright infringement that are reported to our designated copyright agent.</p><h3>How to Submit a DMCA Notice</h3><p>If you believe that your copyrighted work has been copied in a way that constitutes copyright infringement, please provide our copyright agent with the following information:</p><ul><li>A physical or electronic signature of the copyright owner or a person authorized to act on their behalf</li><li>Identification of the copyrighted work claimed to have been infringed</li><li>Identification of the material that is claimed to be infringing or to be the subject of infringing activity</li><li>Your contact information, including your address, telephone number, and an email address</li><li>A statement by you that you have a good faith belief that use of the material in the manner complained of is not authorized by the copyright owner, its agent, or the law</li><li>A statement that the information in the notification is accurate, and, under penalty of perjury, that you are authorized to act on behalf of the copyright owner</li></ul>',
        'meta_title' => 'DMCA Policy - PinSave Pinterest Video Downloader',
        'meta_description' => 'Read about PinSave\'s DMCA policy and how to report copyright infringement related to Pinterest videos.',
        'meta_keywords' => 'pinsave dmca, pinterest video downloader copyright, dmca takedown, copyright policy'
    ]
];

// Merge with defaults
foreach ($defaults[$page_type] as $key => $value) {
    if (!isset($pageContent[$key])) {
        $pageContent[$key] = $value;
    }
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $pageContent['title'] = trim($_POST['title'] ?? '');
    $pageContent['content'] = $_POST['content'] ?? '';
    $pageContent['meta_title'] = trim($_POST['meta_title'] ?? '');
    $pageContent['meta_description'] = trim($_POST['meta_description'] ?? '');
    $pageContent['meta_keywords'] = trim($_POST['meta_keywords'] ?? '');
    
    // Contact page specific field
    if ($page_type === 'contact') {
        $pageContent['email'] = trim($_POST['email'] ?? '');
    }
    
    // Update config
    $adminConfig['pages'][$page_type] = $pageContent;
    
    // Save config
    if (saveConfig($adminConfig)) {
        $success = "Page content updated successfully!";
    } else {
        $error = "Failed to save page content. Please check file permissions.";
    }
}
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">Edit <?php echo htmlspecialchars($page_titles[$page_type]); ?> Page</h5>
                </div>
                <div class="card-body">
                    <!-- Page Type Navigation -->
                    <div class="mb-4">
                        <div class="btn-group" role="group">
                            <?php foreach ($valid_pages as $page): ?>
                            <a href="index.php?page=page-editor&type=<?php echo $page; ?>" class="btn <?php echo $page_type === $page ? 'btn-primary' : 'btn-outline-primary'; ?>">
                                <?php echo htmlspecialchars($page_titles[$page]); ?>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- Success/Error Messages -->
                    <?php if (isset($success)): ?>
                    <div class="alert alert-success">
                        <?php echo $success; ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (isset($error)): ?>
                    <div class="alert alert-danger">
                        <?php echo $error; ?>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Page Edit Form -->
                    <form method="post" action="">
                        <div class="mb-3">
                            <label for="title" class="form-label">Page Title</label>
                            <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($pageContent['title']); ?>" required>
                            <small class="form-text text-muted">This is the main heading (H1) displayed on the page.</small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="content" class="form-label">Page Content</label>
                            <textarea class="form-control" id="content" name="content" rows="10" required><?php echo htmlspecialchars($pageContent['content']); ?></textarea>
                            <small class="form-text text-muted">HTML is allowed for formatting. Use &lt;p&gt;, &lt;h2&gt;, &lt;h3&gt;, &lt;ul&gt;, &lt;li&gt; tags for structure.</small>
                        </div>
                        
                        <?php if ($page_type === 'contact'): ?>
                        <div class="mb-3">
                            <label for="email" class="form-label">Contact Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($pageContent['email'] ?? ''); ?>" required>
                            <small class="form-text text-muted">Email address displayed on the contact page.</small>
                        </div>
                        <?php endif; ?>
                        
                        <hr class="my-4">
                        
                        <h6 class="mb-3">SEO Settings</h6>
                        
                        <div class="mb-3">
                            <label for="meta_title" class="form-label">Meta Title</label>
                            <input type="text" class="form-control" id="meta_title" name="meta_title" value="<?php echo htmlspecialchars($pageContent['meta_title']); ?>" required>
                            <small class="form-text text-muted">Recommended length: 50-60 characters.</small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="meta_description" class="form-label">Meta Description</label>
                            <textarea class="form-control" id="meta_description" name="meta_description" rows="3" required><?php echo htmlspecialchars($pageContent['meta_description']); ?></textarea>
                            <small class="form-text text-muted">Recommended length: 150-160 characters.</small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="meta_keywords" class="form-label">Meta Keywords</label>
                            <input type="text" class="form-control" id="meta_keywords" name="meta_keywords" value="<?php echo htmlspecialchars($pageContent['meta_keywords']); ?>">
                            <small class="form-text text-muted">Comma-separated list of keywords.</small>
                        </div>
                        
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                            <a href="../../pages/<?php echo $page_type; ?>.php" target="_blank" class="btn btn-outline-secondary ml-2">View Page</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Include CKEditor - Free rich text editor -->
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize CKEditor
        ClassicEditor
            .create(document.querySelector('#content'), {
                toolbar: [
                    'heading',
                    '|',
                    'bold', 'italic', 'link',
                    '|',
                    'bulletedList', 'numberedList',
                    '|',
                    'indent', 'outdent',
                    '|',
                    'blockQuote', 'insertTable', 'undo', 'redo'
                ],
                placeholder: 'Write your content here...'
            })
            .catch(error => {
                console.error(error);
            });
    });
</script>
