<?php
// Include configuration
require_once '../includes/config.php';

// Require login
requireLogin();

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'add_page' || $_POST['action'] === 'edit_page') {
            $pageId = $_POST['page_id'] ?? uniqid();
            $config['pages'][$pageId] = [
                'title' => $_POST['title'],
                'content' => $_POST['content'],
                'slug' => $_POST['slug'],
                'show_in_footer' => isset($_POST['show_in_footer']),
                'meta_description' => $_POST['meta_description']
            ];
            
            if (saveConfig($config)) {
                $success = 'Page saved successfully!';
            } else {
                $error = 'Failed to save page.';
            }
        } elseif ($_POST['action'] === 'delete_page' && isset($_POST['page_id'])) {
            if (isset($config['pages'][$_POST['page_id']])) {
                unset($config['pages'][$_POST['page_id']]);
                if (saveConfig($config)) {
                    $success = 'Page deleted successfully!';
                } else {
                    $error = 'Failed to delete page.';
                }
            }
        }
    }
}

// Get current pages
$pages = $config['pages'] ?? [];
?>

<!-- Header -->
<?php include '../includes/header.php'; ?>

<!-- Main Content -->
<div class="container mx-auto px-4 py-8">
    <div class="bg-white rounded-lg shadow-md p-6">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold">Page Management</h2>
            <button onclick="showAddPageForm()" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                Add New Page
            </button>
        </div>
        
        <?php if (isset($success)): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
            <p><?php echo htmlspecialchars($success); ?></p>
        </div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
            <p><?php echo htmlspecialchars($error); ?></p>
        </div>
        <?php endif; ?>
        
        <!-- Pages List -->
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="px-4 py-2 text-left">Title</th>
                        <th class="px-4 py-2 text-left">Slug</th>
                        <th class="px-4 py-2 text-center">Show in Footer</th>
                        <th class="px-4 py-2 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pages as $pageId => $page): ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?php echo htmlspecialchars($page['title']); ?></td>
                        <td class="px-4 py-2"><?php echo htmlspecialchars($page['slug']); ?></td>
                        <td class="px-4 py-2 text-center">
                            <?php echo $page['show_in_footer'] ? '✓' : '✗'; ?>
                        </td>
                        <td class="px-4 py-2 text-right">
                            <button onclick="editPage('<?php echo $pageId; ?>')" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-3 rounded text-sm">
                                Edit
                            </button>
                            <button onclick="deletePage('<?php echo $pageId; ?>')" class="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-3 rounded text-sm ml-2">
                                Delete
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Page Form Modal -->
<div id="pageFormModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-full max-w-3xl shadow-lg rounded-md bg-white">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-xl font-bold" id="modalTitle">Add New Page</h3>
            <button onclick="closePageForm()" class="text-gray-600 hover:text-gray-800">&times;</button>
        </div>
        
        <form method="POST" action="" id="pageForm">
            <input type="hidden" name="action" id="formAction" value="add_page">
            <input type="hidden" name="page_id" id="pageId" value="">
            
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="title">
                    Page Title
                </label>
                <input type="text" id="title" name="title" required
                    class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="slug">
                    URL Slug
                </label>
                <input type="text" id="slug" name="slug" required
                    class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="content">
                    Page Content
                </label>
                <textarea id="content" name="content" rows="6" required
                    class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"></textarea>
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="meta_description">
                    Meta Description
                </label>
                <textarea id="meta_description" name="meta_description" rows="2"
                    class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"></textarea>
            </div>
            
            <div class="mb-6">
                <label class="flex items-center">
                    <input type="checkbox" id="show_in_footer" name="show_in_footer" class="form-checkbox">
                    <span class="ml-2">Show in Footer</span>
                </label>
            </div>
            
            <div class="flex items-center justify-end">
                <button type="button" onclick="closePageForm()" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded mr-2">
                    Cancel
                </button>
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    Save Page
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <h3 class="text-lg font-bold mb-4">Confirm Delete</h3>
        <p class="mb-4">Are you sure you want to delete this page? This cannot be undone.</p>
        
        <form method="POST" action="" id="deleteForm">
            <input type="hidden" name="action" value="delete_page">
            <input type="hidden" name="page_id" id="deletePageId" value="">
            
            <div class="flex items-center justify-end">
                <button type="button" onclick="closeDeleteModal()" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded mr-2">
                    Cancel
                </button>
                <button type="submit" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                    Delete
                </button>
            </div>
        </form>
    </div>
</div>

<script>
const pages = <?php echo json_encode($pages); ?>;

function showAddPageForm() {
    document.getElementById('modalTitle').textContent = 'Add New Page';
    document.getElementById('formAction').value = 'add_page';
    document.getElementById('pageId').value = '';
    document.getElementById('pageForm').reset();
    document.getElementById('pageFormModal').classList.remove('hidden');
}

function editPage(pageId) {
    const page = pages[pageId];
    if (!page) return;
    
    document.getElementById('modalTitle').textContent = 'Edit Page';
    document.getElementById('formAction').value = 'edit_page';
    document.getElementById('pageId').value = pageId;
    
    document.getElementById('title').value = page.title;
    document.getElementById('slug').value = page.slug;
    document.getElementById('content').value = page.content;
    document.getElementById('meta_description').value = page.meta_description;
    document.getElementById('show_in_footer').checked = page.show_in_footer;
    
    document.getElementById('pageFormModal').classList.remove('hidden');
}

function closePageForm() {
    document.getElementById('pageFormModal').classList.add('hidden');
}

function deletePage(pageId) {
    document.getElementById('deletePageId').value = pageId;
    document.getElementById('deleteModal').classList.remove('hidden');
}

function closeDeleteModal() {
    document.getElementById('deleteModal').classList.add('hidden');
}

// Auto-generate slug from title
document.getElementById('title').addEventListener('input', function(e) {
    if (document.getElementById('formAction').value === 'add_page') {
        const slug = e.target.value
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/(^-|-$)/g, '');
        document.getElementById('slug').value = slug;
    }
});
</script>

<!-- Footer -->
<?php include '../includes/footer.php'; ?>
