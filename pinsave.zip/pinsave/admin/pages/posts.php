<?php
// Handle post deletion
if (isset($_POST['action']) && $_POST['action'] === 'delete' && isset($_POST['post_id'])) {
    $post_id = $_POST['post_id'];
    if (isset($adminConfig['posts'][$post_id])) {
        unset($adminConfig['posts'][$post_id]);
        saveConfig($adminConfig);
        
        // Use JavaScript redirect instead of header() to avoid 'headers already sent' errors
        echo "<script>window.location.href = 'index.php?page=posts&deleted=1';</script>";
        exit;
    }
}

// Get all posts
$posts = $adminConfig['posts'] ?? [];

// Sort posts by created date (newest first)
uasort($posts, function($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
});
?>

<div class="p-6 flex flex-col flex-grow">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-2xl font-bold text-gray-800">Manage Posts</h1>
            <p class="text-sm text-gray-500 mt-1">Create, edit and manage your blog content</p>
        </div>
        <a href="index.php?page=post-editor" class="btn btn-primary flex items-center">
            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
            </svg>
            Create New Post
        </a>
    </div>

    <?php if (isset($_GET['success'])): ?>
    <div class="card p-4 mb-6 border-l-4 border-green-500 bg-green-50">
        <div class="flex items-center">
            <svg class="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <span class="text-green-700">Post saved successfully!</span>
        </div>
    </div>
    <?php endif; ?>

    <?php if (isset($_GET['deleted'])): ?>
    <div class="card p-4 mb-6 border-l-4 border-green-500 bg-green-50">
        <div class="flex items-center">
            <svg class="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <span class="text-green-700">Post deleted successfully!</span>
        </div>
    </div>
    <?php endif; ?>

    <div class="card flex flex-col h-full">
        <div class="card-header">
            <h3 class="card-title">All Posts</h3>
            <div class="flex items-center space-x-2">
                <div class="relative">
                    <input type="text" placeholder="Search posts..." class="form-input pl-8 py-2 text-sm rounded-lg border border-gray-300 focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-20">
                    <svg class="w-4 h-4 text-gray-400 absolute left-2.5 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                    </svg>
                </div>
                <select class="form-select py-2 text-sm rounded-lg border border-gray-300 focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-20">
                    <option>All Status</option>
                    <option>Public</option>
                    <option>Draft</option>
                </select>
            </div>
        </div>
        <div class="table-container flex-grow overflow-auto">
            <table class="min-w-full">
                <thead>
                    <tr>
                        <th class="px-6 py-3 text-left">
                            Title
                        </th>
                        <th class="px-6 py-3 text-left">
                            Status
                        </th>
                        <th class="px-6 py-3 text-left">
                            Date
                        </th>
                        <th class="px-6 py-3 text-right">
                            Actions
                        </th>
                    </tr>
                </thead>
            <tbody>
                <?php if (empty($posts)): ?>
                <tr>
                    <td colspan="4" class="px-6 py-8 text-center">
                        <div class="flex flex-col items-center">
                            <svg class="w-12 h-12 text-gray-300 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                            <p class="text-gray-500 mb-2">No posts found</p>
                            <a href="index.php?page=post-editor" class="btn btn-primary btn-sm">Create your first post</a>
                        </div>
                    </td>
                </tr>
                <?php else: ?>
                    <?php foreach ($posts as $post_id => $post): ?>
                    <tr>
                        <td class="px-6 py-4">
                            <div class="text-sm font-medium text-gray-900">
                                <?php echo htmlspecialchars($post['title']); ?>
                            </div>
                            <div class="text-xs text-gray-500 flex items-center mt-1">
                                <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path>
                                </svg>
                                /blog/<?php echo htmlspecialchars($post['slug']); ?>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <span class="badge <?php echo $post['visibility'] === 'public' ? 'badge-success' : 'badge-info'; ?>">
                                <?php echo ucfirst($post['visibility']); ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-500">
                            <div class="flex items-center">
                                <svg class="w-3 h-3 mr-1 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                </svg>
                                <?php echo date('M j, Y', strtotime($post['created_at'])); ?>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <div class="table-actions">
                                <a href="index.php?page=post-editor&id=<?php echo urlencode($post_id); ?>" class="btn-icon btn-secondary">
                                    <svg class="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                                    </svg>
                                </a>
                                <form method="post" class="inline-block">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="post_id" value="<?php echo htmlspecialchars($post_id); ?>">
                                    <button type="submit" class="btn-icon btn-danger" onclick="return confirm('Are you sure you want to delete this post?')">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                        </svg>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
            </div>
            <div class="card-footer flex items-center justify-between mt-auto">
                <div class="text-sm text-gray-600">
                    Showing <?php echo count($posts); ?> posts
                </div>
                <div class="flex space-x-1">
                    <button class="btn btn-sm btn-secondary" disabled>
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                        </svg>
                    </button>
                    <button class="btn btn-sm btn-secondary" disabled>
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    </div>

