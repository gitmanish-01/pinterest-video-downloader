<?php
require_once __DIR__ . '/../../includes/stats_handler.php';
require_once __DIR__ . '/../../includes/api_handler.php';
// Initialize handlers
$stats_handler = new StatsHandler();
$api_handler = new ApiHandler();

// Initialize default values
$categories = [];
$tags = [];
$published_posts = [];
$total_requests = 0;
$today_stats = ['total_requests' => 0, 'successful_requests' => 0, 'failed_requests' => 0];
$api_status = false;
try {
    // Get taxonomy data
    require_once __DIR__ . '/../../includes/taxonomy.php';
    $taxonomy = new Taxonomy($config);
    $categories = $taxonomy->getCategories() ?? [];
    $tags = $taxonomy->getTags() ?? [];
    $all_posts = $taxonomy->getPosts() ?? [];
    $published_posts = array_filter($all_posts, function($post) {
        return isset($post['visibility']) && $post['visibility'] === 'public';
    });

    // Get statistics with error handling
    $stats = $stats_handler->getStats() ?? [];
    $today_stats = $stats['daily']['days'][date('Y-m-d')] ?? [
        'total_requests' => 0,
        'successful_requests' => 0,
        'failed_requests' => 0
    ];

    // Calculate total requests
    $total_requests = 0;
    if (isset($stats['daily']['days']) && is_array($stats['daily']['days'])) {
        foreach ($stats['daily']['days'] as $day) {
            $total_requests += isset($day['total_requests']) ? (int)$day['total_requests'] : 0;
        }
    }

    // Get API status
    $api_status = $api_handler->checkApiStatus();
} catch (Exception $e) {
    error_log('Dashboard Error: ' . $e->getMessage());
    $categories = [];
    $tags = [];
    $published_posts = [];
    $total_requests = 0;
    $today_stats = ['total_requests' => 0, 'successful_requests' => 0, 'failed_requests' => 0];
    $api_status = false;
}
?>

<div class="space-y-6">
    <!-- Welcome Section with Quick Stats -->
    <div class="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg shadow-lg p-6 text-white">
        <div class="flex justify-between items-center">
            <div>
                <h2 class="text-2xl font-bold mb-2">Welcome to PinSave Dashboard</h2>
                <p class="text-blue-100">Manage your Pinterest video downloader platform</p>
            </div>
            <div class="text-right">
                <div class="text-3xl font-bold mb-1"><?php echo number_format($total_requests); ?></div>
                <div class="text-blue-100">Total Downloads</div>
            </div>
        </div>
    </div>

    <!-- Status Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <!-- API Status Card -->
        <div class="bg-white rounded-lg shadow-sm p-6 border-l-4 <?php echo $api_status ? 'border-green-500' : 'border-red-500'; ?>">
            <h3 class="text-lg font-semibold mb-4">API Status</h3>
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <span class="text-sm font-medium">Status:</span>
                    <?php if ($api_status): ?>
                        <span class="ml-2 bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">Active</span>
                    <?php else: ?>
                        <span class="ml-2 bg-red-100 text-red-800 text-xs font-medium px-2.5 py-0.5 rounded">Inactive</span>
                    <?php endif; ?>
                </div>
                <div>
                    <span class="text-sm font-medium">Provider:</span>
                    <span class="ml-2 text-gray-600"><?php echo htmlspecialchars($config['api']['api_provider'] ?? 'Not set'); ?></span>
                </div>
            </div>

            <!-- Today's Stats -->
            <div class="mt-4">
                <h4 class="text-sm font-semibold mb-2">Today's Statistics</h4>
                <div class="grid grid-cols-3 gap-4">
                    <div class="text-center">
                        <div class="text-2xl font-bold text-blue-600"><?php echo number_format($today_stats['total_requests']); ?></div>
                        <div class="text-xs text-gray-500">Total</div>
                    </div>
                    <div class="text-center">
                        <div class="text-2xl font-bold text-green-600"><?php echo number_format($today_stats['successful_requests']); ?></div>
                        <div class="text-xs text-gray-500">Successful</div>
                    </div>
                    <div class="text-center">
                        <div class="text-2xl font-bold text-red-600"><?php echo number_format($today_stats['failed_requests']); ?></div>
                        <div class="text-xs text-gray-500">Failed</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Content Stats Cards -->
        <div class="bg-white rounded-lg shadow-sm p-6 border-t-4 border-blue-500">
            <div class="flex items-center justify-between">
                <div>
                    <h3 class="text-lg font-semibold mb-1">Content</h3>
                    <div class="text-3xl font-bold text-blue-600"><?php echo count($published_posts); ?></div>
                </div>
                <div class="text-right text-sm text-gray-500">
                    <div>Published Posts</div>
                </div>
            </div>
        </div>

        <!-- Categories Card -->
        <div class="bg-white rounded-lg shadow-sm p-6 border-t-4 border-green-500">
            <div class="flex items-center justify-between">
                <div>
                    <h3 class="text-lg font-semibold mb-1">Categories</h3>
                    <div class="text-3xl font-bold text-green-600"><?php echo count($categories); ?></div>
                </div>
                <div class="text-right text-sm text-gray-500">
                    <div>Organized Content</div>
                </div>
            </div>
        </div>

        <!-- Tags Card -->
        <div class="bg-white rounded-lg shadow-sm p-6 border-t-4 border-purple-500">
            <div class="flex items-center justify-between">
                <div>
                    <h3 class="text-lg font-semibold mb-1">Active Tags</h3>
                    <div class="text-3xl font-bold text-purple-600"><?php echo count($tags); ?></div>
                </div>
                <div class="text-right text-sm text-gray-500">
                    <div>Enhanced Search</div>
                </div>
            </div>
        </div>
    </div>

    <!-- System Information -->
        
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="flex items-center justify-between mb-4">
            <h3 class="font-semibold">System Information</h3>
            <span class="text-xs text-gray-500">Last updated: <?php echo date('Y-m-d H:i:s'); ?></span>
        </div>
    
    <!-- Content Statistics -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
        <!-- Popular Categories -->
        <div class="bg-white rounded-lg p-4 border border-gray-200">
            <h3 class="font-semibold mb-4">Popular Categories</h3>
            <div class="space-y-3">
                <?php
                $top_categories = array_slice($categories, 0, 5);
                foreach ($top_categories as $category):
                ?>
                <div class="flex items-center justify-between">
                    <span class="text-gray-700"><?php echo htmlspecialchars($category['name']); ?></span>
                    <span class="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">
                        <?php echo $category['count']; ?> posts
                    </span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <!-- Popular Tags -->
        <div class="bg-white rounded-lg p-4 border border-gray-200">
            <h3 class="font-semibold mb-4">Popular Tags</h3>
            <div class="flex flex-wrap gap-2">
                <?php
                $top_tags = array_slice($tags, 0, 10, true);
                foreach ($top_tags as $tag => $data):
                ?>
                <span class="bg-gray-100 text-gray-800 text-xs font-medium px-2.5 py-0.5 rounded">
                    #<?php echo htmlspecialchars($tag); ?>
                    <span class="text-gray-500">(<?php echo $data['count']; ?>)</span>
                </span>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <!-- API Requests Analytics -->
    <div class="bg-white rounded-lg shadow-sm p-6">
        <h3 class="font-semibold mb-4">API Requests (Last 7 Days)</h3>
        <div class="relative h-40 mt-4">
            <?php
            // Get last 7 days stats
            $daily_stats = [];
            $max_requests = 0;
            
            if (isset($stats['daily']['days'])) {
                // Get stats for last 7 days
                for ($i = 0; $i < 7; $i++) {
                    $date = date('Y-m-d', strtotime("-{$i} days"));
                    $daily_stats[$date] = $stats['daily']['days'][$date] ?? [
                        'total_requests' => 0,
                        'successful_requests' => 0,
                        'failed_requests' => 0
                    ];
                    
                    // Find max requests for scaling
                    $max_requests = max($max_requests, $daily_stats[$date]['total_requests']);
                }
            }
            
            // Scale factor (max height = 40px)
            $scale = $max_requests > 0 ? 40 / $max_requests : 1;
            
            // Generate bars
            $bar_width = 100 / 7; // percentage width for each bar
            $current_x = 0;
            
            for ($i = 0; $i < 7; $i++) {
                $date = date('Y-m-d', strtotime("-{$i} days"));
                $stats = $daily_stats[$date] ?? ['total_requests' => 0, 'successful_requests' => 0, 'failed_requests' => 0];
                $total_height = $stats['total_requests'] * $scale;
                $success_height = $stats['successful_requests'] * $scale;
                $failed_height = $stats['failed_requests'] * $scale;
            ?>
                <div class='absolute bottom-0' style='left: <?php echo $current_x; ?>%; width: <?php echo $bar_width; ?>%'>
                    <div class='relative h-full w-full flex flex-col justify-end items-center'>
                        <?php if ($failed_height > 0): ?>
                            <div class='w-8 bg-red-200' style='height: <?php echo $failed_height; ?>px' title='<?php echo $stats['failed_requests']; ?> failed'></div>
                        <?php endif; ?>
                        <?php if ($success_height > 0): ?>
                            <div class='w-8 bg-green-200' style='height: <?php echo $success_height; ?>px' title='<?php echo $stats['successful_requests']; ?> successful'></div>
                        <?php endif; ?>
                        <div class='text-xs text-gray-500 mt-2'><?php echo date('D', strtotime($date)); ?></div>
                    </div>
                </div>
            <?php
                $current_x += $bar_width;
            }
            ?>
            <!-- Y-axis labels -->
            <div class="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-gray-500">
                <span><?php echo $max_requests; ?></span>
                <span><?php echo round($max_requests/2); ?></span>
                <span>0</span>
            </div>
        </div>
        <div class="flex justify-center mt-4 text-sm">
            <div class="flex items-center mr-4">
                <div class="w-3 h-3 bg-green-200 mr-1"></div>
                <span>Successful</span>
            </div>
            <div class="flex items-center">
                <div class="w-3 h-3 bg-red-200 mr-1"></div>
                <span>Failed</span>
            </div>
        </div>
    </div>
    
    <!-- System Information -->
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="flex items-center justify-between mb-4">
            <h3 class="font-semibold">System Information</h3>
            <span class="text-xs text-gray-500">Last updated: <?php echo date('Y-m-d H:i:s'); ?></span>
        </div>
        <div class="bg-gray-50 rounded-lg overflow-hidden">
            <table class="min-w-full">
            <tbody>
                <tr>
                    <td class="py-2 px-4 border-b border-gray-200 font-medium">PHP Version</td>
                    <td class="py-2 px-4 border-b border-gray-200"><?php echo phpversion(); ?></td>
                </tr>
                <tr>
                    <td class="py-2 px-4 border-b border-gray-200 font-medium">Server</td>
                    <td class="py-2 px-4 border-b border-gray-200"><?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?></td>
                </tr>
                <tr>
                    <td class="py-2 px-4 border-b border-gray-200 font-medium">Configuration File</td>
                    <td class="py-2 px-4 border-b border-gray-200">
                        <?php 
                        $configFile = __DIR__ . '/../../config/admin_settings.json';
                        if (file_exists($configFile)) {
                            echo '<span class="text-green-600">Found</span>';
                        } else {
                            echo '<span class="text-yellow-600">Not found (will be created on first save)</span>';
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="py-2 px-4 border-b border-gray-200 font-medium">Debug Mode</td>
                    <td class="py-2 px-4 border-b border-gray-200">
                        <?php echo $config['api']['debug_mode'] ? '<span class="text-yellow-600">Enabled</span>' : '<span class="text-green-600">Disabled</span>'; ?>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>


