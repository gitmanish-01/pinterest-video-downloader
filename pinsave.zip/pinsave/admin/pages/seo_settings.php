<?php
// Handle SEO settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $config['seo']['title'] = $_POST['title'] ?? '';
    $config['seo']['description'] = $_POST['description'] ?? '';
    $config['seo']['keywords'] = $_POST['keywords'] ?? '';
    
    if (saveConfig($config)) {
        $success = 'SEO settings updated successfully!';
    } else {
        $error = 'Failed to save SEO settings.';
    }
}
?>

<div class="container px-6 py-8 mx-auto">
    <div class="mb-6">
        <h1 class="text-2xl font-bold">SEO Settings</h1>
        <p class="text-gray-600">Optimize your site for search engines</p>
    </div>

    <?php if (isset($success)): ?>
        <div class="mb-4 p-4 bg-green-100 border-l-4 border-green-500 text-green-700">
            <?php echo $success; ?>
        </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="mb-4 p-4 bg-red-100 border-l-4 border-red-500 text-red-700">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <div class="bg-white rounded-lg shadow-md p-6">
        <form method="POST" action="">
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="title">
                    Site Title
                </label>
                <input type="text" id="title" name="title" 
                       value="<?php echo htmlspecialchars($config['seo']['title'] ?? ''); ?>"
                       class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                       placeholder="Enter your site title">
                <p class="mt-1 text-sm text-gray-500">This appears in browser tabs and search results.</p>
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="description">
                    Meta Description
                </label>
                <textarea id="description" name="description" rows="3"
                          class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Enter your site description"><?php echo htmlspecialchars($config['seo']['description'] ?? ''); ?></textarea>
                <p class="mt-1 text-sm text-gray-500">Brief description of your site for search results.</p>
            </div>

            <div class="mb-6">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="keywords">
                    Meta Keywords
                </label>
                <textarea id="keywords" name="keywords" rows="2"
                          class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Enter keywords separated by commas"><?php echo htmlspecialchars($config['seo']['keywords'] ?? ''); ?></textarea>
                <p class="mt-1 text-sm text-gray-500">Keywords help search engines understand your content.</p>
            </div>

            <div class="flex items-center justify-end">
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                    Save SEO Settings
                </button>
            </div>
        </form>
    </div>
</div>
