<?php
require_once __DIR__ . '/../../config/config.php';

// Get current page
$current_page = basename($_SERVER['PHP_SELF']);

require_once '../auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pinterest Video Downloader Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gray-100">
    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center">
                    <a href="index.php" class="text-xl font-bold">PinSave Admin</a>
                </div>
                
                <div class="flex items-center space-x-4">
                    <a href="../" class="text-gray-300 hover:text-white" target="_blank">
                        View Site
                    </a>
                    <div class="relative group">
                        <button class="flex items-center text-gray-300 hover:text-white">
                            <span class="mr-1"><?php echo $_SESSION['admin_user'] ?? 'Admin'; ?></span>
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                            </svg>
                        </button>
                        <div class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 hidden group-hover:block">
                            <a href="logout.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <div class="w-64 bg-white shadow-md">
            <div class="p-4 space-y-2">
                <a href="index.php" class="block px-4 py-2 rounded-lg <?php echo $current_page === 'index.php' ? 'bg-blue-500 text-white' : 'text-gray-700 hover:bg-gray-100'; ?>">
                    <i class="fas fa-tachometer-alt mr-2"></i> Dashboard
                </a>
                <a href="api_settings.php" class="block px-4 py-2 rounded-lg <?php echo $current_page === 'api_settings.php' ? 'bg-blue-500 text-white' : 'text-gray-700 hover:bg-gray-100'; ?>">
                    <i class="fas fa-key mr-2"></i> API Settings
                </a>
                <a href="analytics.php" class="block px-4 py-2 rounded-lg <?php echo $current_page === 'analytics.php' ? 'bg-blue-500 text-white' : 'text-gray-700 hover:bg-gray-100'; ?>">
                    <i class="fas fa-chart-line mr-2"></i> Analytics
                </a>
                <a href="ad_settings.php" class="block px-4 py-2 rounded-lg <?php echo $current_page === 'ad_settings.php' ? 'bg-blue-500 text-white' : 'text-gray-700 hover:bg-gray-100'; ?>">
                    <i class="fas fa-ad mr-2"></i> Ad Management
                </a>
                <a href="pages.php" class="block px-4 py-2 rounded-lg <?php echo $current_page === 'pages.php' ? 'bg-blue-500 text-white' : 'text-gray-700 hover:bg-gray-100'; ?>">
                    <i class="fas fa-file-alt mr-2"></i> Pages
                </a>
                <a href="settings.php" class="block px-4 py-2 rounded-lg <?php echo $current_page === 'settings.php' ? 'bg-blue-500 text-white' : 'text-gray-700 hover:bg-gray-100'; ?>">
                    <i class="fas fa-cog mr-2"></i> Settings
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="flex-1 p-8">

    <header class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <h1 class="text-xl font-bold">Pinterest Video Downloader Admin</h1>
                <nav class="flex space-x-4">
                    <a href="index.php" class="text-gray-300 hover:text-white">Dashboard</a>
                    <a href="pages.php" class="text-gray-300 hover:text-white">Pages</a>
                    <a href="api_settings.php" class="text-gray-300 hover:text-white">API Settings</a>
                    <a href="analytics.php" class="text-gray-300 hover:text-white">Analytics</a>
                    <a href="settings.php" class="text-gray-300 hover:text-white">Settings</a>
                    <a href="logout.php" class="text-gray-300 hover:text-white">Logout</a>
                </nav>
            </div>
        </div>
    </header>
