<?php
// Get current page
$page = $_GET['page'] ?? 'dashboard';

// Map pages to their files and titles
$pages = [
    'dashboard' => [
        'file' => 'dashboard.php',
        'title' => 'Dashboard'
    ],
    'posts' => [
        'file' => 'posts.php',
        'title' => 'Manage Posts'
    ],
    'post-editor' => [
        'file' => 'post-editor.php',
        'title' => 'Edit Post'
    ],
    'categories' => [
        'file' => 'categories.php',
        'title' => 'Manage Categories'
    ],
    'tags' => [
        'file' => 'tags.php',
        'title' => 'Manage Tags'
    ],
    'menu-builder' => [
        'file' => 'menu-builder.php',
        'title' => 'Menu Builder'
    ],
    'api' => [
        'file' => 'api_settings.php',
        'title' => 'API Settings'
    ],
    'ads' => [
        'file' => 'ad_settings.php',
        'title' => 'Ad Settings'
    ],
    'seo' => [
        'file' => 'seo_settings.php',
        'title' => 'SEO Settings'
    ]
];

// Set default page if not found
if (!isset($pages[$page])) {
    $page = 'dashboard';
}

// Get page info
$pageInfo = $pages[$page];
$pageFile = $pageInfo['file'];
$pageTitle = $pageInfo['title'];

// Set page title for header
$GLOBALS['page_title'] = $pageTitle;

// Load the appropriate page file
$filePath = __DIR__ . '/' . $pageFile;

if (file_exists($filePath)) {
    require_once $filePath;
} else {
    // Show error if page file is missing
    echo '<div class="p-4 bg-red-100 border-l-4 border-red-500 text-red-700">';
    echo '<p class="font-bold">Error:</p>';
    echo '<p>The requested page file is missing. Please check the configuration.</p>';
    echo '</div>';
}
