<?php
// Include configuration
require_once '../includes/config.php';

// Require login
requireLogin();

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update footer settings
    $config['footer'] = [
        'disclaimer' => $_POST['disclaimer'] ?? '',
        'copyright_text' => $_POST['copyright_text'] ?? '',
        'links' => [
            'about' => [
                'text' => $_POST['about_text'] ?? 'About us',
                'url' => $_POST['about_url'] ?? '#'
            ],
            'privacy' => [
                'text' => $_POST['privacy_text'] ?? 'Privacy Policy',
                'url' => $_POST['privacy_url'] ?? '#'
            ],
            'contact' => [
                'text' => $_POST['contact_text'] ?? 'Contact us',
                'url' => $_POST['contact_url'] ?? '#'
            ]
        ]
    ];
    
    // Save configuration
    if (saveConfig($config)) {
        $success = 'Footer settings updated successfully!';
    } else {
        $error = 'Failed to save footer settings.';
    }
}

// Get current footer settings
$footerSettings = $config['footer'] ?? [
    'disclaimer' => 'PinterestDownloader does not host any pirated or copyright content on its server, and all videos or images that you download from our tool are downloaded from their respective CDN servers. And this Tool is Not associated with Pinterest in any ways.',
    'copyright_text' => '© ' . date('Y') . ' - PinterestDownloader',
    'links' => [
        'about' => [
            'text' => 'About us',
            'url' => '#'
        ],
        'privacy' => [
            'text' => 'Privacy Policy',
            'url' => '#'
        ],
        'contact' => [
            'text' => 'Contact us',
            'url' => '#'
        ]
    ]
];

// Get current footer settings
$footerSettings = $config['footer'] ?? [
    'disclaimer' => 'PinterestDownloader does not host any pirated or copyright content on its server, and all videos or images that you download from our tool are downloaded from their respective CDN servers. And this Tool is Not associated with Pinterest in any ways.',
    'copyright_text' => '© ' . date('Y') . ' - PinterestDownloader',
    'links' => [
        'about' => [
            'text' => 'About us',
            'url' => '#'
        ],
        'privacy' => [
            'text' => 'Privacy Policy',
            'url' => '#'
        ],
        'contact' => [
            'text' => 'Contact us',
            'url' => '#'
        ]
    ]
];
?>

<!-- Header -->
<?php include '../includes/header.php'; ?>

<!-- Main Content -->
<div class="container mx-auto px-4 py-8">
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <!-- Settings Form -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-2xl font-bold mb-6">Footer Settings</h2>
            
            <?php if (isset($success)): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                <p><?php echo htmlspecialchars($success); ?></p>
            </div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                <p><?php echo htmlspecialchars($error); ?></p>
            </div>
            <?php endif; ?>
            
            <form method="POST" action="" id="footerForm">
                <!-- Disclaimer -->
                <div class="mb-6">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="disclaimer">
                        Disclaimer Text
                    </label>
                    <textarea
                        id="disclaimer"
                        name="disclaimer"
                        rows="4"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        required
                        oninput="updatePreview()"
                    ><?php echo htmlspecialchars($footerSettings['disclaimer']); ?></textarea>
                </div>
                
                <!-- Copyright Text -->
                <div class="mb-6">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="copyright_text">
                        Copyright Text
                    </label>
                    <input
                        type="text"
                        id="copyright_text"
                        name="copyright_text"
                        value="<?php echo htmlspecialchars($footerSettings['copyright_text']); ?>"
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        required
                        oninput="updatePreview()"
                    >
                </div>
                
                <!-- Footer Links -->
                <div class="mb-6">
                    <h3 class="text-lg font-semibold mb-4">Footer Links</h3>
                    
                    <!-- About Link -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="about_text">
                                About Link Text
                            </label>
                            <input
                                type="text"
                                id="about_text"
                                name="about_text"
                                value="<?php echo htmlspecialchars($footerSettings['links']['about']['text']); ?>"
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                oninput="updatePreview()"
                            >
                        </div>
                        <div>
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="about_url">
                                About Link URL
                            </label>
                            <input
                                type="text"
                                id="about_url"
                                name="about_url"
                                value="<?php echo htmlspecialchars($footerSettings['links']['about']['url']); ?>"
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                oninput="updatePreview()"
                            >
                        </div>
                    </div>
                    
                    <!-- Privacy Link -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="privacy_text">
                                Privacy Link Text
                            </label>
                            <input
                                type="text"
                                id="privacy_text"
                                name="privacy_text"
                                value="<?php echo htmlspecialchars($footerSettings['links']['privacy']['text']); ?>"
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                oninput="updatePreview()"
                            >
                        </div>
                        <div>
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="privacy_url">
                                Privacy Link URL
                            </label>
                            <input
                                type="text"
                                id="privacy_url"
                                name="privacy_url"
                                value="<?php echo htmlspecialchars($footerSettings['links']['privacy']['url']); ?>"
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                oninput="updatePreview()"
                            >
                        </div>
                    </div>
                    
                    <!-- Contact Link -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="contact_text">
                                Contact Link Text
                            </label>
                            <input
                                type="text"
                                id="contact_text"
                                name="contact_text"
                                value="<?php echo htmlspecialchars($footerSettings['links']['contact']['text']); ?>"
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                oninput="updatePreview()"
                            >
                        </div>
                        <div>
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="contact_url">
                                Contact Link URL
                            </label>
                            <input
                                type="text"
                                id="contact_url"
                                name="contact_url"
                                value="<?php echo htmlspecialchars($footerSettings['links']['contact']['url']); ?>"
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                oninput="updatePreview()"
                            >
                        </div>
                    </div>
                </div>
                
                <!-- Submit Button -->
                <div class="flex items-center justify-end">
                    <button
                        type="submit"
                        class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                    >
                        Save Footer Settings
                    </button>
                </div>
            </form>
        </div>

        <!-- Live Preview -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-2xl font-bold mb-6">Live Preview</h2>
            <div id="footerPreview" class="border rounded p-4">
                <!-- Preview content will be updated by JavaScript -->
                <div class="text-center mt-10 text-gray-500 text-sm">
                    <!-- Disclaimer -->
                    <div class="mb-6 text-left max-w-3xl mx-auto p-4 bg-gray-50 rounded">
                        <h2 class="font-bold mb-2">Disclaimer</h2>
                        <p id="previewDisclaimer"></p>
                    </div>
                    
                    <!-- Info Links -->
                    <div class="mb-4">
                        <ul class="flex flex-wrap justify-center gap-4" id="previewLinks"></ul>
                    </div>
                    
                    <!-- Copyright -->
                    <p id="previewCopyright"></p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function updatePreview() {
    // Update disclaimer
    document.getElementById('previewDisclaimer').textContent = document.getElementById('disclaimer').value;
    
    // Update copyright
    document.getElementById('previewCopyright').textContent = document.getElementById('copyright_text').value;
    
    // Update links
    const linksContainer = document.getElementById('previewLinks');
    linksContainer.innerHTML = '';
    
    // About link
    if (document.getElementById('about_text').value) {
        const aboutLi = document.createElement('li');
        const aboutLink = document.createElement('a');
        aboutLink.href = document.getElementById('about_url').value;
        aboutLink.className = 'text-blue-600 hover:text-blue-800';
        aboutLink.textContent = document.getElementById('about_text').value;
        aboutLi.appendChild(aboutLink);
        linksContainer.appendChild(aboutLi);
    }
    
    // Privacy link
    if (document.getElementById('privacy_text').value) {
        const privacyLi = document.createElement('li');
        const privacyLink = document.createElement('a');
        privacyLink.href = document.getElementById('privacy_url').value;
        privacyLink.className = 'text-blue-600 hover:text-blue-800';
        privacyLink.textContent = document.getElementById('privacy_text').value;
        privacyLi.appendChild(privacyLink);
        linksContainer.appendChild(privacyLi);
    }
    
    // Contact link
    if (document.getElementById('contact_text').value) {
        const contactLi = document.createElement('li');
        const contactLink = document.createElement('a');
        contactLink.href = document.getElementById('contact_url').value;
        contactLink.className = 'text-blue-600 hover:text-blue-800';
        contactLink.textContent = document.getElementById('contact_text').value;
        contactLi.appendChild(contactLink);
        linksContainer.appendChild(contactLi);
    }
}

// Initialize preview on page load
document.addEventListener('DOMContentLoaded', updatePreview);
</script>

<!-- Footer -->
<?php include '../includes/footer.php'; ?>
