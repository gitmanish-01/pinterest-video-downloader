<?php
// Process form submission
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update API settings
    $config['api']['rapidapi_key'] = $_POST['rapidapi_key'] ?? '';
    $config['api']['api_provider'] = $_POST['api_provider'] ?? 'pinterest-video-downloader1';
    $config['api']['debug_mode'] = isset($_POST['debug_mode']);
    
    // Save configuration
    if (saveConfig($config)) {
        $message = 'API settings updated successfully!';
        $messageType = 'success';
    } else {
        $message = 'Failed to save API settings. Please check file permissions.';
        $messageType = 'error';
    }
}
?>

<div class="bg-white shadow rounded-lg p-6">
    <h2 class="text-xl font-semibold mb-4">API Settings</h2>
    
    <?php if ($message): ?>
        <div class="mb-4 p-4 rounded <?php echo $messageType === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>
    
    <form method="POST" action="">
        <div class="mb-6">
            <label for="rapidapi_key" class="block text-sm font-medium text-gray-700 mb-1">RapidAPI Key</label>
            <input 
                type="text" 
                id="rapidapi_key" 
                name="rapidapi_key" 
                value="<?php echo htmlspecialchars($config['api']['rapidapi_key']); ?>"
                class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                placeholder="Enter your RapidAPI key"
            >
            <p class="mt-1 text-sm text-gray-500">
                Get your API key from <a href="https://rapidapi.com/" target="_blank" class="text-blue-600 hover:underline">RapidAPI</a>
            </p>
        </div>
        
        <div class="mb-6">
            <label for="api_provider" class="block text-sm font-medium text-gray-700 mb-1">API Provider</label>
            <select 
                id="api_provider" 
                name="api_provider" 
                class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
            >
                <option value="pinterest-video-downloader1" <?php echo $config['api']['api_provider'] === 'pinterest-video-downloader1' ? 'selected' : ''; ?>>
                    pinterest-video-downloader1
                </option>
                <option value="pinterest-downloader-download-pinterest-image-video-and-reels" <?php echo $config['api']['api_provider'] === 'pinterest-downloader-download-pinterest-image-video-and-reels' ? 'selected' : ''; ?>>
                    pinterest-downloader-download-pinterest-image-video-and-reels
                </option>
                <option value="social-media-video-downloader" <?php echo $config['api']['api_provider'] === 'social-media-video-downloader' ? 'selected' : ''; ?>>
                    social-media-video-downloader
                </option>
            </select>
            <p class="mt-1 text-sm text-gray-500">
                Select which RapidAPI provider to use as primary
            </p>
        </div>
        
        <div class="mb-6">
            <div class="flex items-start">
                <div class="flex items-center h-5">
                    <input 
                        id="debug_mode" 
                        name="debug_mode" 
                        type="checkbox" 
                        <?php echo $config['api']['debug_mode'] ? 'checked' : ''; ?>
                        class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300 rounded"
                    >
                </div>
                <div class="ml-3 text-sm">
                    <label for="debug_mode" class="font-medium text-gray-700">Enable Debug Mode</label>
                    <p class="text-gray-500">Shows detailed error messages and API responses</p>
                </div>
            </div>
        </div>
        
        <div class="bg-gray-50 p-4 rounded-md mb-6">
            <h3 class="text-lg font-medium text-gray-900 mb-2">API Status</h3>
            <div class="text-sm text-gray-600">
                <?php if (!empty($config['api']['rapidapi_key'])): ?>
                    <div class="flex items-center">
                        <span class="h-2 w-2 bg-green-400 rounded-full mr-2"></span>
                        <span>API Key is configured</span>
                    </div>
                <?php else: ?>
                    <div class="flex items-center">
                        <span class="h-2 w-2 bg-red-400 rounded-full mr-2"></span>
                        <span>API Key is not configured</span>
                    </div>
                <?php endif; ?>
                
                <div class="mt-2">
                    <p>Current API Provider: <strong><?php echo htmlspecialchars($config['api']['api_provider']); ?></strong></p>
                </div>
            </div>
        </div>
        
        <div class="flex justify-end">
            <button 
                type="submit" 
                class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
                Save API Settings
            </button>
        </div>
    </form>
</div>
