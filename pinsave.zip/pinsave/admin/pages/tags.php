<?php

// Handle tag actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'rename') {
        $old_tag = $_POST['old_tag'] ?? '';
        $new_tag = trim($_POST['new_tag'] ?? '');
        
        if (!empty($old_tag) && !empty($new_tag)) {
            // Update tag in all posts
            foreach ($adminConfig['posts'] as &$post) {
                if (!empty($post['tags'])) {
                    $key = array_search($old_tag, $post['tags']);
                    if ($key !== false) {
                        $post['tags'][$key] = $new_tag;
                    }
                }
            }
            
            saveConfig($adminConfig);
            header('Location: tags.php?success=1');
            exit;
        }
    }
    
    if ($action === 'delete') {
        $tag = $_POST['tag'] ?? '';
        
        if (!empty($tag)) {
            // Remove tag from all posts
            foreach ($adminConfig['posts'] as &$post) {
                if (!empty($post['tags'])) {
                    $post['tags'] = array_diff($post['tags'], [$tag]);
                }
            }
            
            saveConfig($adminConfig);
            header('Location: tags.php?deleted=1');
            exit;
        }
    }
    
    if ($action === 'merge') {
        $tags = $_POST['tags'] ?? [];
        $target_tag = $_POST['target_tag'] ?? '';
        
        if (!empty($tags) && !empty($target_tag)) {
            // Merge tags in all posts
            foreach ($adminConfig['posts'] as &$post) {
                if (!empty($post['tags'])) {
                    // Remove source tags
                    $post['tags'] = array_diff($post['tags'], $tags);
                    // Add target tag if not present
                    if (!in_array($target_tag, $post['tags'])) {
                        $post['tags'][] = $target_tag;
                    }
                }
            }
            
            saveConfig($adminConfig);
            header('Location: tags.php?success=1');
            exit;
        }
    }
}

// Get all tags with counts
$taxonomy = new Taxonomy();
$tags = $taxonomy->getTags();
?>

<div class="container px-6 py-8 mx-auto">
    <div class="mb-6">
        <h1 class="text-2xl font-bold">Manage Tags</h1>
        <p class="text-gray-600 mt-2">Organize and clean up your tags</p>
    </div>

    <?php if (isset($_GET['success'])): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
        <span class="block sm:inline">Tags updated successfully!</span>
    </div>
    <?php endif; ?>

    <?php if (isset($_GET['deleted'])): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
        <span class="block sm:inline">Tag deleted successfully!</span>
    </div>
    <?php endif; ?>

    <!-- Tag Cloud -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 class="text-lg font-semibold mb-4">Tag Cloud</h2>
        <div class="flex flex-wrap gap-2">
            <?php foreach ($tags as $tag => $data): ?>
                <div class="group relative">
                    <div class="px-3 py-1 bg-gray-100 rounded-full text-sm flex items-center gap-2">
                        <span>#<?php echo htmlspecialchars($tag); ?></span>
                        <span class="text-gray-500">(<?php echo $data['count']; ?>)</span>
                        <button onclick="openTagMenu('<?php echo htmlspecialchars($tag); ?>')" 
                                class="ml-1 text-gray-400 hover:text-gray-600">
                            <i class="fas fa-ellipsis-v"></i>
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Tag Operations -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Rename Tag -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-lg font-semibold mb-4">Rename Tag</h2>
            <form method="post" class="space-y-4">
                <input type="hidden" name="action" value="rename">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">Old Tag Name</label>
                    <select name="old_tag" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select a tag...</option>
                        <?php foreach ($tags as $tag => $data): ?>
                            <option value="<?php echo htmlspecialchars($tag); ?>">
                                <?php echo htmlspecialchars($tag); ?> (<?php echo $data['count']; ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">New Tag Name</label>
                    <input type="text" name="new_tag" required
                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>
                
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                    Rename Tag
                </button>
            </form>
        </div>

        <!-- Merge Tags -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-lg font-semibold mb-4">Merge Tags</h2>
            <form method="post" class="space-y-4">
                <input type="hidden" name="action" value="merge">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">Select Tags to Merge</label>
                    <select name="tags[]" multiple required
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <?php foreach ($tags as $tag => $data): ?>
                            <option value="<?php echo htmlspecialchars($tag); ?>">
                                <?php echo htmlspecialchars($tag); ?> (<?php echo $data['count']; ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="mt-1 text-sm text-gray-500">Hold Ctrl/Cmd to select multiple tags</p>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">Target Tag</label>
                    <select name="target_tag" required
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select target tag...</option>
                        <?php foreach ($tags as $tag => $data): ?>
                            <option value="<?php echo htmlspecialchars($tag); ?>">
                                <?php echo htmlspecialchars($tag); ?> (<?php echo $data['count']; ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                    Merge Tags
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Tag Menu Modal -->
<div id="tagMenuModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <h3 class="text-lg font-medium text-gray-900 mb-4">Tag Options: <span id="selectedTag"></span></h3>
        <div class="space-y-4">
            <button onclick="openRenameTag()" class="w-full text-left px-4 py-2 hover:bg-gray-100 rounded">
                <i class="fas fa-edit mr-2"></i> Rename Tag
            </button>
            <form method="post" onsubmit="return confirm('Are you sure? This will remove this tag from all posts.');">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="tag" id="deleteTagInput">
                <button type="submit" class="w-full text-left px-4 py-2 text-red-600 hover:bg-red-50 rounded">
                    <i class="fas fa-trash mr-2"></i> Delete Tag
                </button>
            </form>
            <button onclick="closeTagMenu()" class="w-full text-center px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded">
                Cancel
            </button>
        </div>
    </div>
</div>

<script>
let currentTag = '';

function openTagMenu(tag) {
    currentTag = tag;
    document.getElementById('selectedTag').textContent = '#' + tag;
    document.getElementById('deleteTagInput').value = tag;
    document.getElementById('tagMenuModal').classList.remove('hidden');
}

function closeTagMenu() {
    document.getElementById('tagMenuModal').classList.add('hidden');
}

function openRenameTag() {
    document.querySelector('select[name="old_tag"]').value = currentTag;
    document.querySelector('input[name="new_tag"]').value = '';
    closeTagMenu();
    document.querySelector('input[name="new_tag"]').focus();
}

// Close modals when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('tagMenuModal');
    if (event.target == modal) {
        closeTagMenu();
    }
}
</script>

