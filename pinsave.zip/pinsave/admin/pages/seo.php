<?php
// Process form submission
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update SEO settings
    $config['seo']['title'] = $_POST['site_title'] ?? '';
    $config['seo']['description'] = $_POST['site_description'] ?? '';
    $config['seo']['keywords'] = $_POST['site_keywords'] ?? '';
    
    // Save configuration
    if (saveConfig($config)) {
        $message = 'SEO settings updated successfully!';
        $messageType = 'success';
    } else {
        $message = 'Failed to save SEO settings. Please check file permissions.';
        $messageType = 'error';
    }
}
?>

<div class="bg-white shadow rounded-lg p-6">
    <h2 class="text-xl font-semibold mb-4">SEO Settings</h2>
    
    <?php if ($message): ?>
        <div class="mb-4 p-4 rounded <?php echo $messageType === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>
    
    <form method="POST" action="">
        <div class="mb-6">
            <label for="site_title" class="block text-sm font-medium text-gray-700 mb-1">Site Title</label>
            <input 
                type="text" 
                id="site_title" 
                name="site_title" 
                value="<?php echo htmlspecialchars($config['seo']['title']); ?>"
                class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                placeholder="Pinterest Video Downloader - Save Pinterest Videos Easily"
            >
            <p class="mt-1 text-sm text-gray-500">
                The title that appears in search engine results and browser tabs
            </p>
        </div>
        
        <div class="mb-6">
            <label for="site_description" class="block text-sm font-medium text-gray-700 mb-1">Meta Description</label>
            <textarea 
                id="site_description" 
                name="site_description" 
                rows="3"
                class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                placeholder="Download Pinterest videos for free with PinSave. Save Pinterest videos in HD quality without watermark."
            ><?php echo htmlspecialchars($config['seo']['description']); ?></textarea>
            <p class="mt-1 text-sm text-gray-500">
                A brief description of your website (150-160 characters recommended)
            </p>
        </div>
        
        <div class="mb-6">
            <label for="site_keywords" class="block text-sm font-medium text-gray-700 mb-1">Meta Keywords</label>
            <textarea 
                id="site_keywords" 
                name="site_keywords" 
                rows="2"
                class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                placeholder="pinterest video downloader, download pinterest videos, save pinterest videos, pinterest video saver"
            ><?php echo htmlspecialchars($config['seo']['keywords']); ?></textarea>
            <p class="mt-1 text-sm text-gray-500">
                Comma-separated keywords related to your website
            </p>
        </div>
        
        <div class="bg-gray-50 p-4 rounded-md mb-6">
            <h3 class="text-lg font-medium text-gray-900 mb-2">SEO Tips</h3>
            <ul class="list-disc pl-5 space-y-1 text-sm text-gray-600">
                <li>Use your main keyword in the title, preferably at the beginning</li>
                <li>Keep your meta description between 150-160 characters</li>
                <li>Include a call-to-action in your meta description</li>
                <li>Use long-tail keywords for better ranking opportunities</li>
                <li>Focus on user intent rather than keyword stuffing</li>
                <li>Update your content regularly to keep it fresh</li>
            </ul>
        </div>
        
        <div class="mb-6">
            <h3 class="text-lg font-medium text-gray-900 mb-2">Preview</h3>
            <div class="border border-gray-200 rounded-md p-4 bg-white">
                <div class="text-blue-600 text-lg font-medium" id="preview-title">
                    <?php echo htmlspecialchars($config['seo']['title']); ?>
                </div>
                <div class="text-green-600 text-sm mt-1">
                    <?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']; ?>
                </div>
                <div class="text-gray-600 text-sm mt-1" id="preview-description">
                    <?php echo htmlspecialchars($config['seo']['description']); ?>
                </div>
            </div>
        </div>
        
        <div class="flex justify-end">
            <button 
                type="submit" 
                class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
                Save SEO Settings
            </button>
        </div>
    </form>
</div>

<script>
    // Live preview
    document.getElementById('site_title').addEventListener('input', function() {
        document.getElementById('preview-title').textContent = this.value;
    });
    
    document.getElementById('site_description').addEventListener('input', function() {
        document.getElementById('preview-description').textContent = this.value;
    });
</script>
