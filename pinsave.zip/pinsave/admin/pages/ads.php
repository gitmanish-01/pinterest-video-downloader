<?php
// Process form submission
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update Google Ads settings
    $config['ads']['google_ads']['enabled'] = isset($_POST['google_ads_enabled']);
    $config['ads']['google_ads']['publisher_id'] = $_POST['google_ads_publisher_id'] ?? '';
    $config['ads']['google_ads']['ad_slot_top'] = $_POST['google_ads_slot_top'] ?? '';
    $config['ads']['google_ads']['ad_slot_bottom'] = $_POST['google_ads_slot_bottom'] ?? '';
    $config['ads']['google_ads']['ad_slot_sidebar'] = $_POST['google_ads_slot_sidebar'] ?? '';
    
    // Update Ezoic Ads settings
    $config['ads']['ezoic_ads']['enabled'] = isset($_POST['ezoic_ads_enabled']);
    $config['ads']['ezoic_ads']['site_id'] = $_POST['ezoic_site_id'] ?? '';
    $config['ads']['ezoic_ads']['script'] = $_POST['ezoic_script'] ?? '';
    
    // Save configuration
    if (saveConfig($config)) {
        $message = 'Ad settings updated successfully!';
        $messageType = 'success';
    } else {
        $message = 'Failed to save ad settings. Please check file permissions.';
        $messageType = 'error';
    }
}
?>

<div class="bg-white shadow rounded-lg p-6">
    <h2 class="text-xl font-semibold mb-4">Ad Management</h2>
    
    <?php if ($message): ?>
        <div class="mb-4 p-4 rounded <?php echo $messageType === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>
    
    <form method="POST" action="">
        <!-- Google Ads Section -->
        <div class="mb-8 border-b pb-6">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Google AdSense</h3>
            
            <div class="mb-4">
                <div class="flex items-start">
                    <div class="flex items-center h-5">
                        <input 
                            id="google_ads_enabled" 
                            name="google_ads_enabled" 
                            type="checkbox" 
                            <?php echo $config['ads']['google_ads']['enabled'] ? 'checked' : ''; ?>
                            class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300 rounded"
                        >
                    </div>
                    <div class="ml-3 text-sm">
                        <label for="google_ads_enabled" class="font-medium text-gray-700">Enable Google AdSense</label>
                        <p class="text-gray-500">Display Google ads on your website</p>
                    </div>
                </div>
            </div>
            
            <div class="mb-4">
                <label for="google_ads_publisher_id" class="block text-sm font-medium text-gray-700 mb-1">Publisher ID</label>
                <input 
                    type="text" 
                    id="google_ads_publisher_id" 
                    name="google_ads_publisher_id" 
                    value="<?php echo htmlspecialchars($config['ads']['google_ads']['publisher_id']); ?>"
                    class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                    placeholder="ca-pub-1234567890123456"
                >
                <p class="mt-1 text-sm text-gray-500">
                    Your Google AdSense publisher ID (e.g., ca-pub-1234567890123456)
                </p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label for="google_ads_slot_top" class="block text-sm font-medium text-gray-700 mb-1">Top Ad Slot</label>
                    <input 
                        type="text" 
                        id="google_ads_slot_top" 
                        name="google_ads_slot_top" 
                        value="<?php echo htmlspecialchars($config['ads']['google_ads']['ad_slot_top']); ?>"
                        class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                        placeholder="1234567890"
                    >
                </div>
                
                <div>
                    <label for="google_ads_slot_bottom" class="block text-sm font-medium text-gray-700 mb-1">Bottom Ad Slot</label>
                    <input 
                        type="text" 
                        id="google_ads_slot_bottom" 
                        name="google_ads_slot_bottom" 
                        value="<?php echo htmlspecialchars($config['ads']['google_ads']['ad_slot_bottom']); ?>"
                        class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                        placeholder="1234567890"
                    >
                </div>
                
                <div>
                    <label for="google_ads_slot_sidebar" class="block text-sm font-medium text-gray-700 mb-1">Sidebar Ad Slot</label>
                    <input 
                        type="text" 
                        id="google_ads_slot_sidebar" 
                        name="google_ads_slot_sidebar" 
                        value="<?php echo htmlspecialchars($config['ads']['google_ads']['ad_slot_sidebar']); ?>"
                        class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                        placeholder="1234567890"
                    >
                </div>
            </div>
        </div>
        
        <!-- Ezoic Ads Section -->
        <div class="mb-8">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Ezoic Ads</h3>
            
            <div class="mb-4">
                <div class="flex items-start">
                    <div class="flex items-center h-5">
                        <input 
                            id="ezoic_ads_enabled" 
                            name="ezoic_ads_enabled" 
                            type="checkbox" 
                            <?php echo $config['ads']['ezoic_ads']['enabled'] ? 'checked' : ''; ?>
                            class="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300 rounded"
                        >
                    </div>
                    <div class="ml-3 text-sm">
                        <label for="ezoic_ads_enabled" class="font-medium text-gray-700">Enable Ezoic Ads</label>
                        <p class="text-gray-500">Display Ezoic ads on your website</p>
                    </div>
                </div>
            </div>
            
            <div class="mb-4">
                <label for="ezoic_site_id" class="block text-sm font-medium text-gray-700 mb-1">Ezoic Site ID</label>
                <input 
                    type="text" 
                    id="ezoic_site_id" 
                    name="ezoic_site_id" 
                    value="<?php echo htmlspecialchars($config['ads']['ezoic_ads']['site_id']); ?>"
                    class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                    placeholder="123456"
                >
            </div>
            
            <div class="mb-4">
                <label for="ezoic_script" class="block text-sm font-medium text-gray-700 mb-1">Ezoic Integration Script</label>
                <textarea 
                    id="ezoic_script" 
                    name="ezoic_script" 
                    rows="4"
                    class="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md p-2 border"
                    placeholder="<!-- Paste your Ezoic integration script here -->"
                ><?php echo htmlspecialchars($config['ads']['ezoic_ads']['script']); ?></textarea>
                <p class="mt-1 text-sm text-gray-500">
                    Paste the Ezoic integration script provided in your Ezoic dashboard
                </p>
            </div>
        </div>
        
        <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6">
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-exclamation-triangle text-yellow-400"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm text-yellow-700">
                        Note: If both Google AdSense and Ezoic are enabled, Ezoic will take precedence.
                    </p>
                </div>
            </div>
        </div>
        
        <div class="flex justify-end">
            <button 
                type="submit" 
                class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
                Save Ad Settings
            </button>
        </div>
    </form>
</div>
