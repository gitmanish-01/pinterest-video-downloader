<?php
// Handle ad settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Google Ads
    $config['ads']['google_ads']['enabled'] = isset($_POST['google_ads_enabled']);
    $config['ads']['google_ads']['publisher_id'] = $_POST['google_ads_publisher_id'] ?? '';
    $config['ads']['google_ads']['ad_slot_top'] = $_POST['google_ads_slot_top'] ?? '';
    $config['ads']['google_ads']['ad_slot_bottom'] = $_POST['google_ads_slot_bottom'] ?? '';
    $config['ads']['google_ads']['ad_slot_sidebar'] = $_POST['google_ads_slot_sidebar'] ?? '';
    
    // Ezoic Ads
    $config['ads']['ezoic_ads']['enabled'] = isset($_POST['ezoic_ads_enabled']);
    $config['ads']['ezoic_ads']['site_id'] = $_POST['ezoic_site_id'] ?? '';
    $config['ads']['ezoic_ads']['script'] = $_POST['ezoic_script'] ?? '';
    
    if (saveConfig($config)) {
        $success = 'Ad settings updated successfully!';
    } else {
        $error = 'Failed to save ad settings.';
    }
}
?>

<div class="container px-6 py-8 mx-auto">
    <div class="mb-6">
        <h1 class="text-2xl font-bold">Ad Settings</h1>
        <p class="text-gray-600">Configure your advertising settings</p>
    </div>

    <?php if (isset($success)): ?>
        <div class="mb-4 p-4 bg-green-100 border-l-4 border-green-500 text-green-700">
            <?php echo $success; ?>
        </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="mb-4 p-4 bg-red-100 border-l-4 border-red-500 text-red-700">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <div class="bg-white rounded-lg shadow-md p-6">
        <form method="POST" action="">
            <!-- Google AdSense Section -->
            <div class="mb-8">
                <h2 class="text-xl font-bold mb-4">Google AdSense</h2>
                
                <div class="mb-4">
                    <label class="inline-flex items-center">
                        <input type="checkbox" name="google_ads_enabled" 
                               <?php echo ($config['ads']['google_ads']['enabled'] ?? false) ? 'checked' : ''; ?>
                               class="form-checkbox h-5 w-5 text-blue-600">
                        <span class="ml-2">Enable Google AdSense</span>
                    </label>
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="google_ads_publisher_id">
                        Publisher ID
                    </label>
                    <input type="text" id="google_ads_publisher_id" name="google_ads_publisher_id"
                           value="<?php echo htmlspecialchars($config['ads']['google_ads']['publisher_id'] ?? ''); ?>"
                           class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                           placeholder="ca-pub-xxxxxxxxxxxxxxxx">
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="google_ads_slot_top">
                            Top Ad Slot
                        </label>
                        <input type="text" id="google_ads_slot_top" name="google_ads_slot_top"
                               value="<?php echo htmlspecialchars($config['ads']['google_ads']['ad_slot_top'] ?? ''); ?>"
                               class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                               placeholder="xxxxxxxxxx">
                    </div>

                    <div>
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="google_ads_slot_bottom">
                            Bottom Ad Slot
                        </label>
                        <input type="text" id="google_ads_slot_bottom" name="google_ads_slot_bottom"
                               value="<?php echo htmlspecialchars($config['ads']['google_ads']['ad_slot_bottom'] ?? ''); ?>"
                               class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                               placeholder="xxxxxxxxxx">
                    </div>

                    <div>
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="google_ads_slot_sidebar">
                            Sidebar Ad Slot
                        </label>
                        <input type="text" id="google_ads_slot_sidebar" name="google_ads_slot_sidebar"
                               value="<?php echo htmlspecialchars($config['ads']['google_ads']['ad_slot_sidebar'] ?? ''); ?>"
                               class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                               placeholder="xxxxxxxxxx">
                    </div>
                </div>
            </div>

            <!-- Ezoic Section -->
            <div class="mb-8">
                <h2 class="text-xl font-bold mb-4">Ezoic</h2>
                
                <div class="mb-4">
                    <label class="inline-flex items-center">
                        <input type="checkbox" name="ezoic_ads_enabled"
                               <?php echo ($config['ads']['ezoic_ads']['enabled'] ?? false) ? 'checked' : ''; ?>
                               class="form-checkbox h-5 w-5 text-blue-600">
                        <span class="ml-2">Enable Ezoic</span>
                    </label>
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="ezoic_site_id">
                        Site ID
                    </label>
                    <input type="text" id="ezoic_site_id" name="ezoic_site_id"
                           value="<?php echo htmlspecialchars($config['ads']['ezoic_ads']['site_id'] ?? ''); ?>"
                           class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                           placeholder="Enter your Ezoic site ID">
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="ezoic_script">
                        Integration Script
                    </label>
                    <textarea id="ezoic_script" name="ezoic_script" rows="4"
                              class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                              placeholder="Enter your Ezoic integration script"><?php echo htmlspecialchars($config['ads']['ezoic_ads']['script'] ?? ''); ?></textarea>
                </div>
            </div>

            <div class="flex items-center justify-end">
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                    Save Ad Settings
                </button>
            </div>
        </form>
    </div>
</div>
