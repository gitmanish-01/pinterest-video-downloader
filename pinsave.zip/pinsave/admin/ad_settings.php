<?php
// Start session
session_start();

// Include configuration
require_once 'includes/config.php';
require_once '../includes/stats_handler.php';

// Check if user is logged in
if (!isset($_SESSION[SESSION_NAME]) || $_SESSION[SESSION_NAME] !== true) {
    header('Location: login.php');
    exit;
}

// Load configuration
$admin_settings = json_decode(file_get_contents('../config/admin_settings.json'), true);

// Ensure ads section exists with default values
if (!isset($admin_settings['ads'])) {
    $admin_settings['ads'] = [];
}

// Set default values for Google AdSense
if (!isset($admin_settings['ads']['google_ads'])) {
    $admin_settings['ads']['google_ads'] = [
        'enabled' => false,
        'client_id' => '',
        'slots' => [
            'header' => '',
            'sidebar' => '',
            'content' => '',
            'footer' => ''
        ]
    ];
} else {
    // Ensure client_id exists
    if (!isset($admin_settings['ads']['google_ads']['client_id'])) {
        $admin_settings['ads']['google_ads']['client_id'] = '';
    }
    
    // Ensure slots array exists
    if (!isset($admin_settings['ads']['google_ads']['slots']) || !is_array($admin_settings['ads']['google_ads']['slots'])) {
        $admin_settings['ads']['google_ads']['slots'] = [
            'header' => '',
            'sidebar' => '',
            'content' => '',
            'footer' => ''
        ];
    } else {
        // Ensure all slot keys exist
        if (!isset($admin_settings['ads']['google_ads']['slots']['header'])) {
            $admin_settings['ads']['google_ads']['slots']['header'] = '';
        }
        if (!isset($admin_settings['ads']['google_ads']['slots']['sidebar'])) {
            $admin_settings['ads']['google_ads']['slots']['sidebar'] = '';
        }
        if (!isset($admin_settings['ads']['google_ads']['slots']['content'])) {
            $admin_settings['ads']['google_ads']['slots']['content'] = '';
        }
        if (!isset($admin_settings['ads']['google_ads']['slots']['footer'])) {
            $admin_settings['ads']['google_ads']['slots']['footer'] = '';
        }
    }
}

// Set default values for Ezoic
if (!isset($admin_settings['ads']['ezoic'])) {
    $admin_settings['ads']['ezoic'] = [
        'enabled' => false,
        'site_id' => '',
        'slots' => [
            'header' => '',
            'sidebar' => '',
            'content' => '',
            'footer' => ''
        ]
    ];
} else {
    // Ensure site_id exists
    if (!isset($admin_settings['ads']['ezoic']['site_id'])) {
        $admin_settings['ads']['ezoic']['site_id'] = '';
    }
    
    // Ensure slots array exists
    if (!isset($admin_settings['ads']['ezoic']['slots']) || !is_array($admin_settings['ads']['ezoic']['slots'])) {
        $admin_settings['ads']['ezoic']['slots'] = [
            'header' => '',
            'sidebar' => '',
            'content' => '',
            'footer' => ''
        ];
    } else {
        // Ensure all slot keys exist
        if (!isset($admin_settings['ads']['ezoic']['slots']['header'])) {
            $admin_settings['ads']['ezoic']['slots']['header'] = '';
        }
        if (!isset($admin_settings['ads']['ezoic']['slots']['sidebar'])) {
            $admin_settings['ads']['ezoic']['slots']['sidebar'] = '';
        }
        if (!isset($admin_settings['ads']['ezoic']['slots']['content'])) {
            $admin_settings['ads']['ezoic']['slots']['content'] = '';
        }
        if (!isset($admin_settings['ads']['ezoic']['slots']['footer'])) {
            $admin_settings['ads']['ezoic']['slots']['footer'] = '';
        }
    }
}

// Set default values for Custom Ads
if (!isset($admin_settings['ads']['custom'])) {
    $admin_settings['ads']['custom'] = [
        'enabled' => false,
        'slots' => []
    ];
} else {
    // Ensure slots array exists
    if (!isset($admin_settings['ads']['custom']['slots']) || !is_array($admin_settings['ads']['custom']['slots'])) {
        $admin_settings['ads']['custom']['slots'] = [];
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update_google_ads':
                $admin_settings['ads']['google_ads']['enabled'] = isset($_POST['google_ads_enabled']);
                $admin_settings['ads']['google_ads']['client_id'] = $_POST['google_ads_client'];
                $admin_settings['ads']['google_ads']['slots'] = [
                    'header' => $_POST['google_ads_header'],
                    'sidebar' => $_POST['google_ads_sidebar'],
                    'content' => $_POST['google_ads_content'],
                    'footer' => $_POST['google_ads_footer']
                ];
                break;
                
            case 'update_ezoic':
                $admin_settings['ads']['ezoic']['enabled'] = isset($_POST['ezoic_enabled']);
                $admin_settings['ads']['ezoic']['site_id'] = $_POST['ezoic_site_id'];
                $admin_settings['ads']['ezoic']['slots'] = [
                    'header' => $_POST['ezoic_header'],
                    'sidebar' => $_POST['ezoic_sidebar'],
                    'content' => $_POST['ezoic_content'],
                    'footer' => $_POST['ezoic_footer']
                ];
                break;
                
            case 'update_custom_ads':
                $admin_settings['ads']['custom']['enabled'] = isset($_POST['custom_ads_enabled']);
                $admin_settings['ads']['custom']['slots'] = [];
                
                foreach ($_POST['custom_ads'] as $index => $ad) {
                    if (!empty($ad['code'])) {
                        $admin_settings['ads']['custom']['slots'][] = [
                            'name' => $ad['name'],
                            'position' => $ad['position'],
                            'code' => $ad['code']
                        ];
                    }
                }
                break;
        }
        
        // Save configuration
        file_put_contents('../config/admin_settings.json', json_encode($admin_settings, JSON_PRETTY_PRINT));
        $success_message = 'Ad settings updated successfully';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ad Management - Pinterest Video Downloader Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <?php include 'header.php'; ?>
    
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-2xl font-bold mb-6">Ad Management</h1>
        
        <?php if (isset($success_message)): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>
        
        <div class="grid grid-cols-1 gap-6">
            <!-- Google AdSense -->
            <div class="bg-white p-6 rounded-lg shadow">
                <form method="POST" action="">
                    <input type="hidden" name="action" value="update_google_ads">
                    
                    <div class="flex items-center justify-between mb-4">
                        <h2 class="text-xl font-semibold">Google AdSense</h2>
                        <label class="flex items-center">
                            <input type="checkbox" name="google_ads_enabled" 
                                   <?php echo $admin_settings['ads']['google_ads']['enabled'] ? 'checked' : ''; ?> 
                                   class="mr-2">
                            Enable Google AdSense
                        </label>
                    </div>
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-gray-700 mb-2">Client ID</label>
                            <input type="text" name="google_ads_client" 
                                   value="<?php echo htmlspecialchars($admin_settings['ads']['google_ads']['client_id']); ?>" 
                                   class="w-full px-3 py-2 border rounded">
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-gray-700 mb-2">Header Ad Slot</label>
                                <input type="text" name="google_ads_header" 
                                       value="<?php echo htmlspecialchars($admin_settings['ads']['google_ads']['slots']['header']); ?>" 
                                       class="w-full px-3 py-2 border rounded">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">Sidebar Ad Slot</label>
                                <input type="text" name="google_ads_sidebar" 
                                       value="<?php echo htmlspecialchars($admin_settings['ads']['google_ads']['slots']['sidebar']); ?>" 
                                       class="w-full px-3 py-2 border rounded">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">Content Ad Slot</label>
                                <input type="text" name="google_ads_content" 
                                       value="<?php echo htmlspecialchars($admin_settings['ads']['google_ads']['slots']['content']); ?>" 
                                       class="w-full px-3 py-2 border rounded">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">Footer Ad Slot</label>
                                <input type="text" name="google_ads_footer" 
                                       value="<?php echo htmlspecialchars($admin_settings['ads']['google_ads']['slots']['footer']); ?>" 
                                       class="w-full px-3 py-2 border rounded">
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                            Save Google AdSense Settings
                        </button>
                    </div>
                </form>
            </div>
            
            <!-- Ezoic Ads -->
            <div class="bg-white p-6 rounded-lg shadow">
                <form method="POST" action="">
                    <input type="hidden" name="action" value="update_ezoic">
                    
                    <div class="flex items-center justify-between mb-4">
                        <h2 class="text-xl font-semibold">Ezoic Ads</h2>
                        <label class="flex items-center">
                            <input type="checkbox" name="ezoic_enabled" 
                                   <?php echo $admin_settings['ads']['ezoic']['enabled'] ? 'checked' : ''; ?> 
                                   class="mr-2">
                            Enable Ezoic Ads
                        </label>
                    </div>
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-gray-700 mb-2">Site ID</label>
                            <input type="text" name="ezoic_site_id" 
                                   value="<?php echo htmlspecialchars($admin_settings['ads']['ezoic']['site_id']); ?>" 
                                   class="w-full px-3 py-2 border rounded">
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-gray-700 mb-2">Header Placeholder</label>
                                <input type="text" name="ezoic_header" 
                                       value="<?php echo htmlspecialchars($admin_settings['ads']['ezoic']['slots']['header']); ?>" 
                                       class="w-full px-3 py-2 border rounded">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">Sidebar Placeholder</label>
                                <input type="text" name="ezoic_sidebar" 
                                       value="<?php echo htmlspecialchars($admin_settings['ads']['ezoic']['slots']['sidebar']); ?>" 
                                       class="w-full px-3 py-2 border rounded">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">Content Placeholder</label>
                                <input type="text" name="ezoic_content" 
                                       value="<?php echo htmlspecialchars($admin_settings['ads']['ezoic']['slots']['content']); ?>" 
                                       class="w-full px-3 py-2 border rounded">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">Footer Placeholder</label>
                                <input type="text" name="ezoic_footer" 
                                       value="<?php echo htmlspecialchars($admin_settings['ads']['ezoic']['slots']['footer']); ?>" 
                                       class="w-full px-3 py-2 border rounded">
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                            Save Ezoic Settings
                        </button>
                    </div>
                </form>
            </div>
            
            <!-- Custom Ads -->
            <div class="bg-white p-6 rounded-lg shadow">
                <form method="POST" action="">
                    <input type="hidden" name="action" value="update_custom_ads">
                    
                    <div class="flex items-center justify-between mb-4">
                        <h2 class="text-xl font-semibold">Custom Ads</h2>
                        <label class="flex items-center">
                            <input type="checkbox" name="custom_ads_enabled" 
                                   <?php echo $admin_settings['ads']['custom']['enabled'] ? 'checked' : ''; ?> 
                                   class="mr-2">
                            Enable Custom Ads
                        </label>
                    </div>
                    
                    <div id="custom-ads-container" class="space-y-4">
                        <?php foreach ($admin_settings['ads']['custom']['slots'] as $index => $ad): ?>
                            <div class="border p-4 rounded">
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                    <div>
                                        <label class="block text-gray-700 mb-2">Ad Name</label>
                                        <input type="text" name="custom_ads[<?php echo $index; ?>][name]" 
                                               value="<?php echo htmlspecialchars($ad['name']); ?>" 
                                               class="w-full px-3 py-2 border rounded">
                                    </div>
                                    <div>
                                        <label class="block text-gray-700 mb-2">Position</label>
                                        <select name="custom_ads[<?php echo $index; ?>][position]" 
                                                class="w-full px-3 py-2 border rounded">
                                            <option value="header" <?php echo $ad['position'] === 'header' ? 'selected' : ''; ?>>Header</option>
                                            <option value="sidebar" <?php echo $ad['position'] === 'sidebar' ? 'selected' : ''; ?>>Sidebar</option>
                                            <option value="content" <?php echo $ad['position'] === 'content' ? 'selected' : ''; ?>>Content</option>
                                            <option value="footer" <?php echo $ad['position'] === 'footer' ? 'selected' : ''; ?>>Footer</option>
                                        </select>
                                    </div>
                                </div>
                                <div>
                                    <label class="block text-gray-700 mb-2">Ad Code</label>
                                    <textarea name="custom_ads[<?php echo $index; ?>][code]" 
                                              rows="4" class="w-full px-3 py-2 border rounded"><?php 
                                        echo htmlspecialchars($ad['code']); 
                                    ?></textarea>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="mt-4 space-x-4">
                        <button type="button" onclick="addCustomAd()" 
                                class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
                            Add Custom Ad
                        </button>
                        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                            Save Custom Ads
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
    function addCustomAd() {
        const container = document.getElementById('custom-ads-container');
        const index = container.children.length;
        
        const template = `
            <div class="border p-4 rounded">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-gray-700 mb-2">Ad Name</label>
                        <input type="text" name="custom_ads[${index}][name]" class="w-full px-3 py-2 border rounded">
                    </div>
                    <div>
                        <label class="block text-gray-700 mb-2">Position</label>
                        <select name="custom_ads[${index}][position]" class="w-full px-3 py-2 border rounded">
                            <option value="header">Header</option>
                            <option value="sidebar">Sidebar</option>
                            <option value="content">Content</option>
                            <option value="footer">Footer</option>
                        </select>
                    </div>
                </div>
                <div>
                    <label class="block text-gray-700 mb-2">Ad Code</label>
                    <textarea name="custom_ads[${index}][code]" rows="4" class="w-full px-3 py-2 border rounded"></textarea>
                </div>
            </div>
        `;
        
        container.insertAdjacentHTML('beforeend', template);
    }
    </script>
    
    <?php include 'footer.php'; ?>
</body>
</html>
