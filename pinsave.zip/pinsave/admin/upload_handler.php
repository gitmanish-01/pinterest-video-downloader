<?php
session_start();
require_once 'auth.php';
require_once 'functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('HTTP/1.1 403 Forbidden');
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = ['success' => false];
    
    // Handle Pinterest URL image download
    if (isset($_POST['pinterest_url'])) {
        $url = $_POST['pinterest_url'];
        $config = loadConfig();
        $api_key = $config['api']['rapidapi_key'];
        
        // Use RapidAPI to get image URL
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://pinterest-video-and-image-downloader.p.rapidapi.com/pinterest?url=" . urlencode($url));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "X-RapidAPI-Host: pinterest-video-and-image-downloader.p.rapidapi.com",
            "X-RapidAPI-Key: " . $api_key
        ]);
        
        $result = curl_exec($ch);
        curl_close($ch);
        
        if ($result) {
            $data = json_decode($result, true);
            if (isset($data['image_url'])) {
                // Create uploads directory if it doesn't exist
                $upload_dir = __DIR__ . '/uploads';
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                
                // Download and save the image
                $image_data = file_get_contents($data['image_url']);
                $filename = 'pin_' . time() . '.jpg';
                $filepath = $upload_dir . '/' . $filename;
                
                if (file_put_contents($filepath, $image_data)) {
                    $response = [
                        'success' => true,
                        'url' => '/admin/uploads/' . $filename
                    ];
                }
            }
        }
    }
    
    // Handle direct file upload
    if (isset($_FILES['image'])) {
        $upload_dir = __DIR__ . '/uploads';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file = $_FILES['image'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array($ext, $allowed) && $file['error'] === 0) {
            $filename = 'upload_' . time() . '.' . $ext;
            $filepath = $upload_dir . '/' . $filename;
            
            if (move_uploaded_file($file['tmp_name'], $filepath)) {
                $response = [
                    'success' => true,
                    'url' => '/admin/uploads/' . $filename
                ];
            }
        }
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}
?>
