<?php
// Redirect to the post editor page through the admin index
header('Location: index.php?page=post-editor');
exit;
?>
