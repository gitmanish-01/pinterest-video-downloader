<?php
// Start session
session_start();

// Include configuration
require_once 'includes/config.php';
require_once '../includes/stats_handler.php';
require_once '../includes/api_handler.php';
require_once '../includes/Taxonomy.php';
require_once '../includes/Template.php';
require_once '../includes/Cache.php';

// Handle logout action
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    header('Location: login.php');
    exit;
}

// Check if user is logged in
if (!isset($_SESSION[SESSION_NAME]) || $_SESSION[SESSION_NAME] !== true) {
    header('Location: login.php');
    exit;
}

// Get current page
$page = $_GET['page'] ?? 'dashboard';
$validPages = ['dashboard', 'api', 'ads', 'seo', 'posts', 'post-editor', 'categories', 'tags', 'menu-builder', 'page-editor'];
if (!in_array($page, $validPages)) {
    $page = 'dashboard';
}

// Page title
$pageTitle = ucfirst($page);

// Initialize handlers for dashboard
$stats_handler = new StatsHandler();
$api_handler = new ApiHandler();

// Initialize default values
$categories = [];
$tags = [];
$published_posts = [];
$total_requests = 0;
$today_stats = ['total_requests' => 0, 'successful_requests' => 0, 'failed_requests' => 0];
$api_status = false;

try {
    // Get taxonomy data
    $taxonomy = new Taxonomy($config);
    $categories = $taxonomy->getCategories() ?? [];
    $tags = $taxonomy->getTags() ?? [];
    $all_posts = $taxonomy->getPosts() ?? [];
    $published_posts = array_filter($all_posts, function($post) {
        return isset($post['visibility']) && $post['visibility'] === 'public';
    });

    // Get statistics with error handling
    $stats = $stats_handler->getStats() ?? [];
    $today = date('Y-m-d');
    $today_stats = $stats['daily']['days'][$today] ?? [
        'total_requests' => 0,
        'successful_requests' => 0,
        'failed_requests' => 0
    ];

    // Calculate total requests
    $total_requests = 0;
    if (isset($stats['daily']['days']) && is_array($stats['daily']['days'])) {
        foreach ($stats['daily']['days'] as $day) {
            $total_requests += isset($day['total_requests']) ? (int)$day['total_requests'] : 0;
        }
    }

    // Get API status
    $api_status = $api_handler->checkApiStatus();
    
    // Get API health stats
    $api_health = $stats['health']['providers'] ?? [];
    $healthy_providers = array_filter($api_health, function($provider) {
        return isset($provider['status']) && $provider['status'] === 'healthy';
    });
    $warning_providers = array_filter($api_health, function($provider) {
        return isset($provider['status']) && $provider['status'] === 'warning';
    });
    $critical_providers = array_filter($api_health, function($provider) {
        return isset($provider['status']) && $provider['status'] === 'critical';
    });
} catch (Exception $e) {
    error_log('Dashboard Error: ' . $e->getMessage());
    $categories = [];
    $tags = [];
    $published_posts = [];
    $total_requests = 0;
    $today_stats = ['total_requests' => 0, 'successful_requests' => 0, 'failed_requests' => 0];
    $api_status = false;
    $api_health = [];
    $healthy_providers = [];
    $warning_providers = [];
    $critical_providers = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PinSave Admin - <?php echo $pageTitle; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- CKEditor - Free rich text editor -->
    <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
    <style>
        .ck-editor__editable {
            min-height: 300px;
        }
        .ck-content {
            font-size: 1rem;
        }
        .ck.ck-editor {
            margin-bottom: 20px;
        }
    </style>
</head>
<body class="bg-gray-100 flex flex-col min-h-screen pb-6">
    <?php include 'includes/header.php'; ?>

    <main class="flex-1 overflow-x-hidden overflow-y-auto">
            <?php 
            if ($page === 'dashboard') {
                // Dashboard content
                include 'pages/dashboard-content.php';
            } else {
                // Include the requested page
                $page_file = "pages/{$page}.php";
                if (file_exists($page_file)) {
                    include $page_file;
                } else {
                    echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">';
                    echo '<p>Page not found: ' . htmlspecialchars($page) . '</p>';
                    echo '</div>';
                    include 'pages/dashboard-content.php';
                }
            }
            ?>
        </main>
    </div>
    
    <?php include 'includes/footer.php'; ?>

    <script>
        // Notification system
        document.addEventListener('DOMContentLoaded', function() {
            // Auto-hide notifications after 5 seconds
            const notifications = document.querySelectorAll('.notification');
            notifications.forEach(notification => {
                setTimeout(() => {
                    notification.style.opacity = '0';
                    setTimeout(() => notification.remove(), 300);
                }, 5000);
            });
        });
        
        // Toggle submenu function for sidebar navigation
        function toggleSubmenu(submenuId) {
            const submenu = document.getElementById(submenuId);
            if (submenu) {
                submenu.classList.toggle('hidden');
                
                // Find the chevron icon in the parent element and toggle it
                const parentElement = submenu.previousElementSibling;
                if (parentElement) {
                    const chevron = parentElement.querySelector('.fa-chevron-down');
                    if (chevron) {
                        chevron.classList.toggle('fa-chevron-down');
                        chevron.classList.toggle('fa-chevron-up');
                    }
                }
            }
        }
    </script>
</body>
</html>
