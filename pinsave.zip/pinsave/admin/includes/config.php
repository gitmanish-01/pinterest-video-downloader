<?php
// Admin panel configuration
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD_HASH', password_hash('admin123', PASSWORD_DEFAULT)); // Change this in production!
define('SESSION_NAME', 'pinsave_admin');
define('SESSION_LIFETIME', 3600); // 1 hour
define('SITE_URL', (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']);

// Database configuration (for future use)
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'pinsave');

// API configurations
$config = [];

// Load configuration from file if exists
$configFile = __DIR__ . '/../../config/admin_settings.json';
if (file_exists($configFile)) {
    $configData = json_decode(file_get_contents($configFile), true);
    if (is_array($configData)) {
        $config = $configData;
    }
}

// Default configurations if not set
if (!isset($config['api'])) {
    $config['api'] = [
        'rapidapi_key' => '',
        'api_provider' => 'pinterest-video-downloader1',
        'debug_mode' => true
    ];
}

if (!isset($config['ads'])) {
    $config['ads'] = [
        'google_ads' => [
            'enabled' => false,
            'publisher_id' => '',
            'ad_slot_top' => '',
            'ad_slot_bottom' => '',
            'ad_slot_sidebar' => ''
        ],
        'ezoic_ads' => [
            'enabled' => false,
            'site_id' => '',
            'script' => ''
        ]
    ];
}

if (!isset($config['seo'])) {
    $config['seo'] = [
        'title' => 'Free Pinterest Video Downloader - Save Pinterest Videos Easily | PinSave',
        'description' => 'Download Pinterest videos for free with PinSave. Save Pinterest videos in HD quality without watermark. Works with pin.it links and all Pinterest video posts.',
        'keywords' => 'pinterest video downloader, download pinterest videos, save pinterest videos, pinterest video saver, pin.it video downloader, pinterest reels downloader'
    ];
}

if (!isset($config['articles'])) {
    $config['articles'] = [];
}

if (!isset($config['menus'])) {
    $config['menus'] = [
        'locations' => [
            'top' => [],
            'footer' => [],
            'sidebar' => []
        ]
    ];
}

// Function to save configuration
function saveConfig($newConfig) {
    global $config;
    $config = $newConfig;
    $configDir = __DIR__ . '/../../config';
    
    if (!is_dir($configDir)) {
        mkdir($configDir, 0755, true);
    }
    
    $configFile = $configDir . '/admin_settings.json';
    return file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT));
}

// Function to check if user is logged in
function isLoggedIn() {
    return isset($_SESSION[SESSION_NAME]) && $_SESSION[SESSION_NAME] === true;
}

// Function to require login
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

// Alias for isLoggedIn() to maintain compatibility
function isAdminLoggedIn() {
    return isLoggedIn();
}
