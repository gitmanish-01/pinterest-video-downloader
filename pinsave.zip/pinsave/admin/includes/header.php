<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION[SESSION_NAME]) || $_SESSION[SESSION_NAME] !== true) {
    header('Location: login.php');
    exit;
}

// Get current page for navigation highlighting
$current_page = $_GET['page'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PinSave Admin - <?php echo isset($GLOBALS['page_title']) ? $GLOBALS['page_title'] : ucfirst($current_page); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/admin-style.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e8a5f',
                        'primary-light': '#e6f4ee',
                        'primary-dark': '#166e4a'
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif']
                    }
                }
            }
        }
    </script>
</head>
<!-- Note: body tag is already in index.php -->
    <!-- Sidebar Navigation -->
        <!-- Sidebar Navigation -->
        <aside class="sidebar fixed h-full z-10">
            <div class="sidebar-logo">
                <a href="index.php" class="flex items-center">
                    <svg class="w-8 h-8 text-primary mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M10 0C4.478 0 0 4.478 0 10c0 4.209 2.598 7.803 6.279 9.279.459.084.627-.198.627-.443 0-.22-.008-.803-.012-1.575-2.553.555-3.092-1.232-3.092-1.232-.418-1.059-1.019-1.343-1.019-1.343-.832-.569.063-.558.063-.558.92.064 1.404.946 1.404.946.817 1.4 2.143.996 2.662.762.083-.592.32-1 .582-1.23-2.037-.232-4.182-1.018-4.182-4.536 0-1.001.358-1.819.945-2.46-.095-.232-.41-1.169.09-2.437 0 0 .77-.247 2.52.94a8.765 8.765 0 012.292-.308c.778.003 1.56.105 2.292.308 1.748-1.186 2.518-.94 2.518-.94.5 1.268.186 2.205.09 2.437.588.641.944 1.459.944 2.46 0 3.527-2.148 4.301-4.194 4.527.33.284.62.842.62 1.695 0 1.225-.011 2.212-.011 2.511 0 .244.166.528.63.438C17.404 17.797 20 14.206 20 10c0-5.522-4.478-10-10-10z"/>
                    </svg>
                    <span class="font-semibold text-lg text-primary">PinSave</span>
                </a>
            </div>
            <nav class="sidebar-menu">
                <a href="index.php?page=dashboard" class="sidebar-menu-item <?php echo $current_page === 'dashboard' ? 'active' : ''; ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
                <a href="index.php?page=posts" class="sidebar-menu-item <?php echo $current_page === 'posts' || $current_page === 'post-editor' ? 'active' : ''; ?>">
                    <i class="fas fa-file-alt"></i>
                    <span>Posts</span>
                </a>
                <a href="index.php?page=categories" class="sidebar-menu-item <?php echo $current_page === 'categories' ? 'active' : ''; ?>">
                    <i class="fas fa-folder"></i>
                    <span>Categories</span>
                </a>
                <a href="index.php?page=tags" class="sidebar-menu-item <?php echo $current_page === 'tags' ? 'active' : ''; ?>">
                    <i class="fas fa-tags"></i>
                    <span>Tags</span>
                </a>
                <a href="index.php?page=api" class="sidebar-menu-item <?php echo $current_page === 'api' ? 'active' : ''; ?>">
                    <i class="fas fa-plug"></i>
                    <span>API Settings</span>
                </a>
                <a href="index.php?page=seo" class="sidebar-menu-item <?php echo $current_page === 'seo' ? 'active' : ''; ?>">
                    <i class="fas fa-search"></i>
                    <span>SEO</span>
                </a>
                <a href="index.php?page=ads" class="sidebar-menu-item <?php echo $current_page === 'ads' ? 'active' : ''; ?>">
                    <i class="fas fa-ad"></i>
                    <span>Ads</span>
                </a>
                <a href="index.php?page=menu-builder" class="sidebar-menu-item <?php echo $current_page === 'menu-builder' ? 'active' : ''; ?>">
                    <i class="fas fa-bars"></i>
                    <span>Menu Builder</span>
                </a>
                <a href="index.php?page=page-editor" class="sidebar-menu-item <?php echo $current_page === 'page-editor' ? 'active' : ''; ?>">
                    <i class="fas fa-file-alt"></i>
                    <span>Page Editor</span>
                </a>
                <div class="sidebar-divider"></div>
                <a href="?action=logout" class="sidebar-menu-item text-red-500">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </nav>
        </aside>
        
        <!-- Main Content Area -->
        <div class="flex-1 ml-64">
            <!-- Top Header -->
            <header class="main-header">
                <div class="flex items-center">
                    <button id="mobile-menu-button" class="mr-2 md:hidden">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                        </svg>
                    </button>
                    <h1 class="text-xl font-semibold text-gray-800"><?php echo ucfirst($current_page); ?></h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <a href="/" class="text-gray-600 hover:text-primary flex items-center" target="_blank">
                        <i class="fas fa-external-link-alt mr-1"></i> 
                        <span class="hidden md:inline">View Site</span>
                    </a>
                    <div class="relative">
                        <button class="flex items-center space-x-1 bg-white rounded-full p-1 pr-3 shadow-sm border border-gray-200 hover:border-primary transition-colors">
                            <span class="w-8 h-8 rounded-full bg-primary-light flex items-center justify-center text-primary font-semibold">A</span>
                            <span class="text-sm font-medium text-gray-700">Admin</span>
                            <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                            </svg>
                        </button>
                    </div>
                </div>
            </header>
            
            <!-- Mobile Menu Overlay -->
            <div id="mobile-menu" class="fixed inset-0 bg-gray-900 bg-opacity-50 z-20 hidden md:hidden">
                <div class="bg-white w-64 h-full overflow-y-auto">
                    <div class="p-4 flex justify-between items-center border-b">
                        <span class="font-semibold text-lg text-primary">PinSave</span>
                        <button id="close-mobile-menu">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>
                    <!-- Mobile menu items will be dynamically added here -->
                </div>
            </div>
            
            <script>
                // Mobile menu toggle
                document.getElementById('mobile-menu-button')?.addEventListener('click', function() {
                    document.getElementById('mobile-menu')?.classList.toggle('hidden');
                });
                
                document.getElementById('close-mobile-menu')?.addEventListener('click', function() {
                    document.getElementById('mobile-menu')?.classList.add('hidden');
                });
            </script>
