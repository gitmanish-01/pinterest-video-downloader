    </main> <!-- End Main Content -->
    
    <!-- Footer -->
    <footer class="bg-white shadow-inner mt-auto mx-6 mb-6 rounded-2xl overflow-hidden">
        <div class="px-6 py-4">
            <div class="flex justify-between items-center">
                <div class="text-sm text-gray-600">
                    &copy; <?php echo date('Y'); ?> PinSave Admin Panel
                </div>
                <div class="text-sm text-gray-600 flex items-center">
                    <span class="inline-block w-2 h-2 rounded-full bg-green-500 mr-2"></span>
                    Version 1.0.0
                </div>
            </div>
        </div>
    </footer>

<!-- Custom Scripts -->
    <script>
        // Add any custom JavaScript here
        document.addEventListener('DOMContentLoaded', function() {
            // Handle notifications
            const notifications = document.querySelectorAll('.notification');
            notifications.forEach(notification => {
                setTimeout(() => {
                    notification.style.opacity = '0';
                    setTimeout(() => notification.remove(), 300);
                }, 5000);
            });
        });
    </script>
</body>
</html>
