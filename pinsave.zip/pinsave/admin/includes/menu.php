<?php
// Get current page from URL
$current_page = $_GET['page'] ?? 'dashboard';

// Helper function to sanitize strings for use in IDs
function sanitize($string) {
    return preg_replace('/[^a-z0-9]/i', '-', strtolower($string));
}

// Define menu items with their properties
$menu_items = [
    [
        'title' => 'Dashboard',
        'icon' => 'fas fa-tachometer-alt',
        'url' => '?page=dashboard',
        'active' => $current_page === 'dashboard'
    ],
    [
        'title' => 'Blog',
        'icon' => 'fas fa-blog',
        'url' => '#',
        'active' => $current_page === 'posts' || $current_page === 'post-editor' || $current_page === 'add-dummy-posts',
        'submenu' => [
            [
                'title' => 'All Posts',
                'url' => '?page=posts',
                'active' => $current_page === 'posts' || $current_page === 'post-editor'
            ],
            [
                'title' => 'Add Dummy Posts',
                'url' => 'add-dummy-posts.php',
                'active' => $current_page === 'add-dummy-posts'
            ]
        ]
    ],
    [
        'title' => 'Tags',
        'icon' => 'fas fa-tags',
        'url' => '?page=tags',
        'active' => $current_page === 'tags'
    ],
    [
        'title' => 'SEO Settings',
        'icon' => 'fas fa-search',
        'url' => '?page=seo',
        'active' => $current_page === 'seo'
    ],
    [
        'title' => 'API Settings',
        'icon' => 'fas fa-key',
        'url' => '?page=api',
        'active' => $current_page === 'api'
    ],
    [
        'title' => 'Ad Management',
        'icon' => 'fas fa-ad',
        'url' => '?page=ads',
        'active' => $current_page === 'ads'
    ]
];
?>

<aside class="w-64 bg-white border-r border-gray-200">
    <div class="flex flex-col h-full">
        <div class="flex items-center justify-between h-16 px-4 border-b border-gray-200">
            <span class="text-lg font-semibold">PinSave Admin</span>
        </div>
        
        <nav class="flex-1 overflow-y-auto py-4">
            <?php foreach ($menu_items as $item): ?>
                <?php if (isset($item['submenu'])): ?>
                    <div class="mb-2">
                        <div class="flex items-center justify-between px-4 py-2 text-gray-700 hover:bg-gray-100 <?php echo $item['active'] ? 'bg-blue-50 text-blue-700' : ''; ?>" onclick="toggleSubmenu('submenu-<?php echo sanitize($item['title']); ?>')">
                            <div class="flex items-center">
                                <i class="<?php echo $item['icon']; ?> w-5"></i>
                                <span class="ml-3"><?php echo $item['title']; ?></span>
                            </div>
                            <i class="fas fa-chevron-down text-xs"></i>
                        </div>
                        <div id="submenu-<?php echo sanitize($item['title']); ?>" class="pl-8 <?php echo $item['active'] ? '' : 'hidden'; ?>">
                            <?php foreach ($item['submenu'] as $submenu): ?>
                                <a href="<?php echo $submenu['url']; ?>" 
                                   class="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100 <?php echo $submenu['active'] ? 'bg-blue-50 text-blue-700' : ''; ?>">
                                    <span><?php echo $submenu['title']; ?></span>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="<?php echo $item['url']; ?>" 
                       class="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100 <?php echo $item['active'] ? 'bg-blue-50 text-blue-700' : ''; ?>">
                        <i class="<?php echo $item['icon']; ?> w-5"></i>
                        <span class="ml-3"><?php echo $item['title']; ?></span>
                    </a>
                <?php endif; ?>
            <?php endforeach; ?>
        </nav>
        
        <div class="p-4 border-t border-gray-200">
            <a href="/" class="flex items-center text-gray-700 hover:text-gray-900">
                <i class="fas fa-external-link-alt w-5"></i>
                <span class="ml-3">View Site</span>
            </a>
            <a href="?action=logout" class="flex items-center text-red-600 hover:text-red-700 mt-2">
                <i class="fas fa-sign-out-alt w-5"></i>
                <span class="ml-3">Logout</span>
            </a>
        </div>
    </div>
</aside>
