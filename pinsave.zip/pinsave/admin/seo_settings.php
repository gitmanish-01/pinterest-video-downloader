<?php
// Start session
session_start();

// Include configuration
require_once 'includes/config.php';
require_once '../includes/stats_handler.php';

// Check if user is logged in
if (!isset($_SESSION[SESSION_NAME]) || $_SESSION[SESSION_NAME] !== true) {
    header('Location: login.php');
    exit;
}

// Load admin settings
$admin_settings_file = '../config/admin_settings.json';
$admin_settings = json_decode(file_get_contents($admin_settings_file), true);

// Ensure SEO section exists with default values
if (!isset($admin_settings['seo'])) {
    $admin_settings['seo'] = [];
}

// Set default values for all SEO fields if they don't exist
$default_seo = [
    'site_title' => 'Pinterest Video Downloader',
    'meta_description' => 'Download Pinterest videos and images easily with our free online tool.',
    'meta_keywords' => 'pinterest, video downloader, pinterest downloader, download pinterest videos',
    'robots' => 'index, follow',
    'og_image' => '',
    'twitter_card' => 'summary',
    'canonical_url' => '',
    'google_analytics' => '',
    'sitemap_enabled' => false,
    'structured_data' => false
];

// Merge defaults with existing settings
$admin_settings['seo'] = array_merge($default_seo, $admin_settings['seo']);

// Initialize SEO settings if not set
if (!isset($admin_settings['seo'])) {
    $admin_settings['seo'] = [
        'site_title' => 'Pinterest Video Downloader - Download Pinterest Videos & Images',
        'meta_description' => 'Free online tool to download Pinterest videos and images in high quality. No registration required.',
        'meta_keywords' => 'pinterest downloader, pinterest video downloader, download pinterest videos, pinterest image downloader',
        'og_image' => '/assets/images/og-image.jpg',
        'twitter_card' => 'summary_large_image',
        'canonical_url' => '',
        'robots' => 'index, follow',
        'google_analytics' => '',
        'sitemap_enabled' => true,
        'structured_data' => true
    ];
}

// Handle form submission
$notification = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_seo'])) {
    // Update SEO settings
    $admin_settings['seo'] = [
        'site_title' => $_POST['site_title'] ?? $admin_settings['seo']['site_title'],
        'meta_description' => $_POST['meta_description'] ?? $admin_settings['seo']['meta_description'],
        'meta_keywords' => $_POST['meta_keywords'] ?? $admin_settings['seo']['meta_keywords'],
        'og_image' => $_POST['og_image'] ?? $admin_settings['seo']['og_image'],
        'twitter_card' => $_POST['twitter_card'] ?? $admin_settings['seo']['twitter_card'],
        'canonical_url' => $_POST['canonical_url'] ?? $admin_settings['seo']['canonical_url'],
        'robots' => $_POST['robots'] ?? $admin_settings['seo']['robots'],
        'google_analytics' => $_POST['google_analytics'] ?? $admin_settings['seo']['google_analytics'],
        'sitemap_enabled' => isset($_POST['sitemap_enabled']),
        'structured_data' => isset($_POST['structured_data'])
    ];
    
    // Save settings
    file_put_contents($admin_settings_file, json_encode($admin_settings, JSON_PRETTY_PRINT));
    
    // Set notification
    $notification = '<div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
        <p>SEO settings updated successfully!</p>
    </div>';
}

// Include header
include 'header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">SEO Settings</h1>
    </div>
    
    <?php echo $notification; ?>
    
    <div class="bg-white rounded-lg shadow p-6">
        <form method="POST" action="">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Left Column -->
                <div>
                    <div class="mb-4">
                        <label for="site_title" class="block text-sm font-medium text-gray-700 mb-1">Site Title</label>
                        <input type="text" id="site_title" name="site_title" value="<?php echo htmlspecialchars($admin_settings['seo']['site_title']); ?>" 
                               class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                        <p class="mt-1 text-sm text-gray-500">The title that appears in search engine results</p>
                    </div>
                    
                    <div class="mb-4">
                        <label for="meta_description" class="block text-sm font-medium text-gray-700 mb-1">Meta Description</label>
                        <textarea id="meta_description" name="meta_description" rows="3" 
                                  class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"><?php echo htmlspecialchars($admin_settings['seo']['meta_description']); ?></textarea>
                        <p class="mt-1 text-sm text-gray-500">Brief description of your site (150-160 characters)</p>
                    </div>
                    
                    <div class="mb-4">
                        <label for="meta_keywords" class="block text-sm font-medium text-gray-700 mb-1">Meta Keywords</label>
                        <input type="text" id="meta_keywords" name="meta_keywords" value="<?php echo htmlspecialchars($admin_settings['seo']['meta_keywords']); ?>" 
                               class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                        <p class="mt-1 text-sm text-gray-500">Comma-separated keywords</p>
                    </div>
                    
                    <div class="mb-4">
                        <label for="robots" class="block text-sm font-medium text-gray-700 mb-1">Robots Meta Tag</label>
                        <select id="robots" name="robots" class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                            <option value="index, follow" <?php echo $admin_settings['seo']['robots'] === 'index, follow' ? 'selected' : ''; ?>>Index, Follow</option>
                            <option value="index, nofollow" <?php echo $admin_settings['seo']['robots'] === 'index, nofollow' ? 'selected' : ''; ?>>Index, No Follow</option>
                            <option value="noindex, follow" <?php echo $admin_settings['seo']['robots'] === 'noindex, follow' ? 'selected' : ''; ?>>No Index, Follow</option>
                            <option value="noindex, nofollow" <?php echo $admin_settings['seo']['robots'] === 'noindex, nofollow' ? 'selected' : ''; ?>>No Index, No Follow</option>
                        </select>
                        <p class="mt-1 text-sm text-gray-500">Controls how search engines crawl and index your site</p>
                    </div>
                </div>
                
                <!-- Right Column -->
                <div>
                    <div class="mb-4">
                        <label for="og_image" class="block text-sm font-medium text-gray-700 mb-1">OG Image URL</label>
                        <input type="text" id="og_image" name="og_image" value="<?php echo htmlspecialchars($admin_settings['seo']['og_image']); ?>" 
                               class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                        <p class="mt-1 text-sm text-gray-500">Image shown when sharing on social media</p>
                    </div>
                    
                    <div class="mb-4">
                        <label for="twitter_card" class="block text-sm font-medium text-gray-700 mb-1">Twitter Card Type</label>
                        <select id="twitter_card" name="twitter_card" class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                            <option value="summary" <?php echo $admin_settings['seo']['twitter_card'] === 'summary' ? 'selected' : ''; ?>>Summary</option>
                            <option value="summary_large_image" <?php echo $admin_settings['seo']['twitter_card'] === 'summary_large_image' ? 'selected' : ''; ?>>Summary with Large Image</option>
                        </select>
                        <p class="mt-1 text-sm text-gray-500">Controls how your content appears when shared on Twitter</p>
                    </div>
                    
                    <div class="mb-4">
                        <label for="canonical_url" class="block text-sm font-medium text-gray-700 mb-1">Canonical URL</label>
                        <input type="text" id="canonical_url" name="canonical_url" value="<?php echo htmlspecialchars($admin_settings['seo']['canonical_url']); ?>" 
                               class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                        <p class="mt-1 text-sm text-gray-500">Leave empty to use current URL (recommended)</p>
                    </div>
                    
                    <div class="mb-4">
                        <label for="google_analytics" class="block text-sm font-medium text-gray-700 mb-1">Google Analytics ID</label>
                        <input type="text" id="google_analytics" name="google_analytics" value="<?php echo htmlspecialchars($admin_settings['seo']['google_analytics']); ?>" 
                               placeholder="UA-XXXXXXXXX-X or G-XXXXXXXXXX" 
                               class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                        <p class="mt-1 text-sm text-gray-500">Your Google Analytics tracking ID</p>
                    </div>
                </div>
            </div>
            
            <!-- Additional Options -->
            <div class="mt-6 border-t pt-4">
                <h3 class="text-lg font-medium mb-4">Additional SEO Features</h3>
                
                <div class="flex items-center mb-4">
                    <input type="checkbox" id="sitemap_enabled" name="sitemap_enabled" <?php echo $admin_settings['seo']['sitemap_enabled'] ? 'checked' : ''; ?> 
                           class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                    <label for="sitemap_enabled" class="ml-2 block text-sm text-gray-900">
                        Enable XML Sitemap
                    </label>
                    <p class="ml-6 text-sm text-gray-500">Automatically generate and update XML sitemap</p>
                </div>
                
                <div class="flex items-center mb-4">
                    <input type="checkbox" id="structured_data" name="structured_data" <?php echo $admin_settings['seo']['structured_data'] ? 'checked' : ''; ?> 
                           class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                    <label for="structured_data" class="ml-2 block text-sm text-gray-900">
                        Enable Structured Data
                    </label>
                    <p class="ml-6 text-sm text-gray-500">Add JSON-LD structured data for better search results</p>
                </div>
            </div>
            
            <!-- SEO Preview -->
            <div class="mt-6 border-t pt-4">
                <h3 class="text-lg font-medium mb-4">Search Result Preview</h3>
                
                <div class="border rounded-lg p-4 bg-gray-50">
                    <div class="text-blue-600 text-xl mb-1" id="preview-title">
                        <?php echo htmlspecialchars($admin_settings['seo']['site_title']); ?>
                    </div>
                    <div class="text-green-700 text-sm mb-1">
                        <?php echo isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'example.com'; ?>
                    </div>
                    <div class="text-gray-600 text-sm" id="preview-description">
                        <?php echo htmlspecialchars($admin_settings['seo']['meta_description']); ?>
                    </div>
                </div>
            </div>
            
            <!-- Submit Button -->
            <div class="mt-6">
                <button type="submit" name="update_seo" class="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-md">
                    Save SEO Settings
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Live preview
document.getElementById('site_title').addEventListener('input', function() {
    document.getElementById('preview-title').textContent = this.value;
});

document.getElementById('meta_description').addEventListener('input', function() {
    document.getElementById('preview-description').textContent = this.value;
});
</script>

<?php include 'footer.php'; ?>
