<?php
// Include configuration
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/stats_handler.php';

// Track visitor
$stats_handler = new StatsHandler();
$ip = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$country = null;

// Get country from IP (you can use a GeoIP service here)
if (isset($_SERVER['HTTP_CF_IPCOUNTRY'])) { // If using Cloudflare
    $country = $_SERVER['HTTP_CF_IPCOUNTRY'];
}

$stats_handler->logVisitor($ip, $user_agent, $country);

// Get blog posts from admin config
$posts = [];
if (isset($adminConfig['posts']) && is_array($adminConfig['posts'])) {
    $posts = $adminConfig['posts'];
}

// Sort posts by date (newest first)
uasort($posts, function($a, $b) {
    $dateA = isset($a['created_at']) ? strtotime($a['created_at']) : 0;
    $dateB = isset($b['created_at']) ? strtotime($b['created_at']) : 0;
    return $dateB - $dateA;
});

// Filter out non-public posts
$posts = array_filter($posts, function($post) {
    return isset($post['visibility']) && $post['visibility'] === 'public';
});

// Set page title and meta
$pageTitle = "Blog";
$metaTitle = "Blog - " . $seoTitle;
$metaDescription = "Read our latest articles and guides about Pinterest videos and more.";
$metaKeywords = "pinterest blog, pinterest video guides, pinterest tips, video downloader blog";

// Include header
require_once __DIR__ . '/header.php';
?>

<style>
    .blog-content img {
        max-width: 100%;
        height: auto;
        margin: 1rem 0;
    }
    
    .blog-content h2 {
        font-size: 1.5rem;
        font-weight: 600;
        margin-top: 1.5rem;
        margin-bottom: 0.75rem;
    }
    
    .blog-content h3 {
        font-size: 1.25rem;
        font-weight: 600;
        margin-top: 1.25rem;
        margin-bottom: 0.5rem;
    }
    
    .blog-content p {
        margin-bottom: 1rem;
    }
    
    .blog-content ul, .blog-content ol {
        margin-left: 1.5rem;
        margin-bottom: 1rem;
    }
    
    .blog-content ul {
        list-style-type: disc;
    }
    
    .blog-content ol {
        list-style-type: decimal;
    }
</style>

<div class="container mx-auto px-4 py-8">
    <div class="text-center mb-8">
        <h1 class="text-3xl font-bold text-gray-800 mb-2"><i class="fas fa-blog text-red-600 mr-2"></i>Our Blog</h1>
        <p class="text-gray-600">Latest articles, guides and updates</p>
    </div>
    
    <main class="max-w-4xl mx-auto">
        <?php if (empty($posts)): ?>
            <div class="bg-white rounded-lg shadow-md p-6 text-center">
                <h2 class="text-xl font-semibold text-gray-700 mb-3">No Posts Yet</h2>
                <p class="text-gray-600">Check back soon for new articles!</p>
            </div>
        <?php else: ?>
            <!-- Blog Posts Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <?php foreach ($posts as $post_id => $post): ?>
                    <div class="bg-white rounded-lg shadow-md overflow-hidden">
                        <div class="p-6">
                            <h2 class="text-xl font-semibold text-gray-800 mb-2">
                                <a href="/pinsave/blog/<?php echo urlencode($post['slug'] ?? $post_id); ?>" class="hover:text-red-600">
                                    <?php echo htmlspecialchars($post['title']); ?>
                                </a>
                            </h2>
                            
                            <div class="flex items-center text-gray-500 text-sm mb-3">
                                <span class="mr-3">
                                    <i class="far fa-calendar-alt mr-1 text-red-600"></i>
                                    <?php echo date('M j, Y', strtotime($post['created_at'])); ?>
                                </span>
                                
                                <?php if (!empty($post['category'])): ?>
                                <span>
                                    <i class="far fa-folder mr-1 text-red-600"></i>
                                    <?php echo htmlspecialchars($post['category']); ?>
                                </span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="text-gray-600 mb-4">
                                <?php 
                                // Create excerpt from content
                                $excerpt = strip_tags($post['content']);
                                $excerpt = substr($excerpt, 0, 150);
                                echo htmlspecialchars($excerpt) . (strlen(strip_tags($post['content'])) > 150 ? '...' : '');
                                ?>
                            </div>
                            
                            <a href="/pinsave/blog/<?php echo urlencode($post['slug'] ?? $post_id); ?>" class="inline-block text-red-600 hover:text-red-700">
                                Read More <i class="fas fa-arrow-right ml-1"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>
</div>

<?php
// Include footer
require_once __DIR__ . '/footer.php';
?>
