<?php
// Environment-specific configuration - DO NOT commit to version control

// API Keys
define('PINTEREST_API_KEY', 'your-api-key-here');
define('PINTEREST_API_HOST', 'pinterest-video-downloader1.p.rapidapi.com');

// Debug settings
define('DEBUG_MODE', false);

// Database credentials (if needed in future)
// define('DB_HOST', 'localhost');
// define('DB_USER', 'root');
// define('DB_PASS', '');
// define('DB_NAME', 'pinsave');
