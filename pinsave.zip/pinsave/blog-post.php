<?php
// Include configuration
require_once 'config.php';
require_once 'includes/stats_handler.php';

// Track visitor
$stats_handler = new StatsHandler();
$ip = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$country = null;

// Get country from IP (you can use a GeoIP service here)
if (isset($_SERVER['HTTP_CF_IPCOUNTRY'])) { // If using Cloudflare
    $country = $_SERVER['HTTP_CF_IPCOUNTRY'];
}

$stats_handler->logVisitor($ip, $user_agent, $country);

// Get post slug from URL (from path info or query string)
$slug = null;
$post = null;
$notFound = true;

// Check if we have a slug in the URL path (SEO-friendly URL)
if (isset($_SERVER['PATH_INFO'])) {
    $slug = trim($_SERVER['PATH_INFO'], '/');
} elseif (isset($_GET['slug'])) {
    // Fallback to query parameter
    $slug = $_GET['slug'];
} elseif (isset($_GET['id'])) {
    // Legacy support for ID-based URLs
    $post_id = $_GET['id'];
    if (isset($adminConfig['posts'][$post_id])) {
        $post = $adminConfig['posts'][$post_id];
        if (isset($post['visibility']) && $post['visibility'] === 'public') {
            $notFound = false;
        }
    }
}

// If we have a slug, find the matching post
if ($slug && !$post) {
    foreach ($adminConfig['posts'] as $id => $p) {
        if (isset($p['slug']) && $p['slug'] === $slug && isset($p['visibility']) && $p['visibility'] === 'public') {
            $post = $p;
            $notFound = false;
            break;
        }
    }
}

// Set page title and meta
if (!$notFound) {
    $pageTitle = $post['title'] . " - " . $seoTitle;
    $pageDescription = !empty($post['seo']['meta_description']) ? $post['seo']['meta_description'] : substr(strip_tags($post['content']), 0, 160);
} else {
    $pageTitle = "Post Not Found - " . $seoTitle;
    $pageDescription = "The requested blog post could not be found.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Primary SEO Meta Tags -->
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($seoKeywords); ?>">
    
    <?php if ($notFound): ?>
    <meta name="robots" content="noindex, nofollow">
    <?php endif; ?>
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="article">
    <meta property="og:url" content="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>">
    <meta property="og:title" content="<?php echo htmlspecialchars($pageTitle); ?>">
    <meta property="og:description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta property="og:image" content="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']; ?>/img/pinsave-preview.jpg">
    
    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>">
    <meta property="twitter:title" content="<?php echo htmlspecialchars($pageTitle); ?>">
    <meta property="twitter:description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta property="twitter:image" content="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']; ?>/img/pinsave-preview.jpg">
    
    <!-- Canonical URL -->
    <link rel="canonical" href="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>">
    
    <!-- Favicon -->
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    
    <!-- Stylesheets -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <style>
        /* Mobile Navigation Styles */
        @media (max-width: 1023px) {
            #nav-items {
                background: white;
                position: absolute;
                left: 0;
                right: 0;
                top: 60px;
                z-index: 10;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                padding: 1rem;
            }
        }
        
        .blog-content img {
            max-width: 100%;
            height: auto;
            margin: 1rem 0;
        }
        
        .blog-content h2 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-top: 1.5rem;
            margin-bottom: 0.75rem;
        }
        
        .blog-content h3 {
            font-size: 1.25rem;
            font-weight: 600;
            margin-top: 1.25rem;
            margin-bottom: 0.5rem;
        }
        
        .blog-content p {
            margin-bottom: 1rem;
        }
        
        .blog-content ul, .blog-content ol {
            margin-left: 1.5rem;
            margin-bottom: 1rem;
        }
        
        .blog-content ul {
            list-style-type: disc;
        }
        
        .blog-content ol {
            list-style-type: decimal;
        }
    </style>
</head>

<body class="bg-gray-100 min-h-screen">
    <?php if (!$notFound): ?>
    <!-- JSON-LD structured data for Blog Article -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "BlogPosting",
        "headline": "<?php echo htmlspecialchars($post['title']); ?>",
        "description": "<?php echo htmlspecialchars($pageDescription); ?>",
        "image": "<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']; ?>/img/pinsave-preview.jpg",
        "datePublished": "<?php echo date('c', strtotime($post['created_at'])); ?>",
        "dateModified": "<?php echo date('c', strtotime($post['updated_at'])); ?>",
        "author": {
            "@type": "Organization",
            "name": "PinSave",
            "url": "<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']; ?>"
        },
        "publisher": {
            "@type": "Organization",
            "name": "PinSave",
            "logo": {
                "@type": "ImageObject",
                "url": "<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']; ?>/pinlogo.png"
            }
        },
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": "<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>"
        },
        <?php if (!empty($post['tags']) && is_array($post['tags'])): ?>
        "keywords": "<?php echo htmlspecialchars(implode(', ', $post['tags'])); ?>",
        <?php endif; ?>
        "articleSection": "<?php echo htmlspecialchars($post['category'] ?? 'Blog'); ?>"
    }
    </script>
    <?php endif; ?>
    <div class="container mx-auto px-4 py-8">
        <header class="text-center mb-8">
            <!-- Navigation Menu -->
            <nav class="bg-white shadow-md rounded-lg mb-8">
                <div class="container mx-auto px-4">
                    <!-- Mobile Menu Button -->
                    <div class="flex justify-between items-center py-3 lg:hidden">
                        <a href="/pinsave/" class="text-blue-600 hover:text-blue-800 text-lg font-medium"><img src="pinlogo.png" alt="PinSave" class="h-8"></a>
                        <button id="mobile-menu-button" class="text-gray-600 hover:text-blue-600 focus:outline-none">
                            <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path class="menu-open" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                                <path class="menu-close hidden" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>

                    <!-- Desktop/Mobile Menu Items -->
                    <div id="nav-items" class="hidden lg:flex flex-col lg:flex-row justify-center items-start lg:items-center py-3 gap-4">
                        <a href="/pinsave/" class="text-blue-600 hover:text-blue-800 px-3 py-2 rounded-md text-sm font-medium">Home</a>
                        <a href="/pinsave/blog.php" class="text-blue-600 hover:text-blue-800 px-3 py-2 rounded-md text-sm font-medium">Blog</a>
                    </div>
                </div>
            </nav>
        </header>
        
        <main class="max-w-3xl mx-auto">
            <?php if ($notFound): ?>
                <!-- Not Found Message -->
                <div class="bg-white rounded-lg shadow-md p-6 text-center">
                    <h1 class="text-2xl font-bold text-gray-800 mb-4">Post Not Found</h1>
                    <p class="text-gray-600 mb-6">The blog post you're looking for doesn't exist or isn't available.</p>
                    <a href="/pinsave/blog.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded">
                        <i class="fas fa-arrow-left mr-2"></i> Back to Blog
                    </a>
                </div>
            <?php else: ?>
                <!-- Blog Post Content -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="p-6">
                        <h1 class="text-2xl font-bold text-gray-800 mb-4"><?php echo htmlspecialchars($post['title']); ?></h1>
                        
                        <div class="flex items-center text-gray-500 text-sm mb-6">
                            <span class="mr-4">
                                <i class="far fa-calendar-alt mr-1"></i>
                                <?php echo date('M j, Y', strtotime($post['created_at'])); ?>
                            </span>
                            
                            <?php if (!empty($post['category'])): ?>
                            <span class="mr-4">
                                <i class="far fa-folder mr-1"></i>
                                <?php echo htmlspecialchars($post['category']); ?>
                            </span>
                            <?php endif; ?>
                            
                            <?php if (!empty($post['tags']) && is_array($post['tags'])): ?>
                            <span>
                                <i class="fas fa-tags mr-1"></i>
                                <?php echo htmlspecialchars(implode(', ', $post['tags'])); ?>
                            </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="blog-content prose max-w-none text-gray-700">
                            <?php echo $post['content']; ?>
                        </div>
                        
                        <!-- Back to Blog Link -->
                        <div class="mt-8 pt-4 border-t border-gray-200">
                            <a href="/pinsave/blog.php" class="inline-block text-blue-600 hover:text-blue-800">
                                <i class="fas fa-arrow-left mr-2"></i> Back to Blog
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </main>
        
        <footer class="text-center mt-10 text-gray-500">
            <!-- Footer Card -->
            <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-6 mb-8">
                <!-- Copyright -->
                <div class="text-center text-gray-600 text-sm">
                    <p><?php echo htmlspecialchars($footerConfig['copyright_text'] ?? '© ' . date('Y') . ' PinSave - Pinterest Video Downloader | All Rights Reserved'); ?></p>
                </div>
            </div>
        </footer>
    </div>
    
    <!-- Mobile Menu Script -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuButton = document.getElementById('mobile-menu-button');
            const navItems = document.getElementById('nav-items');
            const menuOpen = mobileMenuButton.querySelector('.menu-open');
            const menuClose = mobileMenuButton.querySelector('.menu-close');
            
            mobileMenuButton.addEventListener('click', function() {
                navItems.classList.toggle('hidden');
                menuOpen.classList.toggle('hidden');
                menuClose.classList.toggle('hidden');
            });
        });
    </script>
</body>
</html>
