<?php
// Include configuration
require_once 'config.php';

// Set content type to XML
header("Content-Type: application/xml; charset=utf-8");

// Get the site base URL
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https://" : "http://";
$baseUrl = $protocol . $_SERVER['HTTP_HOST'];

// Start XML output
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
        http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">

    <!-- Homepage -->
    <url>
        <loc><?php echo $baseUrl; ?>/</loc>
        <lastmod><?php echo date('Y-m-d'); ?></lastmod>
        <changefreq>daily</changefreq>
        <priority>1.0</priority>
    </url>

    <!-- Articles index page -->
    <url>
        <loc><?php echo $baseUrl; ?>/articles.php</loc>
        <lastmod><?php echo date('Y-m-d'); ?></lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.8</priority>
    </url>
    
    <!-- Individual articles -->
    <?php if(!empty($articles)): foreach($articles as $articleId => $article): 
          if(!empty($article['slug'])): 
          
          // Get lastmod date from published_date or default to current date
          $lastmod = !empty($article['published_date']) ? $article['published_date'] : date('Y-m-d');
    ?>
    <url>
        <loc><?php echo $baseUrl; ?>/article/<?php echo urlencode($article['slug']); ?></loc>
        <lastmod><?php echo $lastmod; ?></lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.7</priority>
    </url>
    <?php endif; endforeach; endif; ?>
    
    <!-- Blog posts -->
    <?php if(!empty($adminConfig['posts'])): 
          foreach($adminConfig['posts'] as $postId => $post): 
          if(!empty($post['slug']) && isset($post['visible']) && $post['visible'] == true): 
          $postLastmod = !empty($post['date']) ? $post['date'] : date('Y-m-d');
    ?>
    <url>
        <loc><?php echo $baseUrl; ?>/blog/<?php echo urlencode($post['slug']); ?></loc>
        <lastmod><?php echo $postLastmod; ?></lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.7</priority>
    </url>
    <?php endif; endforeach; endif; ?>
    
    <!-- Static pages -->
    <?php if(!empty($pages)): foreach($pages as $pageId => $page): 
          if(!empty($page['slug'])): 
    ?>
    <url>
        <loc><?php echo $baseUrl; ?>/page.php?slug=<?php echo urlencode($page['slug']); ?></loc>
        <lastmod><?php echo date('Y-m-d'); ?></lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.6</priority>
    </url>
    <?php endif; endforeach; endif; ?>
    
</urlset>
