<?php
/**
 * Pinterest Video API Handler
 * Unified handler for Pinterest video data extraction
 * Supports multiple API providers and fallback mechanisms
 */

namespace PinSave\Api;

// Include configuration file
require_once __DIR__ . '/../config.php';

class PinterestApiHandler {
    private $config;
    private $debugMode;
    private $apiKey;
    private $provider;

    public function __construct() {
        $this->config = $GLOBALS['adminConfig'] ?? [];
        
        // Use environment variables if defined, otherwise fall back to admin config
        $this->debugMode = defined('DEBUG_MODE') ? DEBUG_MODE : ($this->config['api']['debug_mode'] ?? false);
        $this->apiKey = defined('PINTEREST_API_KEY') ? PINTEREST_API_KEY : ($this->config['api']['rapidapi_key'] ?? '');
        $this->provider = defined('PINTEREST_API_HOST') ? PINTEREST_API_HOST : ($this->config['api']['api_provider'] ?? 'pinterest-video-downloader1');
    }

    /**
     * Main function to get Pinterest video data
     * @param string $url Pinterest video URL
     * @return array Result with success status and video URL or error message
     */
    public function getVideoData($url) {
        if (empty($this->apiKey)) {
            return [
                'success' => false,
                'message' => 'RapidAPI key is not configured. Please set your API key in the admin panel.'
            ];
        }

        $debug = [
            'api_provider' => $this->provider,
            'debug_mode' => $this->debugMode ? 'Enabled' : 'Disabled',
            'timestamp' => date('Y-m-d H:i:s'),
            'url' => $url
        ];
        
        // Handle pin.it short URLs
        if (strpos($url, 'pin.it/') !== false) {
            $url = $this->expandShortUrl($url);
            $debug['expanded_url'] = $url;
        }

        // Try direct extraction first (most reliable for recent Pinterest changes)
        $result = $this->extractVideoDirectly($url);
        if ($result['success']) {
            return $this->debugMode ? array_merge($result, ['debug' => $debug]) : $result;
        }
        
        // Try Pinterest's internal API next
        $pinId = $this->extractPinId($url);
        if (!empty($pinId)) {
            $result = $this->callPinterestInternalApi($pinId);
            if ($result['success']) {
                return $this->debugMode ? array_merge($result, ['debug' => $debug]) : $result;
            }
            if ($this->debugMode) {
                $debug['internal_api_error'] = $result['message'] ?? 'Unknown error';
            }
        }

        // Try configured API provider as last resort
        $result = $this->callProviderApi($url);

        return $this->debugMode ? array_merge($result, ['debug' => $debug]) : $result;
    }

    /**
     * Call the configured API provider
     * @param string $url Pinterest video URL
     * @return array Result with success status and video URL or error message
     */
    private function callProviderApi($url) {
        $curl = curl_init();
        $headers = [
            "X-RapidAPI-Key: {$this->apiKey}",
            "Content-Type: application/json"
        ];

        switch ($this->provider) {
            case 'pinterest-video-downloader1':
                curl_setopt_array($curl, [
                    CURLOPT_URL => "https://pinterest-video-and-image-downloader.p.rapidapi.com/pinterest",
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => json_encode(['url' => $url]),
                    CURLOPT_HTTPHEADER => array_merge($headers, [
                        "X-RapidAPI-Host: pinterest-video-and-image-downloader.p.rapidapi.com"
                    ])
                ]);
                break;

            case 'social-media-downloader':
                curl_setopt_array($curl, [
                    CURLOPT_URL => "https://social-media-video-downloader.p.rapidapi.com/pinterest?url=" . urlencode($url),
                    CURLOPT_CUSTOMREQUEST => "GET",
                    CURLOPT_HTTPHEADER => array_merge($headers, [
                        "X-RapidAPI-Host: social-media-video-downloader.p.rapidapi.com"
                    ])
                ]);
                break;

            default:
                return [
                    'success' => false,
                    'message' => 'Invalid API provider configured'
                ];
        }

        curl_setopt_array($curl, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            return [
                'success' => false,
                'message' => "cURL Error: " . $err
            ];
        }

        $result = json_decode($response, true);

        // Handle different API response formats
        if ($this->provider === 'pinterest-video-downloader1') {
            if (isset($result['status']) && $result['status'] === 'success' && isset($result['data']['videos'][0]['url'])) {
                return [
                    'success' => true,
                    'video_url' => $result['data']['videos'][0]['url'],
                    'thumbnail' => $result['data']['thumbnail'] ?? '',
                    'title' => $result['data']['title'] ?? 'Pinterest Video',
                    'extraction_method' => 'rapidapi_provider1'
                ];
            }
        } else if ($this->provider === 'social-media-downloader') {
            if (isset($result['video_url'])) {
                return [
                    'success' => true,
                    'video_url' => $result['video_url'],
                    'thumbnail' => $result['thumbnail'] ?? '',
                    'title' => $result['title'] ?? 'Pinterest Video',
                    'extraction_method' => 'rapidapi_provider2'
                ];
            }
        }

        return [
            'success' => false,
            'message' => 'Could not extract video URL from Pinterest link',
            'debug' => $this->debugMode ? $result : null
        ];
    }

    /**
     * Call Pinterest's internal API
     * @param string $pinId Pinterest pin ID
     * @return array Result with success status and video URL or error message
     */
    private function callPinterestInternalApi($pinId) {
        // Try both the standard URL and the API URL
        $urls = [
            "https://www.pinterest.com/pin/{$pinId}/",
            "https://www.pinterest.com/_ngjs/resource/PinResource/get/?source_url=%2Fpin%2F{$pinId}%2F&data=%7B%22options%22%3A%7B%22id%22%3A%22{$pinId}%22%2C%22field_set_key%22%3A%22detailed%22%7D%2C%22context%22%3A%7B%7D%7D"
        ];
        
        foreach ($urls as $url) {
            
            // Try using cURL first (more reliable than file_get_contents)
            if (function_exists('curl_init')) {
                $ch = curl_init();
                curl_setopt_array($ch, [
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36'
                ]);
                $response = curl_exec($ch);
                $error = curl_error($ch);
                curl_close($ch);
                
                if ($response === false) {
                    return [
                        'success' => false,
                        'message' => 'Failed to fetch Pinterest page: ' . $error
                    ];
                }
            } else {
                // Fallback to file_get_contents if cURL is not available
                $options = [
                    'http' => [
                        'method' => 'GET',
                        'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36\r\n",
                        'timeout' => 30
                    ]
                ];

                $context = stream_context_create($options);
                $response = @file_get_contents($url, false, $context);

                if ($response === false) {
                    return [
                        'success' => false,
                        'message' => 'Failed to fetch Pinterest page. Check your internet connection or Pinterest might be blocking requests.'
                    ];
                }
            }
            
            // Parse the response data
            $result = json_decode($response, true);

            // Handle different API response formats
            if ($this->provider === 'pinterest-video-downloader1') {
                if (isset($result['status']) && $result['status'] === 'success' && isset($result['data']['videos'][0]['url'])) {
                    return [
                        'success' => true,
                        'video_url' => $result['data']['videos'][0]['url'],
                        'thumbnail' => $result['data']['thumbnail'] ?? '',
                        'title' => $result['data']['title'] ?? 'Pinterest Video',
                        'extraction_method' => 'rapidapi_provider1'
                    ];
                }
            } else if ($this->provider === 'social-media-downloader') {
                if (isset($result['video_url'])) {
                    return [
                        'success' => true,
                        'video_url' => $result['video_url'],
                        'thumbnail' => $result['thumbnail'] ?? '',
                        'title' => $result['title'] ?? 'Pinterest Video',
                        'extraction_method' => 'rapidapi_provider2'
                    ];
                }
            }

        }
        
        return [
            'success' => false,
            'message' => 'Could not extract video URL from Pinterest link',
            'debug' => $this->debugMode ? $result : null
        ];
    }
    
    /**
     * Extract video URL directly from page HTML
     * @param string $url Pinterest URL
     * @return array Result with success status and video URL or error message
     */
    private function extractVideoDirectly($url) {
        // Ensure we're using www.pinterest.com for consistency
        $url = str_replace(['https://in.pinterest.com', 'http://in.pinterest.com', 'https://pinterest.com', 'http://pinterest.com'], 'https://www.pinterest.com', $url);
        
        $response = '';
        
        // Try using cURL first (more reliable than file_get_contents)
        if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            CURLOPT_HTTPHEADER => [
                'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                'Accept-Language: en-US,en;q=0.9',
                'Cache-Control: max-age=0',
                'Connection: keep-alive',
                'Sec-Fetch-Dest: document',
                'Sec-Fetch-Mode: navigate',
                'Sec-Fetch-Site: none',
                'Sec-Fetch-User: ?1',
                'Upgrade-Insecure-Requests: 1'
            ]
        ]);
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($response === false) {
            return [
                'success' => false,
                'message' => 'Failed to fetch Pinterest page: ' . $error
            ];
        }
        
        if ($httpCode >= 400) {
            return [
                'success' => false,
                'message' => 'Pinterest returned error code: ' . $httpCode
            ];
        }
    } else {
        // Fallback to file_get_contents if cURL is not available
        $options = [
            'http' => [
                'method' => 'GET',
                'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36\r\n",
                'timeout' => 30
            ]
        ];

        $context = stream_context_create($options);
        $response = @file_get_contents($url, false, $context);

        if ($response === false) {
            return [
                'success' => false,
                'message' => 'Failed to fetch Pinterest page. Check your internet connection or Pinterest might be blocking requests.'
            ];
        }
    }

    // Try different patterns to find video URL
    $patterns = [
        // Standard patterns
        '/\{"contentUrl":\s*"([^"]+)"/',
        '/\{"video_url":\s*"([^"]+)"/',
        '/\<meta\s+property="og:video"\s+content="([^"]+)"/',
        '/\<meta\s+property="og:video:url"\s+content="([^"]+)"/',
        '/"url":"([^"]+\.mp4[^"]*)"/i',
        '/"url":"([^"]+\.m3u8[^"]*)"/i',
        
        // Newer Pinterest formats
        '/"video_list":\{"V_[^"]+":\{"url":"([^"]+)"/',
        '/"videos":\{"video_list":\{"V_[^"]+":\{"url":"([^"]+)"/',
        '/"video":\{"video_list":\{"V_[^"]+":\{"url":"([^"]+)"/',
        '/"videoUrl":"([^"]+)"/',
        '/data-video-id="[^"]+" href="([^"]+\.mp4[^"]*)"/i',
        
        // Latest Pinterest formats
        '/"media":\{"type":"video","id":"[^"]+","url":"([^"]+)"/',
        '/"video_list":\{"[^"]+":\{"url":"([^"]+)"/',
        '/"video":\{"[^"]+":\{"url":"([^"]+)"/',
        '/"videos":\{"[^"]+":\{"url":"([^"]+)"/',
        '/"playbackUrl":"([^"]+)"/',
        '/"source_url":"([^"]+\.mp4[^"]*)"/i',
        '/"streaming_url":"([^"]+)"/',
        '/"v_hd":"([^"]+)"/',
        '/"v_sd":"([^"]+)"/',
        '/"video_src":"([^"]+)"/',
        '/"video_data":\{"url":"([^"]+)"/',
        '/"media":\{"video":\{"url":"([^"]+)"/',
        '/"data-pin-media":"([^"]+\.mp4[^"]*)"/i'
    ];
    
    // Also try to find video data in a structured way using json_decode
    if (preg_match('/\<script[^>]*id="__PWS_DATA__"[^>]*>([^<]+)<\/script>/i', $response, $matches)) {
        $jsonData = json_decode(html_entity_decode($matches[1]), true);
        if (is_array($jsonData)) {
            // Navigate through the JSON structure to find video URLs
            if (isset($jsonData['props']['initialReduxState']['pins'])) {
                foreach ($jsonData['props']['initialReduxState']['pins'] as $pinId => $pinData) {
                    if (isset($pinData['videos']['video_list'])) {
                        foreach ($pinData['videos']['video_list'] as $videoData) {
                            if (isset($videoData['url'])) {
                                return [
                                    'success' => true,
                                    'video_url' => $videoData['url'],
                                    'thumbnail' => $pinData['images']['orig']['url'] ?? '',
                                    'title' => $pinData['title'] ?? 'Pinterest Video',
                                    'extraction_method' => 'json_structure'
                                ];
                            }
                        }
                    }
                }
            }
        }
    }

    // Try the newer JSON-LD format
    if (preg_match('/\<script\s+type="application\/ld\+json"\s*>([^<]+)<\/script>/i', $response, $matches)) {
        $jsonData = json_decode(html_entity_decode($matches[1]), true);
        if (is_array($jsonData) && isset($jsonData['video'])) {
            if (isset($jsonData['video']['contentUrl'])) {
                return [
                    'success' => true,
                    'video_url' => $jsonData['video']['contentUrl'],
                    'thumbnail' => $jsonData['video']['thumbnailUrl'] ?? '',
                    'title' => $jsonData['video']['name'] ?? 'Pinterest Video',
                    'extraction_method' => 'json_ld_format'
                ];
            }
        }
    }

    // Try the initial state format
    if (preg_match('/window\.__INITIAL_STATE__\s*=\s*(\{.+?\});/s', $response, $matches)) {
        $jsonData = json_decode($matches[1], true);
        if (is_array($jsonData) && isset($jsonData['resources']['data']['PinResource'])) {
            foreach ($jsonData['resources']['data']['PinResource'] as $pinData) {
                if (isset($pinData['data']['videos']['video_list'])) {
                    foreach ($pinData['data']['videos']['video_list'] as $videoData) {
                        if (isset($videoData['url'])) {
                            return [
                                'success' => true,
                                'video_url' => $videoData['url'],
                                'thumbnail' => $pinData['data']['images']['orig']['url'] ?? '',
                                'title' => $pinData['data']['title'] ?? 'Pinterest Video',
                                'extraction_method' => 'initial_state_format'
                            ];
                        }
                    }
                }
            }
        }
    }

    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $response, $matches)) {
            $videoUrl = str_replace('\/', '/', $matches[1]);
            
            // Skip VTT subtitle files
            if (stripos($videoUrl, '.vtt') !== false) {
                continue;
            }
            
            // Make sure we're getting a video file
            if (stripos($videoUrl, '.mp4') !== false || 
                stripos($videoUrl, '.m3u8') !== false || 
                stripos($videoUrl, 'video') !== false) {
                
                return [
                    'success' => true,
                    'video_url' => $videoUrl,
                    'thumbnail' => '',
                    'title' => 'Pinterest Video',
                    'extraction_method' => 'direct_html'
                ];
            }
        }
    }
    
    // For debugging purposes, save a snippet of the response
    $responseSnippet = substr($response, 0, 500) . '...' . substr($response, -500);
    
    return [
        'success' => false,
        'message' => 'Could not extract video URL directly from Pinterest page',
        'debug_info' => [
            'url' => $url,
            'response_length' => strlen($response),
            'response_snippet' => $responseSnippet,
            'patterns_tried' => count($patterns)
        ]
    ];
}

/**
 * Extract Pinterest pin ID from URL
 * @param string $url Pinterest URL
 * @return string Pin ID or empty string if not found
 */
    private function extractPinId($url) {
        // Handle pin.it short URLs
        if (strpos($url, 'pin.it/') !== false) {
            $url = $this->expandShortUrl($url);
        }

        // Extract pin ID from URL - multiple formats
        $patterns = [
            // Standard format
            '/\/pin\/(\d+)/',
            // International domains
            '/pinterest\.[a-z]+\/pin\/(\d+)/',
            // Country-specific subdomains
            '/[a-z]+\.pinterest\.[a-z]+\/pin\/(\d+)/',
            // Mobile format
            '/pinterest\.[a-z]+\/[a-z]+\/pin\/(\d+)/',
            // Alternate format with username
            '/pinterest\.[a-z]+\/[^/]+\/[^/]+\/(\d+)/',
            // Direct pin ID in query string
            '/[?&]pinid=(\d+)/',
            // ID at the end of URL
            '/(\d{17,19})(?:\/|$)/' // Pinterest IDs are typically 17-19 digits
        ];
        
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $url, $matches)) {
                return $matches[1];
            }
        }

        if ($this->debugMode) {
            error_log("Failed to extract pin ID from URL: {$url}");
        }

        return '';
    }

    /**
     * Expand a Pinterest short URL
     * @param string $shortUrl Short Pinterest URL
     * @return string Full URL or original URL if expansion fails
     */
    private function expandShortUrl($shortUrl) {
        // Clean up the URL first
        $shortUrl = trim($shortUrl);
        if (!preg_match('/^https?:\/\//i', $shortUrl)) {
            $shortUrl = 'https://' . $shortUrl;
        }
        
        if (function_exists('curl_init')) {
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $shortUrl,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HEADER => true,
                CURLOPT_NOBODY => true,
                CURLOPT_TIMEOUT => 15,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
                CURLOPT_HTTPHEADER => [
                    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                    'Accept-Language: en-US,en;q=0.9',
                    'Cache-Control: no-cache'
                ]
            ]);
            
            curl_exec($ch);
            $url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            // Only return the expanded URL if we got a successful response
            if ($httpCode >= 200 && $httpCode < 300 && !empty($url)) {
                return $url;
            }
            
            if ($this->debugMode) {
                error_log("Failed to expand short URL: {$shortUrl}, HTTP code: {$httpCode}");
            }
        } else {
            // Fallback if curl is not available
            $context = stream_context_create([
                'http' => [
                    'method' => 'HEAD',
                    'follow_location' => 1,
                    'max_redirects' => 10,
                    'timeout' => 15,
                    'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36\r\n"
                ]
            ]);
            
            $headers = @get_headers($shortUrl, 1, $context);
            if ($headers && isset($headers['Location'])) {
                return is_array($headers['Location']) ? end($headers['Location']) : $headers['Location'];
            }
        }
        
        return $shortUrl;
    }
}
