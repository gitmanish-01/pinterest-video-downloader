<?php
/**
 * Pinterest Video API Handler
 * Uses RapidAPI to fetch Pinterest video data
 */

// Include configuration file
require_once __DIR__ . '/../config.php';

function getPinterestVideoData($url) {
    // Get RapidAPI key from configuration
    $rapidApiKey = RAPIDAPI_KEY;
    
    // Check if API key is set
    if (empty($rapidApiKey)) {
        return [
            'success' => false,
            'message' => 'RapidAPI key is not configured. Please set your API key in the config.php file.'
        ];
    }
    
    // Determine which API provider to use based on config
    $apiProvider = defined('API_PROVIDER') ? API_PROVIDER : 'pinterest-video-and-image-downloader';
    
    if ($apiProvider === 'social-media-video-downloader') {
        return getPinterestVideoDataAlternative($url, $rapidApiKey);
    }
    
    // Default API provider: pinterest-video-and-image-downloader
    // Prepare the API request
    $curl = curl_init();
    
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://pinterest-video-and-image-downloader.p.rapidapi.com/pinterest",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => json_encode([
            'url' => $url
        ]),
        CURLOPT_HTTPHEADER => [
            "X-RapidAPI-Host: pinterest-video-and-image-downloader.p.rapidapi.com",
            "X-RapidAPI-Key: " . $rapidApiKey,
            "Content-Type: application/json"
        ],
    ]);
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
        return [
            'success' => false,
            'message' => "cURL Error: " . $err
        ];
    }
    
    // Parse the response
    $result = json_decode($response, true);
    
    // Check if we got a valid response with video URL
    if (isset($result['status']) && $result['status'] === 'success' && isset($result['data']['videos'][0]['url'])) {
        return [
            'success' => true,
            'video_url' => $result['data']['videos'][0]['url'],
            'thumbnail' => $result['data']['thumbnail'] ?? '',
            'title' => $result['data']['title'] ?? 'Pinterest Video'
        ];
    }
    
    // If we reach here, something went wrong with the API response
    return [
        'success' => false,
        'message' => 'Could not extract video URL from Pinterest link. Please check if the URL is correct and contains a video.',
        'debug' => defined('DEBUG_MODE') && DEBUG_MODE ? $result : null
    ];
}

/**
 * Alternative function to use a different RapidAPI endpoint
 */
function getPinterestVideoDataAlternative($url, $rapidApiKey = null) {
    // Get RapidAPI key from configuration if not provided
    if ($rapidApiKey === null) {
        $rapidApiKey = RAPIDAPI_KEY;
    }
    
    // Check if API key is set
    if (empty($rapidApiKey)) {
        return [
            'success' => false,
            'message' => 'RapidAPI key is not configured. Please set your API key in the config.php file.'
        ];
    }
    
    // Prepare the API request
    $curl = curl_init();
    
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://social-media-video-downloader.p.rapidapi.com/pinterest?url=" . urlencode($url),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => [
            "X-RapidAPI-Host: social-media-video-downloader.p.rapidapi.com",
            "X-RapidAPI-Key: " . $rapidApiKey
        ],
    ]);
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
        return [
            'success' => false,
            'message' => "cURL Error: " . $err
        ];
    }
    
    // Parse the response
    $result = json_decode($response, true);
    
    // Check if we got a valid response with video URL
    if (isset($result['video_url'])) {
        return [
            'success' => true,
            'video_url' => $result['video_url'],
            'thumbnail' => $result['thumbnail'] ?? '',
            'title' => $result['title'] ?? 'Pinterest Video'
        ];
    }
    
    // If we reach here, something went wrong with the API response
    return [
        'success' => false,
        'message' => 'Could not extract video URL from Pinterest link. Please check if the URL is correct and contains a video.',
        'debug' => defined('DEBUG_MODE') && DEBUG_MODE ? $result : null
    ];
}
?>
