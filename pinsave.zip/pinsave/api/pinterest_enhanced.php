<?php
/**
 * Enhanced Pinterest Video Extractor
 * Specifically for international Pinterest domains
 */

// Include main Pinterest API file
require_once __DIR__ . '/pinterest_api.php';

/**
 * Enhanced extraction for international Pinterest URLs
 * @param string $url Pinterest URL
 * @return array Result with success status and video URL or error message
 */
function extractInternationalPinterestVideo($url) {
    error_log("Attempting enhanced extraction for international Pinterest URL: " . $url);
    
    // Use a modern browser user agent
    $userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36';
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT => $userAgent,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTPHEADER => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language: en-US,en;q=0.5',
            'Connection: keep-alive',
            'Upgrade-Insecure-Requests: 1'
        ],
        CURLOPT_ENCODING => 'gzip, deflate',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false
    ]);
    
    $html = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);
    
    if ($err) {
        error_log("cURL error during enhanced extraction: " . $err);
        return [
            'success' => false,
            'message' => "Error fetching Pinterest page: " . $err
        ];
    }
    
    if (empty($html)) {
        error_log("Empty response from Pinterest page");
        return [
            'success' => false,
            'message' => 'Empty response from Pinterest page'
        ];
    }
    
    // Save the HTML for debugging
    $debugFile = __DIR__ . '/pinterest_debug.html';
    file_put_contents($debugFile, $html);
    error_log("Saved Pinterest HTML response to: " . $debugFile);
    
    // Try to extract video URL from the HTML
    $videoUrl = extractVideoUrlFromHtml($html);
    
    if ($videoUrl) {
        error_log("Successfully extracted video URL: " . $videoUrl);
        return [
            'success' => true,
            'video_url' => $videoUrl,
            'title' => 'Pinterest Video',
            'extraction_method' => 'enhanced_international'
        ];
    }
    
    return [
        'success' => false,
        'message' => 'Could not extract video URL from international Pinterest page'
    ];
}

/**
 * Extract video URL from HTML content
 * @param string $html HTML content
 * @return string|false Video URL or false if not found
 */
function extractVideoUrlFromHtml($html) {
    // Method 1: Extract from JSON-LD data
    if (preg_match('/<script type="application\/ld\\+json">(.*?)<\/script>/s', $html, $matches)) {
        $jsonData = json_decode($matches[1], true);
        if ($jsonData && isset($jsonData['video']) && isset($jsonData['video']['contentUrl'])) {
            return $jsonData['video']['contentUrl'];
        }
    }
    
    // Method 2: Look for video URL in various formats
    $patterns = [
        // Standard patterns
        '/"video":\s*{[^}]*"url":\s*"([^"]+)"/',
        '/"video_url":\s*"([^"]+)"/',
        '/"contentUrl":\s*"([^"]+\.mp4[^"]*)"/i',
        '/\.mp4\\":\{\\"url\\":\\"([^\\]+)\\"/',
        '/"url":\s*"([^"]+\.mp4[^"]*)"/i',
        
        // International Pinterest patterns
        '/"playEligibleVideo":\s*{[^}]*"url":\s*"([^"]+)"/',
        '/"playEligibleVideo":\s*{[^}]*"fallback_url":\s*"([^"]+)"/',
        '/"v_720p":\s*{[^}]*"url":\s*"([^"]+)"/',
        '/"v_480p":\s*{[^}]*"url":\s*"([^"]+)"/',
        '/"contentUrl":\s*"(https:\/\/[^"]+\.mp4[^"]*)"/',
        '/"video":\{[^}]*"id":"[^"]+","duration":[^,]+,"image_signature":"[^"]+","url":"([^"]+)"/'
    ];
    
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $html, $matches)) {
            $videoUrl = str_replace('\/', '/', $matches[1]);
            error_log("Found video URL using pattern: " . $pattern);
            return $videoUrl;
        }
    }
    
    // Method 3: Look for video tags
    if (preg_match('/<video[^>]*src="([^"]+)"/', $html, $matches)) {
        return $matches[1];
    }
    
    // Method 4: Look for initial state data
    if (preg_match('/window\.__INITIAL_STATE__\s*=\s*(\{.*?\});<\/script>/s', $html, $matches)) {
        $initialState = json_decode($matches[1], true);
        
        // Navigate through the structure to find video URL
        if ($initialState && isset($initialState['resourceResponses'])) {
            foreach ($initialState['resourceResponses'] as $response) {
                if (isset($response['response']['data']['videos']['video_list'])) {
                    $videoList = $response['response']['data']['videos']['video_list'];
                    // Get the highest quality video
                    foreach (['V_720P', 'V_480P', 'V_HLSV4', 'V_HLSV3_WEB', 'V_HLSV3_MOBILE'] as $quality) {
                        if (isset($videoList[$quality]['url'])) {
                            return $videoList[$quality]['url'];
                        }
                    }
                    
                    // If standard qualities not found, try the first available
                    $qualities = array_keys($videoList);
                    if (!empty($qualities) && isset($videoList[$qualities[0]]['url'])) {
                        return $videoList[$qualities[0]]['url'];
                    }
                }
            }
        }
    }
    
    return false;
}
