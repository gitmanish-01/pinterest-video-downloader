<?php
/**
 * Direct Pinterest Video Downloader
 * This file provides a direct method to download Pinterest videos without relying on RapidAPI
 */

/**
 * Get Pinterest video data directly without using RapidAPI
 * @param string $url Pinterest video URL
 * @return array Result with success status and video URL or error message
 */
function getPinterestVideoDirectly($url) {
    error_log("Starting direct Pinterest video extraction for: " . $url);
    
    // Step 1: Clean and validate the URL
    $url = trim($url);
    if (empty($url)) {
        return [
            'success' => false,
            'message' => 'Please provide a Pinterest URL'
        ];
    }
    
    // Step 2: Expand short URLs if needed
    if (strpos($url, 'pin.it') !== false) {
        $expandedUrl = expandPinterestShortUrl($url);
        if (!empty($expandedUrl)) {
            $url = $expandedUrl;
            error_log("Expanded short URL to: " . $url);
        }
    }
    
    // Step 3: Extract the pin ID
    $pinId = extractPinId($url);
    if (empty($pinId)) {
        error_log("Failed to extract pin ID from URL: " . $url);
        return [
            'success' => false,
            'message' => 'Invalid Pinterest URL. Could not extract pin ID.'
        ];
    }
    
    error_log("Extracted pin ID: " . $pinId);
    
    // Step 4: Try multiple methods to extract the video
    
    // Method 1: Try direct page scraping
    $result = scrapeVideoFromPinterestPage($url);
    if ($result['success']) {
        return $result;
    }
    
    // Method 2: Try Pinterest API
    $result = getPinterestVideoFromApi($pinId);
    if ($result['success']) {
        return $result;
    }
    
    // Method 3: Try international Pinterest domains
    if (strpos($url, '.pinterest.com') !== false && !strpos($url, 'www.pinterest.com')) {
        // Try with www.pinterest.com instead
        $wwwUrl = str_replace(parse_url($url, PHP_URL_HOST), 'www.pinterest.com', $url);
        error_log("Trying with www.pinterest.com: " . $wwwUrl);
        
        $result = scrapeVideoFromPinterestPage($wwwUrl);
        if ($result['success']) {
            return $result;
        }
    }
    
    // All methods failed
    return [
        'success' => false,
        'message' => 'Could not extract video from Pinterest URL. Please make sure the URL contains a video.',
        'debug' => [
            'url' => $url,
            'pin_id' => $pinId
        ]
    ];
}

/**
 * Expand a Pinterest short URL
 * @param string $shortUrl Pinterest short URL
 * @return string Full URL or empty string on failure
 */
function expandPinterestShortUrl($shortUrl) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $shortUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => true,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_NOBODY => true,
        CURLOPT_TIMEOUT => 10
    ]);
    
    curl_exec($ch);
    $redirectUrl = curl_getinfo($ch, CURLINFO_REDIRECT_URL);
    curl_close($ch);
    
    return $redirectUrl ?: '';
}

/**
 * Extract pin ID from Pinterest URL
 * @param string $url Pinterest URL
 * @return string Pin ID or empty string if not found
 */
function extractPinId($url) {
    // Handle various Pinterest URL formats
    $patterns = [
        // Standard formats
        '/\/pin\/(\d+)/',
        '/pinterest\.com\/pin\/(\d+)/',
        '/[a-z]{2}\.pinterest\.com\/pin\/(\d+)/',
        
        // New formats with alphanumeric IDs
        '/\/pin\/([a-zA-Z0-9_-]+)/',
        '/pinterest\.com\/pin\/([a-zA-Z0-9_-]+)/',
        '/[a-z]{2}\.pinterest\.com\/pin\/([a-zA-Z0-9_-]+)/',
        
        // User profile pins
        '/pinterest\.com\/.*?\/pin\/(\d+)/',
        '/pinterest\.com\/.*?\/pin\/([a-zA-Z0-9_-]+)/',
        '/[a-z]{2}\.pinterest\.com\/.*?\/pin\/(\d+)/',
        '/[a-z]{2}\.pinterest\.com\/.*?\/pin\/([a-zA-Z0-9_-]+)/'
    ];
    
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $url, $matches)) {
            return $matches[1];
        }
    }
    
    // Check for pin ID in query string
    $parsedUrl = parse_url($url);
    if (isset($parsedUrl['query'])) {
        parse_str($parsedUrl['query'], $params);
        if (isset($params['pin_id'])) {
            return $params['pin_id'];
        }
    }
    
    return '';
}

/**
 * Scrape video URL directly from Pinterest page
 * @param string $url Pinterest URL
 * @return array Result with success status and video URL or error message
 */
function scrapeVideoFromPinterestPage($url) {
    error_log("Scraping video from Pinterest page: " . $url);
    
    // Set up a request with browser-like headers
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTPHEADER => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language: en-US,en;q=0.5',
            'Cache-Control: no-cache',
            'Pragma: no-cache'
        ],
        CURLOPT_ENCODING => 'gzip, deflate'
    ]);
    
    $html = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);
    
    if ($err) {
        error_log("cURL error: " . $err);
        return [
            'success' => false,
            'message' => "Error fetching Pinterest page: " . $err
        ];
    }
    
    if (empty($html)) {
        error_log("Empty response from Pinterest");
        return [
            'success' => false,
            'message' => "Empty response from Pinterest"
        ];
    }
    
    // Save HTML for debugging
    $debugFile = __DIR__ . '/pinterest_debug.html';
    file_put_contents($debugFile, $html);
    error_log("Saved Pinterest HTML to: " . $debugFile);
    
    // Method 1: Extract from JSON-LD data
    if (preg_match('/<script type="application\/ld\+json">(.*?)<\/script>/s', $html, $matches)) {
        $jsonData = json_decode($matches[1], true);
        if ($jsonData && isset($jsonData['video']) && isset($jsonData['video']['contentUrl'])) {
            $videoUrl = $jsonData['video']['contentUrl'];
            error_log("Found video URL in JSON-LD: " . $videoUrl);
            return [
                'success' => true,
                'video_url' => $videoUrl,
                'thumbnail' => $jsonData['image'] ?? '',
                'title' => $jsonData['name'] ?? 'Pinterest Video',
                'extraction_method' => 'json_ld'
            ];
        }
    }
    
    // Method 2: Extract from initial state data
    if (preg_match('/window\.__INITIAL_STATE__\s*=\s*(\{.*?\});<\/script>/s', $html, $matches)) {
        $initialState = json_decode($matches[1], true);
        
        // Navigate through the structure to find video URL
        if ($initialState && isset($initialState['resourceResponses'])) {
            foreach ($initialState['resourceResponses'] as $response) {
                if (isset($response['response']['data']['videos']['video_list'])) {
                    $videoList = $response['response']['data']['videos']['video_list'];
                    
                    // Get the highest quality video
                    foreach (['V_720P', 'V_480P', 'V_HLSV4', 'V_HLSV3_WEB', 'V_HLSV3_MOBILE'] as $quality) {
                        if (isset($videoList[$quality]['url'])) {
                            $videoUrl = $videoList[$quality]['url'];
                            error_log("Found video URL in initial state: " . $videoUrl);
                            return [
                                'success' => true,
                                'video_url' => $videoUrl,
                                'thumbnail' => $response['response']['data']['images']['orig']['url'] ?? '',
                                'title' => $response['response']['data']['title'] ?? 'Pinterest Video',
                                'extraction_method' => 'initial_state'
                            ];
                        }
                    }
                    
                    // If standard qualities not found, try the first available
                    $qualities = array_keys($videoList);
                    if (!empty($qualities)) {
                        $videoUrl = $videoList[$qualities[0]]['url'];
                        error_log("Found video URL using first available quality: " . $videoUrl);
                        return [
                            'success' => true,
                            'video_url' => $videoUrl,
                            'thumbnail' => $response['response']['data']['images']['orig']['url'] ?? '',
                            'title' => $response['response']['data']['title'] ?? 'Pinterest Video',
                            'extraction_method' => 'initial_state_fallback'
                        ];
                    }
                }
            }
        }
    }
    
    // Method 3: Look for video URL in various patterns
    $patterns = [
        '/"video":\s*{[^}]*"url":\s*"([^"]+)"/',
        '/"video_url":\s*"([^"]+)"/',
        '/"contentUrl":\s*"([^"]+\.mp4[^"]*)"/i',
        '/\.mp4\\":\{\\"url\\":\\"([^\\]+)\\"/',
        '/"url":\s*"([^"]+\.mp4[^"]*)"/i',
        '/"playEligibleVideo":\s*{[^}]*"url":\s*"([^"]+)"/',
        '/"v_720p":\s*{[^}]*"url":\s*"([^"]+)"/',
        '/"v_480p":\s*{[^}]*"url":\s*"([^"]+)"/',
        '/"contentUrl":\s*"(https:\/\/[^"]+\.mp4[^"]*)"/',
        '/"video":\{[^}]*"id":"[^"]+","duration":[^,]+,"image_signature":"[^"]+","url":"([^"]+)"/'
    ];
    
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $html, $matches)) {
            $videoUrl = str_replace('\/', '/', $matches[1]);
            error_log("Found video URL using pattern: " . $videoUrl);
            return [
                'success' => true,
                'video_url' => $videoUrl,
                'title' => 'Pinterest Video',
                'extraction_method' => 'regex_pattern'
            ];
        }
    }
    
    // Method 4: Look for video tags
    if (preg_match('/<video[^>]*src="([^"]+)"/', $html, $matches)) {
        $videoUrl = $matches[1];
        error_log("Found video URL in video tag: " . $videoUrl);
        return [
            'success' => true,
            'video_url' => $videoUrl,
            'title' => 'Pinterest Video',
            'extraction_method' => 'video_tag'
        ];
    }
    
    return [
        'success' => false,
        'message' => 'Could not find video URL in Pinterest page'
    ];
}

/**
 * Get Pinterest video using their internal API
 * @param string $pinId Pinterest pin ID
 * @return array Result with success status and video URL or error message
 */
function getPinterestVideoFromApi($pinId) {
    error_log("Getting video from Pinterest API for pin ID: " . $pinId);
    
    // Try both www.pinterest.com and in.pinterest.com domains
    $domains = ['www.pinterest.com', 'in.pinterest.com'];
    
    foreach ($domains as $domain) {
        $apiUrl = "https://{$domain}/resource/PinResource/get/";
        $data = [
            "options" => [
                "id" => $pinId,
                "field_set_key" => "detailed"
            ],
            "context" => []
        ];
        
        $queryParams = [
            "source_url" => "/pin/{$pinId}/",
            "data" => json_encode($data)
        ];
        
        $fullUrl = $apiUrl . '?' . http_build_query($queryParams);
        
        error_log("Calling Pinterest API: " . $fullUrl);
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $fullUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json, text/javascript, */*; q=0.01',
                'Accept-Language: en-US,en;q=0.5',
                'X-Requested-With: XMLHttpRequest',
                'X-APP-VERSION: 9e3f4ae',
                'Referer: https://' . $domain . '/'
            ]
        ]);
        
        $response = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        
        if ($err) {
            error_log("cURL error: " . $err);
            continue;
        }
        
        // Parse the response
        $result = json_decode($response, true);
        
        // Check for video data
        if (isset($result['resource_response']['data']['videos']['video_list'])) {
            $videoList = $result['resource_response']['data']['videos']['video_list'];
            
            // Get the highest quality video
            foreach (['V_720P', 'V_480P', 'V_HLSV4', 'V_HLSV3_WEB', 'V_HLSV3_MOBILE'] as $quality) {
                if (isset($videoList[$quality]['url'])) {
                    $videoUrl = $videoList[$quality]['url'];
                    $thumbnail = $result['resource_response']['data']['images']['orig']['url'] ?? '';
                    $title = $result['resource_response']['data']['title'] ?? 'Pinterest Video';
                    
                    error_log("Found video URL in Pinterest API: " . $videoUrl);
                    return [
                        'success' => true,
                        'video_url' => $videoUrl,
                        'thumbnail' => $thumbnail,
                        'title' => $title,
                        'extraction_method' => 'pinterest_api'
                    ];
                }
            }
            
            // If standard qualities not found, try the first available
            $qualities = array_keys($videoList);
            if (!empty($qualities)) {
                $videoUrl = $videoList[$qualities[0]]['url'];
                $thumbnail = $result['resource_response']['data']['images']['orig']['url'] ?? '';
                $title = $result['resource_response']['data']['title'] ?? 'Pinterest Video';
                
                error_log("Found video URL using first available quality: " . $videoUrl);
                return [
                    'success' => true,
                    'video_url' => $videoUrl,
                    'thumbnail' => $thumbnail,
                    'title' => $title,
                    'extraction_method' => 'pinterest_api_fallback'
                ];
            }
        }
        
        // Try alternative path for story pins
        if (isset($result['resource_response']['data']['story_pin_data']['pages'][0]['blocks'][0]['video']['video_list'])) {
            $videoList = $result['resource_response']['data']['story_pin_data']['pages'][0]['blocks'][0]['video']['video_list'];
            
            // Get the highest quality video
            foreach (['V_720P', 'V_480P', 'V_HLSV4', 'V_HLSV3_WEB', 'V_HLSV3_MOBILE'] as $quality) {
                if (isset($videoList[$quality]['url'])) {
                    $videoUrl = $videoList[$quality]['url'];
                    $thumbnail = $result['resource_response']['data']['images']['orig']['url'] ?? '';
                    $title = $result['resource_response']['data']['title'] ?? 'Pinterest Video';
                    
                    error_log("Found video URL in story pin data: " . $videoUrl);
                    return [
                        'success' => true,
                        'video_url' => $videoUrl,
                        'thumbnail' => $thumbnail,
                        'title' => $title,
                        'extraction_method' => 'pinterest_story_pin'
                    ];
                }
            }
        }
    }
    
    return [
        'success' => false,
        'message' => 'Could not extract video URL from Pinterest API'
    ];
}
?>
