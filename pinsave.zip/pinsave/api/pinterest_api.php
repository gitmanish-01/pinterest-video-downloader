<?php
/**
 * Pinterest Video API Handler
 * Uses RapidAPI to fetch Pinterest video data
 */

// Include configuration file
require_once __DIR__ . '/../config.php';

// Set default RapidAPI key if not defined in config
if (!defined('RAPIDAPI_KEY')) {
    define('RAPIDAPI_KEY', '4e95129c77msh450d4d435c7cbe1p1b6608jsna3349d7b7a56');
}

/**
 * Main function to get Pinterest video data
 * @param string $url Pinterest video URL
 * @return array Result with success status and video URL or error message
 */
function getPinterestVideoData($url) {
    // Get RapidAPI key from configuration
    $rapidApiKey = RAPIDAPI_KEY;
    $apiProvider = defined('API_PROVIDER') ? API_PROVIDER : 'pinterest-video-downloader1';
    $debugMode = defined('DEBUG_MODE') ? DEBUG_MODE : false;
    
    // Debug information
    $debug = [
        'api_provider' => $apiProvider,
        'debug_mode' => $debugMode ? 'Enabled' : 'Disabled',
        'timestamp' => date('Y-m-d H:i:s'),
        'url' => $url
    ];
    
    // FIRST APPROACH: Try our fixed video extraction method that filters out VTT files
    // This is our most reliable method now
    require_once __DIR__ . '/pinterest_video_fix.php';
    $result = extractPinterestVideo($url);
    
    if ($result['success']) {
        if ($debugMode) {
            $debug['extraction_method'] = 'fixed_video_extraction';
            $result['debug'] = array_merge($debug, $result['debug'] ?? []);
        }
        return $result;
    }
    
    if ($debugMode) {
        $debug['fixed_extraction_error'] = $result['message'] ?? 'Unknown error';
    }
    
    // SECOND APPROACH: Try the old methods if direct extraction failed
    
    // Check if API key is set for RapidAPI methods
    if (empty($rapidApiKey)) {
        return [
            'success' => false,
            'message' => 'Direct extraction failed and RapidAPI key is not configured. Please set your API key in the admin panel.'
        ];
    }
    
    // For international Pinterest URLs, try enhanced extraction
    if (preg_match('/[a-z]{2}\.pinterest\.com/i', $url)) {
        error_log("International Pinterest URL detected: {$url}. Trying enhanced extraction.");
        
        // Include the enhanced Pinterest extractor if it exists and hasn't been included
        if (file_exists(__DIR__ . '/pinterest_enhanced.php') && !function_exists('extractInternationalPinterestVideo')) {
            require_once __DIR__ . '/pinterest_enhanced.php';
            
            // Try the enhanced extraction method
            $enhancedResult = extractInternationalPinterestVideo($url);
            
            if ($enhancedResult['success']) {
                if ($debugMode) {
                    $debug['extraction_method'] = 'enhanced_international';
                    $enhancedResult['debug'] = array_merge($debug, $enhancedResult['debug'] ?? []);
                }
                return $enhancedResult;
            }
            
            if ($debugMode) {
                $debug['enhanced_extraction_error'] = $enhancedResult['message'] ?? 'Unknown error';
            }
        }
        
        // If enhanced extraction fails or doesn't exist, try standard direct extraction
        $oldDirectResult = extractPinterestVideoDirectly($url);
        
        if ($oldDirectResult['success']) {
            if ($debugMode) {
                $debug['extraction_method'] = 'direct_html_international';
                $oldDirectResult['debug'] = array_merge($debug, $oldDirectResult['debug'] ?? []);
            }
            return $oldDirectResult;
        }
        
        if ($debugMode) {
            $debug['direct_extraction_error'] = $oldDirectResult['message'] ?? 'Unknown error';
        }
    }
    
    // Extract pin ID from URL for direct Pinterest API call
    $pinId = extractPinId($url);
    if (!empty($pinId)) {
        // Try Pinterest's internal API
        $result = callPinterestInternalAPI($pinId);
        if ($result['success']) {
            if ($debugMode) {
                $result['debug'] = array_merge($debug, $result['debug'] ?? []);
            }
            return $result;
        }
        
        if ($debugMode) {
            $debug['internal_api_error'] = $result['message'] ?? 'Unknown error';
        }
    } else {
        // If we couldn't extract a pin ID, try to expand short URLs
        $expandedUrl = expandShortUrl($url);
        if ($expandedUrl && $expandedUrl !== $url) {
            $pinId = extractPinId($expandedUrl);
            if (!empty($pinId)) {
                $result = callPinterestInternalAPI($pinId);
                if ($result['success']) {
                    if ($debugMode) {
                        $result['debug'] = array_merge($debug, $result['debug'] ?? []);
                    }
                    return $result;
                }
            }
        }
    }
    
    // Select API provider based on admin settings
    switch ($apiProvider) {
        case 'pinterest-video-downloader1':
            $result = callPinterestAPI($url, $rapidApiKey);
            if ($debugMode) {
                $debug['api_method'] = 'pinterest-video-downloader1';
                $debug['api_result'] = $result['success'] ? 'success' : 'failed';
            }
            break;
            
        case 'pinterest-video-downloader2':
            $result = callPinterestAPIAlternative($url, $rapidApiKey);
            if ($debugMode) {
                $debug['api_method'] = 'pinterest-video-downloader2';
                $debug['api_result'] = $result['success'] ? 'success' : 'failed';
            }
            break;
            
        case 'pinterest-video-downloader3':
            $result = callPinterestAPIAlternative2($url, $rapidApiKey);
            if ($debugMode) {
                $debug['api_method'] = 'pinterest-video-downloader3';
                $debug['api_result'] = $result['success'] ? 'success' : 'failed';
            }
            break;
            
        default:
            // Try all methods in sequence as fallback
            $result = callPinterestAPI($url, $rapidApiKey);
            if ($debugMode) {
                $debug['api_method'] = 'fallback_sequence';
                $debug['first_api_result'] = $result['success'] ? 'success' : 'failed';
            }
            
            // If direct call failed, try first alternative API
            if (!$result['success']) {
                $result = callPinterestAPIAlternative($url, $rapidApiKey);
                if ($debugMode) {
                    $debug['second_api_result'] = $result['success'] ? 'success' : 'failed';
                }
                
                // If first alternative failed, try second alternative API
                if (!$result['success']) {
                    $result = callPinterestAPIAlternative2($url, $rapidApiKey);
                    if ($debugMode) {
                        $debug['third_api_result'] = $result['success'] ? 'success' : 'failed';
                    }
                }
            }
            break;
    }
    
    // If all API methods failed, try direct extraction as last resort
    if (!$result['success']) {
        // Log the failure for debugging
        error_log("All API methods failed for URL: {$url}. Trying direct extraction.");
        
        // Try direct extraction
        $result = extractPinterestVideoDirectly($url);
        
        if ($debugMode) {
            $debug['extraction_method'] = 'direct_html';
            $debug['direct_extraction'] = $result['success'] ? 'success' : 'failed';
            
            if (!$result['success']) {
                $debug['direct_extraction_error'] = $result['message'] ?? 'Unknown error';
            }
        }
        $result['debug'] = array_merge($debug, $result['debug'] ?? []);
    }
    
    return $result;
}

/**
 * Call the primary Pinterest API
 * @param string $url Pinterest video URL
 * @param string $rapidApiKey RapidAPI key
 * @return array Result with success status and video URL or error message
 */
function callPinterestAPI($url, $rapidApiKey) {
    // Normalize Pinterest URL
    if (strpos($url, 'pin.it') !== false) {
        $expandedUrl = expandShortUrl($url);
        if (!empty($expandedUrl)) {
            $url = $expandedUrl;
        }
    }
    
    // Log the URL we're trying to download from
    error_log("Attempting to download from URL: " . $url);
    
    // Prepare the API request - using exact format from RapidAPI example
    $curl = curl_init();
    
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://pinterest-video-downloader1.p.rapidapi.com/",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => "url=" . urlencode($url),
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/x-www-form-urlencoded",
            "x-rapidapi-host: pinterest-video-downloader1.p.rapidapi.com",
            "x-rapidapi-key: " . $rapidApiKey
        ],
    ]);
    
    $response = curl_exec($curl);
    $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    // Log response for debugging
    error_log("Pinterest API HTTP Code: " . $httpCode);
    error_log("Pinterest API Raw Response: " . $response);
    
    if ($err) {
        return [
            'success' => false,
            'message' => "cURL Error: " . $err
        ];
    }
    
    // Check for HTTP errors
    if ($httpCode >= 400) {
        return [
            'success' => false,
            'message' => "API Error: HTTP Code " . $httpCode . ". Please try again later."
        ];
    }
    
    // Parse the response
    $result = json_decode($response, true);
    
    // Check for valid JSON
    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log("JSON Parse Error: " . json_last_error_msg());
        return [
            'success' => false,
            'message' => "Error parsing API response. Please try again later."
        ];
    }
    
    // Check for API error messages
    if (isset($result['error']) && !empty($result['error'])) {
        return [
            'success' => false,
            'message' => "API Error: " . $result['error']
        ];
    }
    
    // Check for video links
    if (isset($result['links']) && !empty($result['links'])) {
        // Get the highest quality video URL
        $videoUrl = '';
        foreach ($result['links'] as $link) {
            if (isset($link['url']) && !empty($link['url'])) {
                $videoUrl = $link['url'];
                break; // Use the first available video URL
            }
        }
        
        if (!empty($videoUrl)) {
            return [
                'success' => true,
                'video_url' => $videoUrl,
                'thumbnail' => $result['thumbnail'] ?? '',
                'title' => $result['title'] ?? 'Pinterest Video'
            ];
        }
    }
    
    // If we reach here, something went wrong with the API response
    return [
        'success' => false,
        'message' => 'Could not extract video URL from Pinterest link. Please check if the URL is correct and contains a video.',
        'debug' => $result
    ];
}

/**
 * Alternative API call method
 * @param string $url Pinterest video URL
 * @param string $rapidApiKey RapidAPI key
 * @return array Result with success status and video URL or error message
 */
function callPinterestAPIAlternative($url, $rapidApiKey) {
    // Try a different API endpoint format
    $curl = curl_init();
    
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://pinterest-downloader-download-pinterest-image-video-and-reels.p.rapidapi.com/",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => json_encode([
            'url' => $url
        ]),
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/json",
            "X-RapidAPI-Host: pinterest-downloader-download-pinterest-image-video-and-reels.p.rapidapi.com",
            "X-RapidAPI-Key: " . $rapidApiKey
        ],
    ]);
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    error_log("Alternative API Raw Response: " . $response);
    
    if ($err) {
        return [
            'success' => false,
            'message' => "cURL Error: " . $err
        ];
    }
    
    // Parse the response
    $result = json_decode($response, true);
    
    // Check if we got a valid response with video URL
    if (isset($result['data']) && isset($result['data']['videos']) && !empty($result['data']['videos'])) {
        return [
            'success' => true,
            'video_url' => $result['data']['videos'][0],
            'thumbnail' => $result['data']['thumbnail'] ?? '',
            'title' => $result['data']['title'] ?? 'Pinterest Video'
        ];
    }
    
    return [
        'success' => false,
        'message' => 'Could not extract video URL from Pinterest link using alternative API.',
        'debug' => $result
    ];
}

/**
 * Second alternative API call method
 * @param string $url Pinterest video URL
 * @param string $rapidApiKey RapidAPI key
 * @return array Result with success status and video URL or error message
 */
function callPinterestAPIAlternative2($url, $rapidApiKey) {
    // Try a third API endpoint
    $curl = curl_init();
    
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://social-media-video-downloader.p.rapidapi.com/pinterest?url=" . urlencode($url),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => [
            "X-RapidAPI-Host: social-media-video-downloader.p.rapidapi.com",
            "X-RapidAPI-Key: " . $rapidApiKey
        ],
    ]);
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    error_log("Second Alternative API Raw Response: " . $response);
    
    if ($err) {
        return [
            'success' => false,
            'message' => "cURL Error: " . $err
        ];
    }
    
    // Parse the response
    $result = json_decode($response, true);
    
    // Check if we got a valid response with video URL
    if (isset($result['video_url']) && !empty($result['video_url'])) {
        return [
            'success' => true,
            'video_url' => $result['video_url'],
            'thumbnail' => $result['thumbnail'] ?? '',
            'title' => $result['title'] ?? 'Pinterest Video'
        ];
    }
    
    return [
        'success' => false,
        'message' => 'Could not extract video URL from Pinterest link using any available API. The URL may not contain a video or may be private.',
        'debug' => $result
    ];
}

/**
 * Expand a Pinterest short URL to its full form
 * @param string $shortUrl Short Pinterest URL
 * @return string Full URL or empty string if expansion fails
 */
function expandShortUrl($shortUrl) {
    $ch = curl_init($shortUrl);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_exec($ch);
    $fullUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);
    
    if (!empty($fullUrl) && $fullUrl !== $shortUrl) {
        error_log("Expanded short URL from {$shortUrl} to {$fullUrl}");
        return $fullUrl;
    }
    
    return '';
}

/**
 * Attempt to extract Pinterest video URL directly from the page HTML
 * This is a last resort method when all API methods fail
 * @param string $url Pinterest URL
 * @return array Result with success status and video URL or error message
 */
function extractPinterestVideoDirectly($url) {
    // Make sure we have a full URL
    if (strpos($url, 'pin.it') !== false) {
        $expandedUrl = expandShortUrl($url);
        if (!empty($expandedUrl)) {
            $url = $expandedUrl;
        }
    }
    
    error_log("Attempting direct extraction from: " . $url);
    
    // Set up a request with browser-like headers and improved anti-blocking measures
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.64',
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_ENCODING => 'gzip, deflate',
        CURLOPT_COOKIEJAR => __DIR__ . '/pinterest_cookies.txt',
        CURLOPT_COOKIEFILE => __DIR__ . '/pinterest_cookies.txt',
        CURLOPT_REFERER => 'https://www.google.com/',
        CURLOPT_CONNECTTIMEOUT => 30,
        CURLOPT_HTTPHEADER => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Language: en-US,en;q=0.9',
            'sec-ch-ua: "Chromium";v="112", "Microsoft Edge";v="112", "Not:A-Brand";v="99"',
            'sec-ch-ua-mobile: ?0',
            'sec-ch-ua-platform: "Windows"',
            'sec-fetch-dest: document',
            'sec-fetch-mode: navigate',
            'sec-fetch-site: none',
            'sec-fetch-user: ?1',
            'Cache-Control: no-cache',
            'Pragma: no-cache',
            'Upgrade-Insecure-Requests: 1'
        ]
    ]);
    
    // Add a random delay to mimic human behavior
    usleep(rand(500000, 1500000)); // 0.5 to 1.5 seconds
    
    $html = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);
    
    if ($err) {
        return [
            'success' => false,
            'message' => "Error fetching Pinterest page: " . $err
        ];
    }
    
    // Log a small portion of the HTML for debugging
    error_log("Direct extraction HTML snippet: " . substr($html, 0, 300) . "...");
    
    // Method 0: Extract from Pinterest's initial state data
    if (preg_match('/window\.__INITIAL_STATE__\s*=\s*(\{.*?\});<\/script>/s', $html, $matches)) {
        $initialState = json_decode($matches[1], true);
        error_log("Found initial state data");
        
        // Navigate through the structure to find video URL
        if (isset($initialState['resourceResponses'])) {
            foreach ($initialState['resourceResponses'] as $response) {
                if (isset($response['response']['data']['videos']['video_list'])) {
                    $videoList = $response['response']['data']['videos']['video_list'];
                    // Get the highest quality video
                    foreach (['V_720P', 'V_480P', 'V_HLSV4', 'V_HLSV3_WEB', 'V_HLSV3_MOBILE'] as $quality) {
                        if (isset($videoList[$quality]['url'])) {
                            $videoUrl = $videoList[$quality]['url'];
                            error_log("Found video URL in initial state: " . $videoUrl);
                            return [
                                'success' => true,
                                'video_url' => $videoUrl,
                                'title' => 'Pinterest Video',
                                'extraction_method' => 'initial_state'
                            ];
                        }
                    }
                }
            }
        }
    }
    
    // Method 1: Look for video URL in JSON data (multiple patterns)
    $patterns = [
        '/"video":\s*{[^}]*"url":\s*"([^"]+)"/',
        '/"video_url":\s*"([^"]+)"/',
        '/"contentUrl":\s*"([^"]+\.mp4[^"]*)"/i',
        '/\.mp4\\":\{\\"url\\":\\"([^\\]+)\\"/',
        '/"url":\s*"([^"]+\.mp4[^"]*)"/i'
    ];
    
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $html, $matches)) {
            $videoUrl = str_replace('\/', '/', $matches[1]);
            error_log("Found video URL using JSON pattern: " . $videoUrl);
            return [
                'success' => true,
                'video_url' => $videoUrl,
                'title' => 'Pinterest Video',
                'extraction_method' => 'json_pattern'
            ];
        }
    }
    
    // Method 2: Look for video URL in meta tags
    if (preg_match('/<meta\s+property="og:video"\s+content="([^"]+)"/', $html, $matches)) {
        $videoUrl = $matches[1];
        error_log("Found video URL in meta tag: " . $videoUrl);
        return [
            'success' => true,
            'video_url' => $videoUrl,
            'title' => 'Pinterest Video',
            'extraction_method' => 'meta_tag'
        ];
    }
    
    // Method 3: Look for video URL in a video tag
    if (preg_match('/<video[^>]*>\s*<source\s+src="([^"]+)"/', $html, $matches)) {
        $videoUrl = $matches[1];
        error_log("Found video URL in video tag: " . $videoUrl);
        return [
            'success' => true,
            'video_url' => $videoUrl,
            'title' => 'Pinterest Video',
            'extraction_method' => 'video_tag'
        ];
    }
    
    // Method 4: Look for video URL in any attribute
    if (preg_match('/(?:src|data-src|href)=[\"\'](https?:\/\/[^\"\']+\.mp4[^\"\']*)[\"\']/', $html, $matches)) {
        $videoUrl = $matches[1];
        error_log("Found video URL in attribute: " . $videoUrl);
        return [
            'success' => true,
            'video_url' => $videoUrl,
            'title' => 'Pinterest Video',
            'extraction_method' => 'attribute_search'
        ];
    }
    
    // If we get here, we couldn't find a video URL
    return [
        'success' => false,
        'message' => 'Could not extract video URL directly from Pinterest page. The URL may not contain a video or may be private.',
        'debug' => 'Direct HTML extraction failed'
    ];
}

/**
 * Extract Pinterest pin ID from URL
 * @param string $url Pinterest URL
 * @return string Pin ID or empty string if not found
 */
function extractPinId($url) {
    // Make sure we have a full URL
    if (strpos($url, 'pin.it') !== false) {
        $expandedUrl = expandShortUrl($url);
        if (!empty($expandedUrl)) {
            $url = $expandedUrl;
        }
    }
    
    // Extract pin ID using regex patterns
    $patterns = [
        '/\/pin\/(\d+)/',                  // Standard URL pattern
        '/pinterest\.com\/pin\/(\d+)/',    // Full domain pattern
        '/[a-z]{2}\.pinterest\.com\/pin\/(\d+)/',  // International domains (in.pinterest.com, etc.)
        '/pin\/(\d+)/',                    // Relative path pattern
        '/pin-(\d+)/',                     // Alternative format
        '/pin_id=(\d+)/',                  // Query parameter
        '/\/pin\/([a-zA-Z0-9_-]+)/',        // New format with alphanumeric IDs
        '/pinterest\.com\/pin\/([a-zA-Z0-9_-]+)/', // New format with full domain
        '/[a-z]{2}\.pinterest\.com\/pin\/([a-zA-Z0-9_-]+)/', // International domains with new format
        '/pinterest\.com\/(.*?)\/pin\/(\d+)/',  // User profile pin format
        '/pinterest\.com\/(.*?)\/pin\/([a-zA-Z0-9_-]+)/', // User profile with new format
        '/[a-z]{2}\.pinterest\.com\/(.*?)\/pin\/(\d+)/',  // International user profile pin format
        '/[a-z]{2}\.pinterest\.com\/(.*?)\/pin\/([a-zA-Z0-9_-]+)/' // International user profile with new format
    ];
    
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $url, $matches)) {
            // Return the last match from the array (the pin ID)
            $pinId = end($matches);
            error_log("Extracted Pin ID: " . $pinId);
            return $pinId;
        }
    }
    
    error_log("Could not extract Pin ID from URL: " . $url);
    return '';
}

/**
 * Call Pinterest's internal API to get video data
 * @param string $pinId Pinterest pin ID
 * @return array Result with success status and video URL or error message
 */
function callPinterestInternalAPI($pinId) {
    // Try both www.pinterest.com and in.pinterest.com domains
    $domains = ['www.pinterest.com', 'in.pinterest.com'];
    $response = null;
    $err = null;
    
    foreach ($domains as $domain) {
        $apiUrl = "https://{$domain}/resource/PinResource/get/";
        $data = [
            "options" => [
                "id" => $pinId,
                "field_set_key" => "detailed"
            ],
            "context" => []
        ];
        
        $queryParams = [
            "source_url" => "/pin/{$pinId}/",
            "data" => json_encode($data)
        ];
        
        $fullUrl = $apiUrl . '?' . http_build_query($queryParams);
        
        error_log("Calling Pinterest internal API for pin ID: {$pinId} using domain: {$domain}");
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $fullUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json, text/javascript, */*; q=0.01',
                'Accept-Language: en-US,en;q=0.5',
                'X-Requested-With: XMLHttpRequest',
                'X-APP-VERSION: 9e3f4ae',
                'Referer: https://{$domain}/'
            ]
        ]);
        
        $response = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        
        // If we got a valid response, break the loop
        if (!$err && $response && strpos($response, 'resource_response') !== false) {
            break;
        }
    }
    
    if ($err) {
        return [
            'success' => false,
            'message' => "Error calling Pinterest internal API: " . $err
        ];
    }
    
    error_log("Pinterest internal API response received");
    
    // Parse the response
    $result = json_decode($response, true);
    
    error_log("Analyzing Pinterest API response for video URLs");
    
    // Debug the response structure
    if (!isset($result['resource_response']['data'])) {
        error_log("Pinterest API response missing resource_response.data structure");
        error_log("Response keys: " . implode(", ", array_keys($result)));
        // Dump the entire response for debugging
        error_log("Full API response: " . json_encode($result));
    } else {
        error_log("Pinterest API response contains resource_response.data structure");
        // Check if this is a video pin
        if (isset($result['resource_response']['data']['videos'])) {
            error_log("This appears to be a video pin");
        } else {
            error_log("This does NOT appear to be a video pin - no videos key found");
            error_log("Available data keys: " . implode(", ", array_keys($result['resource_response']['data'])));
        }
    }
    
    // Check standard video path
    if (isset($result['resource_response']['data']['videos']['video_list'])) {
        $videoList = $result['resource_response']['data']['videos']['video_list'];
        error_log("Found standard video_list with keys: " . implode(", ", array_keys($videoList)));
        
        // Get the highest quality video
        foreach (['V_720P', 'V_480P', 'V_HLSV4', 'V_HLSV3_WEB', 'V_HLSV3_MOBILE'] as $quality) {
            if (isset($videoList[$quality]['url'])) {
                $videoUrl = $videoList[$quality]['url'];
                $thumbnail = $result['resource_response']['data']['images']['orig']['url'] ?? '';
                $title = $result['resource_response']['data']['title'] ?? 'Pinterest Video';
                
                error_log("Found video URL in Pinterest internal API: " . $videoUrl);
                return [
                    'success' => true,
                    'video_url' => $videoUrl,
                    'thumbnail' => $thumbnail,
                    'title' => $title,
                    'extraction_method' => 'pinterest_internal_api'
                ];
            }
        }
    }
    
    // Try story pin path
    if (isset($result['resource_response']['data']['story_pin_data']['pages'][0]['blocks'][0]['video']['video_list'])) {
        $videoList = $result['resource_response']['data']['story_pin_data']['pages'][0]['blocks'][0]['video']['video_list'];
        error_log("Found story pin video_list");
        
        // Get the highest quality video
        foreach (['V_720P', 'V_480P', 'V_HLSV4', 'V_HLSV3_WEB', 'V_HLSV3_MOBILE'] as $quality) {
            if (isset($videoList[$quality]['url'])) {
                $videoUrl = $videoList[$quality]['url'];
                $thumbnail = $result['resource_response']['data']['images']['orig']['url'] ?? '';
                $title = $result['resource_response']['data']['title'] ?? 'Pinterest Video';
                
                error_log("Found video URL in Pinterest story pin data: " . $videoUrl);
                return [
                    'success' => true,
                    'video_url' => $videoUrl,
                    'thumbnail' => $thumbnail,
                    'title' => $title,
                    'extraction_method' => 'pinterest_story_pin'
                ];
            }
        }
    }
    
    // Try video format for India/international Pinterest
    if (isset($result['resource_response']['data']['videos'])) {
        $videos = $result['resource_response']['data']['videos'];
        error_log("Found videos data structure with keys: " . implode(", ", array_keys($videos)));
        
        // Check for video_list in different format
        if (isset($videos['video_list'])) {
            $videoList = $videos['video_list'];
            
            // Some international Pinterest formats use different quality keys
            $qualityKeys = array_keys($videoList);
            error_log("Available quality keys: " . implode(", ", $qualityKeys));
            
            // Try standard quality keys first
            foreach (['V_720P', 'V_480P', 'V_HLSV4', 'V_HLSV3_WEB', 'V_HLSV3_MOBILE'] as $quality) {
                if (isset($videoList[$quality]['url'])) {
                    $videoUrl = $videoList[$quality]['url'];
                    $thumbnail = $result['resource_response']['data']['images']['orig']['url'] ?? '';
                    $title = $result['resource_response']['data']['title'] ?? 'Pinterest Video';
                    
                    error_log("Found video URL using standard quality key: " . $quality);
                    return [
                        'success' => true,
                        'video_url' => $videoUrl,
                        'thumbnail' => $thumbnail,
                        'title' => $title,
                        'extraction_method' => 'pinterest_internal_api_standard'
                    ];
                }
            }
            
            // If standard keys didn't work, try the first available quality
            if (!empty($qualityKeys)) {
                $firstQuality = $qualityKeys[0];
                if (isset($videoList[$firstQuality]['url'])) {
                    $videoUrl = $videoList[$firstQuality]['url'];
                    $thumbnail = $result['resource_response']['data']['images']['orig']['url'] ?? '';
                    $title = $result['resource_response']['data']['title'] ?? 'Pinterest Video';
                    
                    error_log("Found video URL using first available quality key: " . $firstQuality);
                    return [
                        'success' => true,
                        'video_url' => $videoUrl,
                        'thumbnail' => $thumbnail,
                        'title' => $title,
                        'extraction_method' => 'pinterest_internal_api_fallback'
                    ];
                }
            }
        }
    }
    
    return [
        'success' => false,
        'message' => 'Could not extract video URL from Pinterest internal API.',
        'debug' => 'Pin ID: ' . $pinId
    ];
}

/**
 * Alternative function to use a different RapidAPI endpoint if needed
 */
function getPinterestVideoDataAlternative($url) {
    // RapidAPI configuration
    $rapidApiKey = ""; // You'll need to set your RapidAPI key here
    
    // Check if API key is set
    if (empty($rapidApiKey)) {
        return [
            'success' => false,
            'message' => 'RapidAPI key is not configured. Please set your API key in the pinterest_api.php file.'
        ];
    }
    
    // Prepare the API request
    $curl = curl_init();
    
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://social-media-video-downloader.p.rapidapi.com/pinterest?url=" . urlencode($url),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => [
            "X-RapidAPI-Host: social-media-video-downloader.p.rapidapi.com",
            "X-RapidAPI-Key: " . $rapidApiKey
        ],
    ]);
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
        return [
            'success' => false,
            'message' => "cURL Error: " . $err
        ];
    }
    
    // Parse the response
    $result = json_decode($response, true);
    
    // Check if we got a valid response with video URL
    if (isset($result['video_url'])) {
        return [
            'success' => true,
            'video_url' => $result['video_url'],
            'thumbnail' => $result['thumbnail'] ?? '',
            'title' => $result['title'] ?? 'Pinterest Video'
        ];
    }
    
    // If we reach here, something went wrong with the API response
    return [
        'success' => false,
        'message' => 'Could not extract video URL from Pinterest link. Please check if the URL is correct and contains a video.',
        'debug' => $result ?? null
    ];
}
?>
