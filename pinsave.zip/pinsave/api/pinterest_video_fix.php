<?php
/**
 * Pinterest Video Fix
 * Direct extraction of Pinterest videos with VTT file filtering
 */

/**
 * Extract video URL from Pinterest page
 * @param string $url Pinterest URL
 * @return array Result with success status and video URL or error message
 */
function extractPinterestVideo($url) {
    error_log("Starting Pinterest video extraction for: " . $url);
    
    // Step 1: Get the Pinterest page content
    $html = fetchPinterestPage($url);
    if (empty($html)) {
        return [
            'success' => false,
            'message' => 'Failed to fetch Pinterest page'
        ];
    }
    
    // Save HTML for debugging
    $debugFile = __DIR__ . '/pinterest_debug.html';
    file_put_contents($debugFile, $html);
    error_log("Saved Pinterest HTML to: " . $debugFile);
    
    // Step 2: Extract video URL using multiple methods
    $videoUrl = findVideoUrlInHtml($html);
    
    if (!empty($videoUrl)) {
        // Verify it's a video file, not VTT
        if (isValidVideoUrl($videoUrl)) {
            return [
                'success' => true,
                'video_url' => $videoUrl,
                'title' => 'Pinterest Video',
                'extraction_method' => 'direct_html'
            ];
        } else {
            error_log("Found URL is not a valid video: " . $videoUrl);
        }
    }
    
    // Step 3: Try Pinterest API if direct extraction failed
    $pinId = extractPinId($url);
    if (!empty($pinId)) {
        $videoUrl = getPinterestVideoFromApi($pinId);
        if (!empty($videoUrl) && isValidVideoUrl($videoUrl)) {
            return [
                'success' => true,
                'video_url' => $videoUrl,
                'title' => 'Pinterest Video',
                'extraction_method' => 'pinterest_api'
            ];
        }
    }
    
    return [
        'success' => false,
        'message' => 'Could not find a valid video URL'
    ];
}

/**
 * Fetch Pinterest page content
 * @param string $url Pinterest URL
 * @return string HTML content or empty string on failure
 */
function fetchPinterestPage($url) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTPHEADER => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language: en-US,en;q=0.5',
            'Cache-Control: no-cache',
            'Pragma: no-cache'
        ],
        CURLOPT_ENCODING => 'gzip, deflate'
    ]);
    
    $html = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);
    
    if ($err) {
        error_log("cURL error: " . $err);
        return '';
    }
    
    return $html;
}

/**
 * Extract pin ID from Pinterest URL
 * @param string $url Pinterest URL
 * @return string Pin ID or empty string if not found
 */
function extractPinId($url) {
    $patterns = [
        '/\/pin\/(\d+)/',
        '/pinterest\.com\/pin\/(\d+)/',
        '/[a-z]{2}\.pinterest\.com\/pin\/(\d+)/',
        '/\/pin\/([a-zA-Z0-9_-]+)/',
        '/pinterest\.com\/pin\/([a-zA-Z0-9_-]+)/',
        '/[a-z]{2}\.pinterest\.com\/pin\/([a-zA-Z0-9_-]+)/',
        '/pinterest\.com\/.*?\/pin\/(\d+)/',
        '/pinterest\.com\/.*?\/pin\/([a-zA-Z0-9_-]+)/',
        '/[a-z]{2}\.pinterest\.com\/.*?\/pin\/(\d+)/',
        '/[a-z]{2}\.pinterest\.com\/.*?\/pin\/([a-zA-Z0-9_-]+)/'
    ];
    
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $url, $matches)) {
            return $matches[1];
        }
    }
    
    return '';
}

/**
 * Find video URL in HTML content
 * @param string $html HTML content
 * @return string Video URL or empty string if not found
 */
function findVideoUrlInHtml($html) {
    // Method 1: Look for video URLs in JSON-LD data
    if (preg_match('/<script type="application\/ld\+json">(.*?)<\/script>/s', $html, $matches)) {
        $jsonData = json_decode($matches[1], true);
        if ($jsonData && isset($jsonData['video']) && isset($jsonData['video']['contentUrl'])) {
            $videoUrl = $jsonData['video']['contentUrl'];
            if (isValidVideoUrl($videoUrl)) {
                error_log("Found video URL in JSON-LD: " . $videoUrl);
                return $videoUrl;
            }
        }
    }
    
    // Method 2: Extract from initial state data
    if (preg_match('/window\.__INITIAL_STATE__\s*=\s*(\{.*?\});<\/script>/s', $html, $matches)) {
        $initialState = json_decode($matches[1], true);
        
        if ($initialState && isset($initialState['resourceResponses'])) {
            foreach ($initialState['resourceResponses'] as $response) {
                if (isset($response['response']['data']['videos']['video_list'])) {
                    $videoList = $response['response']['data']['videos']['video_list'];
                    
                    // Get the highest quality video
                    foreach (['V_720P', 'V_480P', 'V_HLSV4', 'V_HLSV3_WEB', 'V_HLSV3_MOBILE'] as $quality) {
                        if (isset($videoList[$quality]['url'])) {
                            $videoUrl = $videoList[$quality]['url'];
                            if (isValidVideoUrl($videoUrl)) {
                                error_log("Found video URL in initial state: " . $videoUrl);
                                return $videoUrl;
                            }
                        }
                    }
                    
                    // If standard qualities not found, try the first available
                    foreach ($videoList as $quality => $data) {
                        if (isset($data['url']) && isValidVideoUrl($data['url'])) {
                            error_log("Found video URL in initial state (alternative quality): " . $data['url']);
                            return $data['url'];
                        }
                    }
                }
                
                // Check for story pins
                if (isset($response['response']['data']['story_pin_data']['pages'])) {
                    foreach ($response['response']['data']['story_pin_data']['pages'] as $page) {
                        if (isset($page['blocks'])) {
                            foreach ($page['blocks'] as $block) {
                                if (isset($block['video']['video_list'])) {
                                    $videoList = $block['video']['video_list'];
                                    foreach ($videoList as $quality => $data) {
                                        if (isset($data['url']) && isValidVideoUrl($data['url'])) {
                                            error_log("Found video URL in story pin: " . $data['url']);
                                            return $data['url'];
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    // Method 3: Look for video URLs in various patterns
    $patterns = [
        // Only match MP4 files specifically
        '/"video":\s*{[^}]*"url":\s*"([^"]+\.mp4[^"]*)"/',
        '/"video_url":\s*"([^"]+\.mp4[^"]*)"/',
        '/"contentUrl":\s*"([^"]+\.mp4[^"]*)"/',
        '/\.mp4\\":\{\\"url\\":\\"([^\\]+)\\"/',
        '/"url":\s*"([^"]+\.mp4[^"]*)"/',
        '/"playEligibleVideo":\s*{[^}]*"url":\s*"([^"]+\.mp4[^"]*)"/',
        '/"v_720p":\s*{[^}]*"url":\s*"([^"]+\.mp4[^"]*)"/',
        '/"v_480p":\s*{[^}]*"url":\s*"([^"]+\.mp4[^"]*)"/',
    ];
    
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $html, $matches)) {
            $videoUrl = str_replace('\/', '/', $matches[1]);
            if (isValidVideoUrl($videoUrl)) {
                error_log("Found video URL using pattern: " . $videoUrl);
                return $videoUrl;
            }
        }
    }
    
    // Method 4: Look for video tags
    if (preg_match('/<video[^>]*src="([^"]+)"/', $html, $matches)) {
        $videoUrl = $matches[1];
        if (isValidVideoUrl($videoUrl)) {
            error_log("Found video URL in video tag: " . $videoUrl);
            return $videoUrl;
        }
    }
    
    return '';
}

/**
 * Get Pinterest video using their internal API
 * @param string $pinId Pinterest pin ID
 * @return string Video URL or empty string if not found
 */
function getPinterestVideoFromApi($pinId) {
    $domains = ['www.pinterest.com', 'in.pinterest.com'];
    
    foreach ($domains as $domain) {
        $apiUrl = "https://{$domain}/resource/PinResource/get/";
        $data = [
            "options" => [
                "id" => $pinId,
                "field_set_key" => "detailed"
            ],
            "context" => []
        ];
        
        $queryParams = [
            "source_url" => "/pin/{$pinId}/",
            "data" => json_encode($data)
        ];
        
        $fullUrl = $apiUrl . '?' . http_build_query($queryParams);
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $fullUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json, text/javascript, */*; q=0.01',
                'Accept-Language: en-US,en;q=0.5',
                'X-Requested-With: XMLHttpRequest',
                'X-APP-VERSION: 9e3f4ae',
                'Referer: https://' . $domain . '/'
            ]
        ]);
        
        $response = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        
        if ($err) {
            continue;
        }
        
        $result = json_decode($response, true);
        
        // Check for video data
        if (isset($result['resource_response']['data']['videos']['video_list'])) {
            $videoList = $result['resource_response']['data']['videos']['video_list'];
            
            // Get the highest quality video
            foreach (['V_720P', 'V_480P', 'V_HLSV4', 'V_HLSV3_WEB', 'V_HLSV3_MOBILE'] as $quality) {
                if (isset($videoList[$quality]['url'])) {
                    $videoUrl = $videoList[$quality]['url'];
                    if (isValidVideoUrl($videoUrl)) {
                        error_log("Found video URL in Pinterest API: " . $videoUrl);
                        return $videoUrl;
                    }
                }
            }
            
            // If standard qualities not found, try the first available
            foreach ($videoList as $quality => $data) {
                if (isset($data['url']) && isValidVideoUrl($data['url'])) {
                    error_log("Found video URL in Pinterest API (alternative quality): " . $data['url']);
                    return $data['url'];
                }
            }
        }
        
        // Try alternative path for story pins
        if (isset($result['resource_response']['data']['story_pin_data']['pages'][0]['blocks'][0]['video']['video_list'])) {
            $videoList = $result['resource_response']['data']['story_pin_data']['pages'][0]['blocks'][0]['video']['video_list'];
            
            foreach ($videoList as $quality => $data) {
                if (isset($data['url']) && isValidVideoUrl($data['url'])) {
                    error_log("Found video URL in story pin data: " . $data['url']);
                    return $data['url'];
                }
            }
        }
    }
    
    return '';
}

/**
 * Check if URL is a valid video URL (not VTT or other non-video file)
 * @param string $url URL to check
 * @return bool True if valid video URL
 */
function isValidVideoUrl($url) {
    // Check for VTT files (subtitles) which we want to exclude
    if (stripos($url, '.vtt') !== false) {
        error_log("Skipping VTT file: " . $url);
        return false;
    }
    
    // Check for common video extensions
    $videoExtensions = ['.mp4', '.mov', '.avi', '.wmv', '.flv', '.webm', '.m4v'];
    foreach ($videoExtensions as $ext) {
        if (stripos($url, $ext) !== false) {
            return true;
        }
    }
    
    // If no extension found, check if URL contains video-related keywords
    $videoKeywords = ['video', 'media', 'stream', 'content'];
    foreach ($videoKeywords as $keyword) {
        if (stripos($url, $keyword) !== false) {
            return true;
        }
    }
    
    // Default to false if we're not sure
    return false;
}
?>
