<?php
// Ensure these variables are set
if (!isset($seoTitle)) $seoTitle = 'PinSave - Pinterest Video Downloader';
if (!isset($seoDescription)) $seoDescription = 'Download Pinterest videos easily with PinSave. Free online tool to save Pinterest videos in high quality.';
if (!isset($seoKeywords)) $seoKeywords = 'pinterest video downloader, download pinterest videos, save pinterest videos';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Primary SEO Meta Tags -->
    <title><?php echo htmlspecialchars($seoTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($seoDescription); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($seoKeywords); ?>">
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>">
    <meta property="og:title" content="<?php echo htmlspecialchars($seoTitle); ?>">
    <meta property="og:description" content="<?php echo htmlspecialchars($seoDescription); ?>">
    <meta property="og:image" content="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']; ?>/img/pinsave-preview.jpg">
    
    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>">
    <meta property="twitter:title" content="<?php echo htmlspecialchars($seoTitle); ?>">
    <meta property="twitter:description" content="<?php echo htmlspecialchars($seoDescription); ?>">
    <meta property="twitter:image" content="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']; ?>/img/pinsave-preview.jpg">
    
    <!-- Stylesheets -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <style>
        /* Mobile Navigation Styles */
        @media (max-width: 1023px) {
            #nav-items {
                background: white;
                position: absolute;
                left: 0;
                right: 0;
                top: 100%;
                z-index: 50;
                border-top: 1px solid #e5e7eb;
                display: none;
            }
            
            #nav-items.show {
                display: block;
            }
        }
        
        /* Active States */
        .nav-item-active {
            color: #2563eb; /* blue-600 */
            background-color: #f3f4f6; /* gray-100 */
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <!-- Navigation Menu -->
        <nav class="bg-white shadow-md rounded-lg mb-8">
            <div class="container mx-auto px-4">
                <!-- Mobile Menu Button and Logo -->
                <div class="flex justify-between items-center py-3 lg:hidden">
                    <!-- Logo -->
                    <a href="/host/pinsave/" class="flex items-center">
                        <img src="/host/pinsave/img/logo.svg" alt="PinSave Logo" class="h-8 w-8">
                        <span class="ml-2 text-xl font-bold text-[#E60023]">PinSave</span>
                    </a>
                    <!-- Mobile menu button -->
                    <button id="mobileMenuBtn" class="text-gray-500 hover:text-gray-600">
                        <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                        </svg>
                    </button>
                </div>

                <!-- Desktop/Mobile Menu Items -->
                <div class="flex justify-between items-center w-full py-3">
                    <!-- Logo on the left -->
                    <a href="/host/pinsave/" class="flex items-center">
                        <img src="/host/pinsave/img/logo.svg" alt="PinSave Logo" class="h-8 w-8">
                        <span class="ml-2 text-xl font-bold text-[#E60023]">PinSave</span>
                    </a>
                    <!-- Menu items on the right -->
                    <div class="hidden lg:flex lg:items-center lg:space-x-1">
                        <a href="/host/pinsave/" class="text-gray-700 hover:text-[#E60023] px-3 py-2 rounded-md text-sm font-medium">Home</a>
                        <a href="/host/pinsave/pages/about.php" class="text-gray-700 hover:text-[#E60023] px-3 py-2 rounded-md text-sm font-medium">About</a>
                        <a href="/host/pinsave/blog.php" class="text-gray-700 hover:text-[#E60023] px-3 py-2 rounded-md text-sm font-medium">Blog</a>
                        <a href="/host/pinsave/pages/faq.php" class="text-gray-700 hover:text-[#E60023] px-3 py-2 rounded-md text-sm font-medium">FAQ</a>
                        <a href="/host/pinsave/pages/contact.php" class="text-gray-700 hover:text-[#E60023] px-3 py-2 rounded-md text-sm font-medium">Contact</a>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Mobile Menu -->
        <div class="lg:hidden">
            <div id="mobileMenu" class="hidden bg-white border-t border-gray-200 py-2">
                <div class="container mx-auto px-4 space-y-1">
                    <a href="/host/pinsave/" class="block px-3 py-2 text-blue-600 hover:text-blue-800 font-medium">Home</a>
                    <a href="/host/pinsave/pages/about.php" class="block px-3 py-2 text-blue-600 hover:text-blue-800 font-medium">About</a>
                    <a href="/host/pinsave/blog.php" class="block px-3 py-2 text-blue-600 hover:text-blue-800 font-medium">Blog</a>
                    <a href="/host/pinsave/pages/faq.php" class="block px-3 py-2 text-blue-600 hover:text-blue-800 font-medium">FAQ</a>
                    <a href="/host/pinsave/pages/contact.php" class="block px-3 py-2 text-blue-600 hover:text-blue-800 font-medium">Contact</a>
                </div>
            </div>
        </div>

        <!-- Mobile Menu Script -->
        <script>
            document.getElementById('mobileMenuBtn').addEventListener('click', function() {
                document.getElementById('mobileMenu').classList.toggle('hidden');
            });
        </script>
