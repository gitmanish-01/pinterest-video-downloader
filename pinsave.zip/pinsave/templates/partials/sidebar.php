<?php
// Get categories
$categories = $adminConfig['categories'] ?? [];
$recentPosts = array_slice($adminConfig['posts'] ?? [], 0, 5);
?>

<!-- Categories -->
<div class="bg-white rounded-lg shadow-sm p-6 mb-6">
    <h3 class="text-lg font-semibold mb-4">Categories</h3>
    <?php if (!empty($categories)): ?>
        <ul class="space-y-2">
            <?php foreach ($categories as $category): ?>
                <li>
                    <a href="/category/<?php echo $category['slug']; ?>" 
                       class="text-gray-600 hover:text-blue-600">
                        <?php echo htmlspecialchars($category['name']); ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p class="text-gray-500">No categories found</p>
    <?php endif; ?>
</div>

<!-- Recent Posts -->
<div class="bg-white rounded-lg shadow-sm p-6 mb-6">
    <h3 class="text-lg font-semibold mb-4">Recent Posts</h3>
    <?php if (!empty($recentPosts)): ?>
        <ul class="space-y-4">
            <?php foreach ($recentPosts as $post): ?>
                <li>
                    <a href="/blog/<?php echo $post['slug']; ?>" 
                       class="block hover:bg-gray-50 p-2 rounded">
                        <h4 class="font-medium text-gray-900"><?php echo htmlspecialchars($post['title']); ?></h4>
                        <span class="text-sm text-gray-500">
                            <?php echo date('M j, Y', strtotime($post['created_at'])); ?>
                        </span>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p class="text-gray-500">No recent posts</p>
    <?php endif; ?>
</div>

<!-- Ad Space -->
<div class="bg-white rounded-lg shadow-sm p-6 mb-6">
    <div class="bg-gray-100 p-4 rounded text-center">
        <!-- AdSense Ad -->
        <?php if (isset($adminConfig['ads']['sidebar'])): ?>
            <?php echo $adminConfig['ads']['sidebar']; ?>
        <?php else: ?>
            <span class="text-gray-500">Advertisement</span>
        <?php endif; ?>
    </div>
</div>
