<footer class="bg-white border-t mt-8">
    <div class="container mx-auto px-4 py-8">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
            <!-- About -->
            <div>
                <h3 class="text-lg font-semibold mb-4">About PinSave</h3>
                <p class="text-gray-600">
                    Download Pinterest videos easily with our free online tool. Save and share your favorite Pinterest content.
                </p>
            </div>
            
            <!-- Quick Links -->
            <div>
                <h3 class="text-lg font-semibold mb-4">Quick Links</h3>
                <ul class="space-y-2">
                    <li><a href="/pinsave/pages/about.php" class="text-blue-600 hover:underline">About Us</a></li>
                    <li><a href="/pinsave/pages/contact.php" class="text-blue-600 hover:underline">Contact Us</a></li>
                    <li><a href="/pinsave/pages/faq.php" class="text-blue-600 hover:underline">FAQ</a></li>
                    <li><a href="/pinsave/pages/dmca.php" class="text-blue-600 hover:underline">DMCA Policy</a></li>
                    <li><a href="/pinsave/pages/privacy.php" class="text-blue-600 hover:underline">Privacy Policy</a></li>
                    <li><a href="/pinsave/pages/terms.php" class="text-blue-600 hover:underline">Terms of Service</a></li>
                </ul>
            </div>
            
            <!-- Tools -->
            <div>
                <h3 class="text-lg font-semibold mb-4">Our Tools</h3>
                <ul class="space-y-2">
                    <li><a href="/tool/pinterest-video" class="text-blue-600 hover:underline">Pinterest Video Downloader</a></li>
                    <li><a href="/tool/image-converter" class="text-blue-600 hover:underline">Image Converter</a></li>
                </ul>
            </div>
            
            <!-- Contact -->
            <div>
                <h3 class="text-lg font-semibold mb-4">Contact Us</h3>
                <ul class="space-y-2 text-gray-600">
                    <li>Email: contact@pinsave.com</li>
                    <li>Follow us on social media</li>
                </ul>
            </div>
        </div>
        
        <!-- Copyright -->
        <div class="border-t mt-8 pt-8 text-center text-gray-600">
            <p>&copy; <?php echo date('Y'); ?> PinSave. All rights reserved.</p>
        </div>
    </div>
</footer>
