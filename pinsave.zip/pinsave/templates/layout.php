<?php
/**
 * Main layout template for PinSave
 * This template provides a consistent structure for all pages
 */

// Ensure required variables are set
$pageTitle = $pageTitle ?? 'PinSave - Pinterest Video Downloader';
$metaTitle = $metaTitle ?? $pageTitle;
$metaDescription = $metaDescription ?? 'Download Pinterest videos easily with PinSave';
$metaKeywords = $metaKeywords ?? 'pinterest video downloader, pinterest video saver, download pinterest videos';
$currentUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https://" : "http://") . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Primary Meta Tags -->
    <title><?= htmlspecialchars($metaTitle) ?></title>
    <meta name="description" content="<?= htmlspecialchars($metaDescription) ?>">
    <meta name="keywords" content="<?= htmlspecialchars($metaKeywords) ?>">
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?= htmlspecialchars($currentUrl) ?>">
    <meta property="og:title" content="<?= htmlspecialchars($metaTitle) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($metaDescription) ?>">
    
    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="<?= htmlspecialchars($currentUrl) ?>">
    <meta property="twitter:title" content="<?= htmlspecialchars($metaTitle) ?>">
    <meta property="twitter:description" content="<?= htmlspecialchars($metaDescription) ?>">
    
    <!-- Favicon -->
    <link rel="icon" href="/host/pinsave/img/favicon.ico" type="image/x-icon">
    
    <!-- Stylesheets -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <!-- Custom Styles -->
    <style>
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        main {
            flex: 1;
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-md">
        <div class="container mx-auto px-4">
            <!-- Mobile Menu Button and Logo -->
            <div class="flex justify-between items-center py-3 lg:hidden">
                <!-- Logo -->
                <a href="/host/pinsave/" class="flex items-center">
                    <img src="/host/pinsave/img/logo.svg" alt="PinSave" class="h-8 w-auto mr-2">
                    <span class="text-xl font-bold text-[#E60023]">PinSave</span>
                </a>

                <!-- Mobile Menu Button -->
                <button class="text-gray-600 hover:text-[#E60023]" id="mobileMenuBtn">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path>
                    </svg>
                </button>
            </div>

            <!-- Desktop Menu -->
            <div class="hidden lg:block">
                <div class="flex justify-between items-center w-full py-3">
                    <!-- Logo on the left -->
                    <a href="/host/pinsave/" class="flex items-center">
                        <img src="/host/pinsave/img/logo.svg" alt="PinSave" class="h-8 w-auto mr-2">
                        <span class="text-xl font-bold text-[#E60023]">PinSave</span>
                    </a>

                    <!-- Navigation items on the right -->
                    <div class="flex items-center space-x-6">
                        <a href="/host/pinsave/" class="text-gray-700 hover:text-[#E60023] px-3 py-2 rounded-md text-sm font-medium">Home</a>
                        <a href="/host/pinsave/pages/about.php" class="text-gray-700 hover:text-[#E60023] px-3 py-2 rounded-md text-sm font-medium">About</a>
                        <a href="/host/pinsave/blog.php" class="text-gray-700 hover:text-[#E60023] px-3 py-2 rounded-md text-sm font-medium">Blog</a>
                        <a href="/host/pinsave/pages/faq.php" class="text-gray-700 hover:text-[#E60023] px-3 py-2 rounded-md text-sm font-medium">FAQ</a>
                        <a href="/host/pinsave/pages/contact.php" class="text-gray-700 hover:text-[#E60023] px-3 py-2 rounded-md text-sm font-medium">Contact</a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Mobile Menu -->
        <div class="lg:hidden">
            <div id="mobileMenu" class="hidden bg-white border-t border-gray-200 py-2">
                <div class="container mx-auto px-4 space-y-1">
                    <a href="/host/pinsave/" class="block px-3 py-2 text-gray-700 hover:text-[#E60023] font-medium">Home</a>
                    <a href="/host/pinsave/pages/about.php" class="block px-3 py-2 text-gray-700 hover:text-[#E60023] font-medium">About</a>
                    <a href="/host/pinsave/blog.php" class="block px-3 py-2 text-gray-700 hover:text-[#E60023] font-medium">Blog</a>
                    <a href="/host/pinsave/pages/faq.php" class="block px-3 py-2 text-gray-700 hover:text-[#E60023] font-medium">FAQ</a>
                    <a href="/host/pinsave/pages/contact.php" class="block px-3 py-2 text-gray-700 hover:text-[#E60023] font-medium">Contact</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="container mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow-md p-6 md:p-8">
            <?php echo $pageContent ?? ''; ?>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-white border-t mt-8">
        <div class="container mx-auto px-4 py-6">
            <div class="text-center text-sm text-gray-600">
                <?php echo $footerConfig['copyright_text'] ?? '© ' . date('Y') . ' pinsave.in - All Rights Reserved'; ?>
            </div>
            <div class="mt-2 text-xs text-gray-500 text-center max-w-4xl mx-auto">
                <?php echo $footerConfig['disclaimer'] ?? ''; ?>
            </div>
        </div>
    </footer>

    <!-- Mobile Menu Script -->
    <script>
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mobileMenu = document.getElementById('mobileMenu');
        
        mobileMenuBtn.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
        });
    </script>
</body>
</html>
