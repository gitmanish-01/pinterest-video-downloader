<?php
// Get view type from query string (grid, list, masonry)
$view = $_GET['view'] ?? 'grid';

// Get current page
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 12;

// Get posts
$posts = $adminConfig['posts'] ?? [];

// Filter only public posts
$posts = array_filter($posts, function($post) {
    return $post['visibility'] === 'public';
});

// Sort by date (newest first)
uasort($posts, function($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
});

// Pagination
$total_posts = count($posts);
$total_pages = ceil($total_posts / $per_page);
$posts = array_slice($posts, ($page - 1) * $per_page, $per_page, true);
?>

<div class="mb-8">
    <h1 class="text-3xl font-bold mb-4">Blog</h1>
    
    <!-- View Switcher -->
    <div class="flex justify-between items-center mb-6">
        <div class="flex space-x-2">
            <a href="?view=grid" class="px-3 py-1 rounded <?php echo $view === 'grid' ? 'bg-blue-500 text-white' : 'bg-gray-100'; ?>">
                <i class="fas fa-th"></i> Grid
            </a>
            <a href="?view=list" class="px-3 py-1 rounded <?php echo $view === 'list' ? 'bg-blue-500 text-white' : 'bg-gray-100'; ?>">
                <i class="fas fa-list"></i> List
            </a>
            <a href="?view=masonry" class="px-3 py-1 rounded <?php echo $view === 'masonry' ? 'bg-blue-500 text-white' : 'bg-gray-100'; ?>">
                <i class="fas fa-th-large"></i> Masonry
            </a>
        </div>
    </div>

    <?php if (empty($posts)): ?>
        <div class="text-center py-12">
            <h2 class="text-2xl font-semibold text-gray-600">No posts found</h2>
            <p class="text-gray-500 mt-2">Check back later for new content!</p>
        </div>
    <?php else: ?>
        <?php if ($view === 'grid'): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($posts as $post): ?>
                    <article class="bg-white rounded-lg shadow-sm overflow-hidden">
                        <?php if (!empty($post['thumbnail'])): ?>
                            <img src="<?php echo htmlspecialchars($post['thumbnail']); ?>" 
                                 alt="<?php echo htmlspecialchars($post['title']); ?>"
                                 class="w-full h-48 object-cover">
                        <?php endif; ?>
                        
                        <div class="p-6">
                            <h2 class="text-xl font-semibold mb-2">
                                <a href="/blog/<?php echo $post['slug']; ?>" class="hover:text-blue-600">
                                    <?php echo htmlspecialchars($post['title']); ?>
                                </a>
                            </h2>
                            
                            <div class="text-gray-600 text-sm mb-4">
                                <?php echo date('F j, Y', strtotime($post['created_at'])); ?>
                                <?php if (!empty($post['category'])): ?>
                                    • <a href="/category/<?php echo $post['category']; ?>" class="text-blue-600 hover:underline">
                                        <?php echo htmlspecialchars($post['category']); ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                            
                            <p class="text-gray-600 mb-4">
                                <?php echo substr(strip_tags($post['content']), 0, 150) . '...'; ?>
                            </p>
                            
                            <div class="flex items-center justify-between">
                                <a href="/blog/<?php echo $post['slug']; ?>" 
                                   class="text-blue-600 hover:underline">
                                    Read More
                                </a>
                                
                                <?php if (!empty($post['tags'])): ?>
                                    <div class="flex flex-wrap gap-2">
                                        <?php foreach ($post['tags'] as $tag): ?>
                                            <a href="/tag/<?php echo $tag; ?>" 
                                               class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                                                #<?php echo htmlspecialchars($tag); ?>
                                            </a>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
            
        <?php elseif ($view === 'list'): ?>
            <div class="space-y-6">
                <?php foreach ($posts as $post): ?>
                    <article class="bg-white rounded-lg shadow-sm overflow-hidden">
                        <div class="md:flex">
                            <?php if (!empty($post['thumbnail'])): ?>
                                <div class="md:w-48 flex-shrink-0">
                                    <img src="<?php echo htmlspecialchars($post['thumbnail']); ?>" 
                                         alt="<?php echo htmlspecialchars($post['title']); ?>"
                                         class="w-full h-48 md:h-full object-cover">
                                </div>
                            <?php endif; ?>
                            
                            <div class="p-6">
                                <h2 class="text-xl font-semibold mb-2">
                                    <a href="/blog/<?php echo $post['slug']; ?>" class="hover:text-blue-600">
                                        <?php echo htmlspecialchars($post['title']); ?>
                                    </a>
                                </h2>
                                
                                <div class="text-gray-600 text-sm mb-4">
                                    <?php echo date('F j, Y', strtotime($post['created_at'])); ?>
                                    <?php if (!empty($post['category'])): ?>
                                        • <a href="/category/<?php echo $post['category']; ?>" class="text-blue-600 hover:underline">
                                            <?php echo htmlspecialchars($post['category']); ?>
                                        </a>
                                    <?php endif; ?>
                                </div>
                                
                                <p class="text-gray-600 mb-4">
                                    <?php echo substr(strip_tags($post['content']), 0, 300) . '...'; ?>
                                </p>
                                
                                <div class="flex items-center justify-between">
                                    <a href="/blog/<?php echo $post['slug']; ?>" 
                                       class="text-blue-600 hover:underline">
                                        Read More
                                    </a>
                                    
                                    <?php if (!empty($post['tags'])): ?>
                                        <div class="flex flex-wrap gap-2">
                                            <?php foreach ($post['tags'] as $tag): ?>
                                                <a href="/tag/<?php echo $tag; ?>" 
                                                   class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                                                    #<?php echo htmlspecialchars($tag); ?>
                                                </a>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
            
        <?php else: /* Masonry */ ?>
            <div class="columns-1 md:columns-2 lg:columns-3 gap-6">
                <?php foreach ($posts as $post): ?>
                    <article class="bg-white rounded-lg shadow-sm overflow-hidden break-inside-avoid mb-6">
                        <?php if (!empty($post['thumbnail'])): ?>
                            <img src="<?php echo htmlspecialchars($post['thumbnail']); ?>" 
                                 alt="<?php echo htmlspecialchars($post['title']); ?>"
                                 class="w-full object-cover">
                        <?php endif; ?>
                        
                        <div class="p-6">
                            <h2 class="text-xl font-semibold mb-2">
                                <a href="/blog/<?php echo $post['slug']; ?>" class="hover:text-blue-600">
                                    <?php echo htmlspecialchars($post['title']); ?>
                                </a>
                            </h2>
                            
                            <div class="text-gray-600 text-sm mb-4">
                                <?php echo date('F j, Y', strtotime($post['created_at'])); ?>
                                <?php if (!empty($post['category'])): ?>
                                    • <a href="/category/<?php echo $post['category']; ?>" class="text-blue-600 hover:underline">
                                        <?php echo htmlspecialchars($post['category']); ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                            
                            <p class="text-gray-600 mb-4">
                                <?php echo substr(strip_tags($post['content']), 0, 200) . '...'; ?>
                            </p>
                            
                            <div class="flex items-center justify-between">
                                <a href="/blog/<?php echo $post['slug']; ?>" 
                                   class="text-blue-600 hover:underline">
                                    Read More
                                </a>
                                
                                <?php if (!empty($post['tags'])): ?>
                                    <div class="flex flex-wrap gap-2">
                                        <?php foreach ($post['tags'] as $tag): ?>
                                            <a href="/tag/<?php echo $tag; ?>" 
                                               class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                                                #<?php echo htmlspecialchars($tag); ?>
                                            </a>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <div class="mt-8 flex justify-center">
                <div class="flex space-x-2">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>&view=<?php echo $view; ?>" 
                           class="px-4 py-2 bg-white rounded shadow hover:bg-gray-50">
                            Previous
                        </a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&view=<?php echo $view; ?>" 
                           class="px-4 py-2 <?php echo $i === $page ? 'bg-blue-500 text-white' : 'bg-white hover:bg-gray-50'; ?> rounded shadow">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?php echo $page + 1; ?>&view=<?php echo $view; ?>" 
                           class="px-4 py-2 bg-white rounded shadow hover:bg-gray-50">
                            Next
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<!-- Load masonry.js only when needed -->
<?php if ($view === 'masonry'): ?>
<script src="https://unpkg.com/masonry-layout@4/dist/masonry.pkgd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    new Masonry('.masonry-grid', {
        itemSelector: '.masonry-item',
        columnWidth: '.masonry-sizer',
        percentPosition: true
    });
});
</script>
<?php endif; ?>
