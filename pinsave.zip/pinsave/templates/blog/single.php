<?php
// Get post by slug
$slug = $params['slug'] ?? '';
$post = null;

foreach ($adminConfig['posts'] as $p) {
    if ($p['slug'] === $slug && $p['visibility'] === 'public') {
        $post = $p;
        break;
    }
}

// 404 if post not found
if (!$post) {
    header("HTTP/1.0 404 Not Found");
    require dirname(__DIR__) . '/404.php';
    exit;
}

// Get related posts
$related_posts = [];
foreach ($adminConfig['posts'] as $p) {
    if ($p['visibility'] === 'public' && $p['slug'] !== $slug) {
        // Match by category or tags
        if ($p['category'] === $post['category'] || 
            !empty(array_intersect($p['tags'] ?? [], $post['tags'] ?? []))) {
            $related_posts[] = $p;
            if (count($related_posts) >= 3) break;
        }
    }
}
?>

<article class="max-w-4xl mx-auto">
    <!-- Article Header -->
    <header class="mb-8">
        <h1 class="text-4xl font-bold mb-4">
            <?php echo htmlspecialchars($post['title']); ?>
        </h1>
        
        <div class="flex items-center text-gray-600 text-sm mb-6">
            <span><?php echo date('F j, Y', strtotime($post['created_at'])); ?></span>
            
            <?php if (!empty($post['category'])): ?>
                <span class="mx-2">•</span>
                <a href="/category/<?php echo $post['category']; ?>" 
                   class="text-blue-600 hover:underline">
                    <?php echo htmlspecialchars($post['category']); ?>
                </a>
            <?php endif; ?>
            
            <?php if (!empty($post['author'])): ?>
                <span class="mx-2">•</span>
                <span>By <?php echo htmlspecialchars($post['author']); ?></span>
            <?php endif; ?>
        </div>
        
        <?php if (!empty($post['thumbnail'])): ?>
            <img src="<?php echo htmlspecialchars($post['thumbnail']); ?>" 
                 alt="<?php echo htmlspecialchars($post['title']); ?>"
                 class="w-full h-64 md:h-96 object-cover rounded-lg shadow-lg mb-8">
        <?php endif; ?>
    </header>
    
    <!-- Article Content -->
    <div class="prose prose-lg max-w-none mb-8">
        <?php echo $post['content']; ?>
    </div>
    
    <!-- Tags -->
    <?php if (!empty($post['tags'])): ?>
        <div class="border-t border-b py-4 mb-8">
            <div class="flex flex-wrap gap-2">
                <?php foreach ($post['tags'] as $tag): ?>
                    <a href="/tag/<?php echo $tag; ?>" 
                       class="bg-gray-100 text-gray-600 px-3 py-1 rounded-full hover:bg-gray-200">
                        #<?php echo htmlspecialchars($tag); ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Share Buttons -->
    <div class="flex items-center space-x-4 mb-8">
        <span class="text-gray-600">Share:</span>
        <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode($currentUrl); ?>&text=<?php echo urlencode($post['title']); ?>" 
           target="_blank"
           class="text-blue-400 hover:text-blue-500">
            <i class="fab fa-twitter"></i>
        </a>
        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode($currentUrl); ?>" 
           target="_blank"
           class="text-blue-600 hover:text-blue-700">
            <i class="fab fa-facebook"></i>
        </a>
        <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo urlencode($currentUrl); ?>&title=<?php echo urlencode($post['title']); ?>" 
           target="_blank"
           class="text-blue-700 hover:text-blue-800">
            <i class="fab fa-linkedin"></i>
        </a>
    </div>
    
    <!-- Related Posts -->
    <?php if (!empty($related_posts)): ?>
        <div class="border-t pt-8 mt-8">
            <h2 class="text-2xl font-bold mb-6">Related Posts</h2>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <?php foreach ($related_posts as $related): ?>
                    <article class="bg-white rounded-lg shadow-sm overflow-hidden">
                        <?php if (!empty($related['thumbnail'])): ?>
                            <img src="<?php echo htmlspecialchars($related['thumbnail']); ?>" 
                                 alt="<?php echo htmlspecialchars($related['title']); ?>"
                                 class="w-full h-48 object-cover">
                        <?php endif; ?>
                        
                        <div class="p-4">
                            <h3 class="font-semibold mb-2">
                                <a href="/blog/<?php echo $related['slug']; ?>" 
                                   class="hover:text-blue-600">
                                    <?php echo htmlspecialchars($related['title']); ?>
                                </a>
                            </h3>
                            
                            <div class="text-sm text-gray-600">
                                <?php echo date('M j, Y', strtotime($related['created_at'])); ?>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Comments Section (if enabled) -->
    <?php if (!empty($adminConfig['comments_enabled'])): ?>
        <div class="border-t pt-8 mt-8">
            <h2 class="text-2xl font-bold mb-6">Comments</h2>
            <div id="disqus_thread"></div>
            <script>
                var disqus_config = function () {
                    this.page.url = '<?php echo $currentUrl; ?>';
                    this.page.identifier = '<?php echo $post['slug']; ?>';
                };
                (function() {
                    var d = document, s = d.createElement('script');
                    s.src = 'https://<?php echo $adminConfig['disqus_shortname']; ?>.disqus.com/embed.js';
                    s.setAttribute('data-timestamp', +new Date());
                    (d.head || d.body).appendChild(s);
                })();
            </script>
        </div>
    <?php endif; ?>
</article>

<!-- Schema.org Article Markup -->
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "<?php echo htmlspecialchars($post['title']); ?>",
    "datePublished": "<?php echo date('c', strtotime($post['created_at'])); ?>",
    "dateModified": "<?php echo date('c', strtotime($post['updated_at'] ?? $post['created_at'])); ?>",
    <?php if (!empty($post['thumbnail'])): ?>
    "image": "<?php echo htmlspecialchars($post['thumbnail']); ?>",
    <?php endif; ?>
    <?php if (!empty($post['author'])): ?>
    "author": {
        "@type": "Person",
        "name": "<?php echo htmlspecialchars($post['author']); ?>"
    },
    <?php endif; ?>
    "publisher": {
        "@type": "Organization",
        "name": "PinSave",
        "logo": {
            "@type": "ImageObject",
            "url": "/assets/images/logo.png"
        }
    }
}
</script>
