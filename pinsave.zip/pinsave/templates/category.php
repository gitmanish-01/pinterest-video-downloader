<?php
$slug = $params['slug'] ?? '';
$category = null;

// Find category
foreach ($adminConfig['categories'] as $cat) {
    if ($cat['slug'] === $slug) {
        $category = $cat;
        break;
    }
}

// 404 if category not found
if (!$category) {
    header("HTTP/1.0 404 Not Found");
    require 'templates/404.php';
    exit;
}

// Get posts in this category
$posts = array_filter($adminConfig['posts'] ?? [], function($post) use ($slug) {
    return $post['visibility'] === 'public' && $post['category'] === $slug;
});

// Sort by date
uasort($posts, function($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
});

// Pagination
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 12;
$total_posts = count($posts);
$total_pages = ceil($total_posts / $per_page);
$posts = array_slice($posts, ($page - 1) * $per_page, $per_page, true);
?>

<div class="mb-8">
    <header class="mb-8">
        <h1 class="text-3xl font-bold mb-2">
            Category: <?php echo htmlspecialchars($category['name']); ?>
        </h1>
        <?php if (!empty($category['description'])): ?>
            <p class="text-gray-600">
                <?php echo htmlspecialchars($category['description']); ?>
            </p>
        <?php endif; ?>
    </header>

    <?php if (empty($posts)): ?>
        <div class="text-center py-12">
            <h2 class="text-2xl font-semibold text-gray-600">No posts found</h2>
            <p class="text-gray-500 mt-2">There are no posts in this category yet.</p>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($posts as $post): ?>
                <article class="bg-white rounded-lg shadow-sm overflow-hidden">
                    <?php if (!empty($post['thumbnail'])): ?>
                        <img src="<?php echo htmlspecialchars($post['thumbnail']); ?>" 
                             alt="<?php echo htmlspecialchars($post['title']); ?>"
                             class="w-full h-48 object-cover">
                    <?php endif; ?>
                    
                    <div class="p-6">
                        <h2 class="text-xl font-semibold mb-2">
                            <a href="/blog/<?php echo $post['slug']; ?>" class="hover:text-blue-600">
                                <?php echo htmlspecialchars($post['title']); ?>
                            </a>
                        </h2>
                        
                        <div class="text-gray-600 text-sm mb-4">
                            <?php echo date('F j, Y', strtotime($post['created_at'])); ?>
                        </div>
                        
                        <p class="text-gray-600 mb-4">
                            <?php echo substr(strip_tags($post['content']), 0, 150) . '...'; ?>
                        </p>
                        
                        <div class="flex items-center justify-between">
                            <a href="/blog/<?php echo $post['slug']; ?>" 
                               class="text-blue-600 hover:underline">
                                Read More
                            </a>
                            
                            <?php if (!empty($post['tags'])): ?>
                                <div class="flex flex-wrap gap-2">
                                    <?php foreach ($post['tags'] as $tag): ?>
                                        <a href="/tag/<?php echo $tag; ?>" 
                                           class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                                            #<?php echo htmlspecialchars($tag); ?>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <div class="mt-8 flex justify-center">
                <div class="flex space-x-2">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>" 
                           class="px-4 py-2 bg-white rounded shadow hover:bg-gray-50">
                            Previous
                        </a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>" 
                           class="px-4 py-2 <?php echo $i === $page ? 'bg-blue-500 text-white' : 'bg-white hover:bg-gray-50'; ?> rounded shadow">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?php echo $page + 1; ?>" 
                           class="px-4 py-2 bg-white rounded shadow hover:bg-gray-50">
                            Next
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
