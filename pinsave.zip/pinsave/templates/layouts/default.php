<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title ?? 'PinSave - Pinterest Video Downloader'; ?></title>
    
    <?php if (isset($meta_description)): ?>
    <meta name="description" content="<?php echo htmlspecialchars($meta_description); ?>">
    <?php endif; ?>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/assets/css/style.css">
    
    <?php $this->partial('head'); ?>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <?php $this->partial('header'); ?>
    
    <!-- Main Content -->
    <main class="container mx-auto px-4 py-8">
        <div class="max-w-7xl mx-auto">
            <?php require dirname(__DIR__) . "/templates/{$this->template}.php"; ?>
        </div>
    </main>
    
    <!-- Footer -->
    <?php $this->partial('footer'); ?>
    
    <!-- Scripts -->
    <?php $this->partial('scripts'); ?>
</body>
</html>
