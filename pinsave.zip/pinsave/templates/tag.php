<?php
$tag = $params['slug'] ?? '';

// Get posts with this tag
$posts = array_filter($adminConfig['posts'] ?? [], function($post) use ($tag) {
    return $post['visibility'] === 'public' && in_array($tag, $post['tags'] ?? []);
});

// Sort by date
uasort($posts, function($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
});

// Pagination
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 12;
$total_posts = count($posts);
$total_pages = ceil($total_posts / $per_page);
$posts = array_slice($posts, ($page - 1) * $per_page, $per_page, true);
?>

<div class="mb-8">
    <header class="mb-8">
        <h1 class="text-3xl font-bold mb-2">
            Posts tagged with: #<?php echo htmlspecialchars($tag); ?>
        </h1>
        <p class="text-gray-600">
            Found <?php echo $total_posts; ?> post<?php echo $total_posts !== 1 ? 's' : ''; ?> with this tag
        </p>
    </header>

    <?php if (empty($posts)): ?>
        <div class="text-center py-12">
            <h2 class="text-2xl font-semibold text-gray-600">No posts found</h2>
            <p class="text-gray-500 mt-2">There are no posts with this tag yet.</p>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($posts as $post): ?>
                <article class="bg-white rounded-lg shadow-sm overflow-hidden">
                    <?php if (!empty($post['thumbnail'])): ?>
                        <img src="<?php echo htmlspecialchars($post['thumbnail']); ?>" 
                             alt="<?php echo htmlspecialchars($post['title']); ?>"
                             class="w-full h-48 object-cover">
                    <?php endif; ?>
                    
                    <div class="p-6">
                        <h2 class="text-xl font-semibold mb-2">
                            <a href="/blog/<?php echo $post['slug']; ?>" class="hover:text-blue-600">
                                <?php echo htmlspecialchars($post['title']); ?>
                            </a>
                        </h2>
                        
                        <div class="text-gray-600 text-sm mb-4">
                            <?php echo date('F j, Y', strtotime($post['created_at'])); ?>
                            <?php if (!empty($post['category'])): ?>
                                • <a href="/category/<?php echo $post['category']; ?>" class="text-blue-600 hover:underline">
                                    <?php echo htmlspecialchars($post['category']); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                        
                        <p class="text-gray-600 mb-4">
                            <?php echo substr(strip_tags($post['content']), 0, 150) . '...'; ?>
                        </p>
                        
                        <div class="flex items-center justify-between">
                            <a href="/blog/<?php echo $post['slug']; ?>" 
                               class="text-blue-600 hover:underline">
                                Read More
                            </a>
                            
                            <?php if (!empty($post['tags'])): ?>
                                <div class="flex flex-wrap gap-2">
                                    <?php foreach ($post['tags'] as $tag): ?>
                                        <a href="/tag/<?php echo $tag; ?>" 
                                           class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                                            #<?php echo htmlspecialchars($tag); ?>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <div class="mt-8 flex justify-center">
                <div class="flex space-x-2">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>" 
                           class="px-4 py-2 bg-white rounded shadow hover:bg-gray-50">
                            Previous
                        </a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>" 
                           class="px-4 py-2 <?php echo $i === $page ? 'bg-blue-500 text-white' : 'bg-white hover:bg-gray-50'; ?> rounded shadow">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?php echo $page + 1; ?>" 
                           class="px-4 py-2 bg-white rounded shadow hover:bg-gray-50">
                            Next
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
    
    <!-- Popular Tags -->
    <div class="mt-12 border-t pt-8">
        <h2 class="text-2xl font-bold mb-6">Popular Tags</h2>
        <div class="flex flex-wrap gap-3">
            <?php
            // Get all tags and their counts
            $tag_counts = [];
            foreach ($adminConfig['posts'] as $p) {
                if ($p['visibility'] === 'public') {
                    foreach ($p['tags'] ?? [] as $t) {
                        $tag_counts[$t] = ($tag_counts[$t] ?? 0) + 1;
                    }
                }
            }
            
            // Sort by count
            arsort($tag_counts);
            
            // Show top 20 tags
            $top_tags = array_slice($tag_counts, 0, 20, true);
            
            foreach ($top_tags as $t => $count):
            ?>
                <a href="/tag/<?php echo $t; ?>" 
                   class="px-3 py-1 bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200">
                    #<?php echo htmlspecialchars($t); ?>
                    <span class="text-gray-500">(<?php echo $count; ?>)</span>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>
