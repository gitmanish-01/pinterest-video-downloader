<?php
require_once '../config.php';
require_once '../includes/router.php';

$router = new Router();

// Home page
$router->add('/', function() {
    require '../templates/home.php';
});

// Blog list
$router->add('/blog', function() {
    require '../templates/blog/list.php';
});

// Single blog post
$router->add('/blog/\{slug\}', function($params) {
    $slug = $params['slug'];
    require '../templates/blog/single.php';
});

// Pages
$router->add('/page/\{slug\}', function($params) {
    $slug = $params['slug'];
    require '../templates/page.php';
});

// Tool routes
$router->add('/tool/pinterest-video', function() {
    require '../templates/tools/pinterest-video.php';
});

$router->add('/tool/image-converter', function() {
    require '../templates/tools/image-converter.php';
});

// Category pages
$router->add('/category/\{slug\}', function($params) {
    $slug = $params['slug'];
    require '../templates/category.php';
});

// Tag pages
$router->add('/tag/\{slug\}', function($params) {
    $slug = $params['slug'];
    require '../templates/tag.php';
});

// 404 handler
$router->notFound(function() {
    header("HTTP/1.0 404 Not Found");
    require '../templates/404.php';
});

// Dispatch the router
$router->dispatch();
