<?php
require_once '../config.php';

// Set content type to XML
header('Content-Type: application/xml; charset=utf-8');

// Get base URL
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
$baseUrl = $protocol . $_SERVER['HTTP_HOST'];

// Start XML
echo '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL;

// Add homepage
echo '<url>' . PHP_EOL;
echo '  <loc>' . $baseUrl . '/</loc>' . PHP_EOL;
echo '  <changefreq>daily</changefreq>' . PHP_EOL;
echo '  <priority>1.0</priority>' . PHP_EOL;
echo '</url>' . PHP_EOL;

// Add blog index
echo '<url>' . PHP_EOL;
echo '  <loc>' . $baseUrl . '/blog</loc>' . PHP_EOL;
echo '  <changefreq>daily</changefreq>' . PHP_EOL;
echo '  <priority>0.9</priority>' . PHP_EOL;
echo '</url>' . PHP_EOL;

// Add tool pages
$tools = [
    'pinterest-video' => 'Pinterest Video Downloader',
    'image-converter' => 'Image Converter'
];

foreach ($tools as $slug => $name) {
    echo '<url>' . PHP_EOL;
    echo '  <loc>' . $baseUrl . '/tool/' . $slug . '</loc>' . PHP_EOL;
    echo '  <changefreq>weekly</changefreq>' . PHP_EOL;
    echo '  <priority>0.8</priority>' . PHP_EOL;
    echo '</url>' . PHP_EOL;
}

// Add blog posts
if (!empty($adminConfig['posts'])) {
    foreach ($adminConfig['posts'] as $post) {
        if ($post['visibility'] === 'public') {
            echo '<url>' . PHP_EOL;
            echo '  <loc>' . $baseUrl . '/blog/' . $post['slug'] . '</loc>' . PHP_EOL;
            echo '  <lastmod>' . date('Y-m-d', strtotime($post['updated_at'])) . '</lastmod>' . PHP_EOL;
            echo '  <changefreq>monthly</changefreq>' . PHP_EOL;
            echo '  <priority>0.7</priority>' . PHP_EOL;
            echo '</url>' . PHP_EOL;
        }
    }
}

// Add pages
if (!empty($adminConfig['pages'])) {
    foreach ($adminConfig['pages'] as $page) {
        if ($page['visibility'] === 'public') {
            echo '<url>' . PHP_EOL;
            echo '  <loc>' . $baseUrl . '/page/' . $page['slug'] . '</loc>' . PHP_EOL;
            echo '  <lastmod>' . date('Y-m-d', strtotime($page['updated_at'])) . '</lastmod>' . PHP_EOL;
            echo '  <changefreq>monthly</changefreq>' . PHP_EOL;
            echo '  <priority>0.6</priority>' . PHP_EOL;
            echo '</url>' . PHP_EOL;
        }
    }
}

// Add category pages
if (!empty($adminConfig['categories'])) {
    foreach ($adminConfig['categories'] as $category) {
        echo '<url>' . PHP_EOL;
        echo '  <loc>' . $baseUrl . '/category/' . $category['slug'] . '</loc>' . PHP_EOL;
        echo '  <changefreq>weekly</changefreq>' . PHP_EOL;
        echo '  <priority>0.5</priority>' . PHP_EOL;
        echo '</url>' . PHP_EOL;
    }
}

// Close XML
echo '</urlset>';
